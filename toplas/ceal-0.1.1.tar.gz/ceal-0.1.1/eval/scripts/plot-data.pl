#!/usr/bin/env perl
# Matthew Hammer <hammer@tti-c.org>
use strict;
use POSIX;
use Getopt::Std;
use Testutils;
use Template;

my $datasets = [];
my $targetdir;
my $verif_label = "Cnv.";

## Process command-line arguments
sub doopts {   
    for(my $i = 0; $i <= $#ARGV; $i++) {
        my $dir;
        my $label;
        
        if($ARGV[$i] =~ /([^=]*)=(.+)/) {
            $label = $1;
            $dir = $2;
        }
        else {
            $dir = $label = $ARGV[$i];
        }        
        Testutils::logg("Info", "path=$dir, label=$label");
        die "not a dir: $dir\n" if !(-d $dir);

        my $dataset = {
            label => $label, 
            path  =>  $dir
            };

        push @$datasets, $dataset;
        $targetdir = $dir;
    }
    
    ## See if the user has given us an explicit targetdir.
    {
        my %args;
        getopts("d:", \%args);    
        if(exists $args{d}) {
            $targetdir = $args{d};
        }
    }

    Testutils::logg("Info", "targetdir=$targetdir");
}

##
## Get an array of datasets for a particular subdirectory (i.e.,
## application) based on the full datasets given on the command-line.
##
sub datasets_for_subdir {
    my $subdir = shift;
    my $datasets_out = [];
    my $dataset_out_last;

    for my $dataset (@$datasets) {
        my %dataset_out = %$dataset;
        $dataset_out{"path"} = $$dataset{"path"}."/$subdir";
        $dataset_out{"delim"} = ",\\\n";
        $dataset_out_last = {%dataset_out};
        push @$datasets_out, $dataset_out_last;
    }
    $$dataset_out_last{"delim"} = "";
    $datasets_out;
}

sub mk_verifier_from {
    my $dataset = shift;    
    my $verifier = {%$dataset};
    $$verifier{"label"} = ucfirst $verif_label;
    return $verifier;
}

##
##
##
sub verifier_for_datasets {
    my $datasets = shift;    
    for my $dataset (@$datasets) {
        if ($$dataset{"label"} =~ /([^,]*),$verif_label$/) {
            my $verifier = mk_verifier_from($dataset);
            $$dataset{"label"} = $1;
            return $verifier;
        }
    }
    return mk_verifier_from(@$datasets[$#$datasets]);
}

## pick_xtics() --- GNUPLOT has many severe holes in its
## functionality.  One of them is allowing the user to say how many
## xtics they want without having to say how far apart they are along
## the x axis.  Basically I want to have xtics spaced out so that I
## can read each of them (they don't overlap eachother).  This
## "high-level" goal is reached by ensuring there are only 5 tics
## total.  I do this by picking the xtics (increment) value to be
## ($max_n / 5).  Also, since GNUPLOT can't format numbers in any
## useful way, I hand-format the values that label the xtics, e.g.,
## using notation like "100K" for the number 100,0000.
sub pick_xtics {
    my $max_n = shift;
    chomp($max_n);   
    my $incr = floor($max_n / 4);
    my $xtics = [];
    for(my $x = 0; $x <= $max_n; $x += $incr) {
        my $xlab = Testutils::format_number($x,"size_10");
        $xlab =~ s/(\.0)([KkMmGg]?)/$2/;
        push @$xtics, "\"$xlab\" $x";
    }    
    return ("(".(join(", ",@$xtics)).")");
}

sub plot_from_template {
    my $subdir = shift;
    my $max_n = shift;
    my $template = shift;

    Testutils::logg("Info", "plot_from_template: subdir=$subdir, template=$template");

    ## Get the plot filename by stripping ".template" from the end of
    ## the template filename.
    my $plotfile = $template;
    $plotfile =~ s/\.template$//;
    
    my $subdir_path = "$targetdir/$subdir";
    my $plots_path  = "$targetdir/$subdir/plots";

    my $datasets = datasets_for_subdir($subdir);
    my $verifier = verifier_for_datasets($datasets);
    my $xtics    = pick_xtics($max_n);

    my $tt = Template->new({
        INCLUDE_PATH => '../plot_templates',
    }) || die "$Template::ERROR\n";
    
    my $vars = {
        wd         => `pwd`,
        appname    => ucfirst($subdir),
        max_x      => $max_n,      
        xtics      => $xtics,
        output_dir => $plots_path,
        datasets   => $datasets,
        verifier   => $verifier
        };        
    
    ## Create the directory for the plot-file and plots, if it doesn't exist.
    Testutils::mysystem("mkdir -p $plots_path");
    
    ## Process the plot-file template into a plotfile ready for gnuplot.
    $tt->process($template, $vars, "$plots_path/$plotfile")
        || die $tt->error(), "\n";
    
    ## Run gnuplot on the plotfile.
    Testutils::mysystem("gnuplot $plots_path/$plotfile");    
}

doopts();

my $requests = Testutils::get_requests_file("plot-data.local",
                                            "plot-data.defaults");
for my $line (<$requests>) {
    next if $line =~ /^\#/;
    my ($app_name, $max_n) = Testutils::get_request_from_line $line;
    plot_from_template($app_name, $max_n, "fromscratch.gnuplot.template");
    plot_from_template($app_name, $max_n, "allinsrem.gnuplot.template");
    plot_from_template($app_name, $max_n, "maxlive.gnuplot.template");
    plot_from_template($app_name, $max_n, "overhead.gnuplot.template");
    plot_from_template($app_name, $max_n, "speedup.gnuplot.template");    
}
