#!/usr/bin/env perl
# Matthew Hammer <hammer@tti-c.org>
use strict;
use Getopt::Std;
use CollectSeries;

my $slimehome = "../../";
my $binary    = "$slimehome/bin/slime";
my $targetdir;   # <- Command-line arg
my $batchmode;   # <- Command-line arg
my $num_samples; # <- Command-line arg


## Process command-line arguments
##
## mandatory: -d <target-dir>     Specify target directory for results
## mandatory: -s <num-samples>    Specify #samples at each input-size.
##  optional: -b <binary>         Specify the binary path
##  optional: -B                  Run in "batch-mode" (don't tail the log)

sub doopts {
    my %args;
    getopts("s:d:b:B", \%args);
    die "required arg: -d <target-dir>\n" if (!exists $args{d});
    die "required arg: -s <num-samples>\n" if (!exists $args{s});

    $targetdir = $args{d};
    $num_samples = $args{s};
    $binary = $args{b} if exists $args{b};
    $batchmode = 1 if exists $args{B};
}

doopts();

Testutils::mysystem("mkdir -p $targetdir");

open(STDERR, ">$targetdir/LOG") or 
    die "couldn't open log file for writing";

Testutils::mysystem("cp $slimehome/slime_config.h $targetdir");

if(! $batchmode) {
    Testutils::mysystem("xterm -e \"tail -f $targetdir/LOG | grep -v '==\\W\\+Sys\\W\\+=='\" &");
}

my $requests = Testutils::get_requests_file("gather-data.local",
                                            "gather-data.defaults");

for my $line (<$requests>) {
    next if $line =~ /^\#/;
    my $min_n = 10;
    my ($app_name, $max_n) = Testutils::get_request_from_line $line;

    my $targetdir = "$targetdir/$app_name";
    my $command = "$binary -srand time -app $app_name -input-size \$N";
    
    CollectSeries::collect_series($targetdir, $command, $min_n, $max_n, $num_samples);
}

Testutils::logg("Info", "$0: complete.");
