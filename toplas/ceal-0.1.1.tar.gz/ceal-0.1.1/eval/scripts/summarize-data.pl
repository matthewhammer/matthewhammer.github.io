#!/usr/bin/env perl
# Matthew Hammer <hammer@tti-c.org>
use strict;
use Getopt::Std;
use Testutils;

my $targetdir; # <- Command-line arg

sub doopts {
    my %args;
    getopts("d:", \%args);
    die "required arg: -d <target-dir>\n" if (!exists $args{d});
    $targetdir = $args{d};
}

doopts();

my @apps = Testutils::apps_in_path($targetdir);

sub get_row {
    my $app = shift;
    my $input_size = shift;
    my $row = [];

    my $columns = [["input-size", "size_10"],
                   ["verifier/time", "frac"],
                   ["fromscratch/time", "frac"],
                   ["fromscratch/overhead", "frac"],
                   ["allinsrem/time-ave", "sci"],
                   ["allinsrem/speedup", "sci"],
#                   ["allinsrem/all-malloc-bytes", "size_2"],
                   ["allinsrem/all-maxlive-bytes", "size_2"]
                   ];
        
    my $row_num = Testutils::find_row_num($targetdir.$app, "input-size", $input_size);
    
    return 0 if($row_num < 0);

    for my $column (@$columns) {
        my ($colname, $colformat) = @$column;

        my $data = Testutils::get_data($targetdir.$app, $colname, $row_num);
        my $formatted = Testutils::format_number($data, $colformat);        
        push (@$row, $formatted);
    }
    return @$row;
}

open (OUT, ">$targetdir/summary-table.tex");

my $requests = Testutils::get_requests_file("summarize-data.local",
                                            "summarize-data.defaults");

for my $line (<$requests>) {
    next if $line =~ /^\#/;
    my ($app_name, $input_size) = Testutils::get_request_from_line $line;
    my @row = get_row($app_name, $input_size);

    if(@row) {
        my $line = sprintf ("%20s & %s\\\\ \\hline\n", "{\\tt $app_name}", (join " & ", @row));
        Testutils::logg("Out", $line);
        printf OUT $line;
    }
}

close (OUT);
