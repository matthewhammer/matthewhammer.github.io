/* Matthew A Hammer <hammer@tti-c.org> */

#define __SLIME_PQUEUE_H__

#include "traceobj.h"

typedef closure_t* pqueue_elt_t;
typedef struct pqueue_s pqueue_t;

pqueue_t*    pqueue_init(pqueue_t* pq);
uintptr_t    pqueue_isempty(const pqueue_t* pq);
void         pqueue_push(pqueue_t* pq, pqueue_elt_t elt);
pqueue_elt_t pqueue_pop(pqueue_t* pq);
pqueue_elt_t pqueue_peek(const pqueue_t* pq);
void         pqueue_cleanup(pqueue_t* pq);

struct pqueue_s {
  uintptr_t size;
  uintptr_t num;
  pqueue_elt_t* data;
};
