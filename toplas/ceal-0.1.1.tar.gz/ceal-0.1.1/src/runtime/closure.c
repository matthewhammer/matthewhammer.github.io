/* Matthew Hammer <hammer@tti-c.org> */
/* Operations on closures */

#include <assert.h>
#include <stdlib.h>
#include "closure.h"
#include "context.h"
#include "state.h"
#include "logging.h"
#include "pointerflags.h"

#define ONQUEUE 1 /* flag on closure->time_end */

uintptr_t  closure_onqueue(closure_t* closure);
closure_t* closure_dequeue();
closure_t* closure_invoke(closure_t* closure);
void       closure_reinvoke(closure_t* closure);

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

closure_vtbl_t* closure_vtbl(closure_t* closure) {
  return (closure_vtbl_t*) closure->traceobj.vtbl;
}

const char* closure_name(closure_t* closure) {
  return (closure_vtbl(closure)->traceobj_vtbl).name(closure);
}

timestamp_t* closure_time_start(closure_t* closure) {
  return closure->time_start;
}

timestamp_t* closure_time_end(closure_t* closure) {
  return pointer_part(closure->time_end);
}

uintptr_t closure_onqueue(closure_t* closure) {
  return flags_part(closure->time_end) & ONQUEUE;
}

int closure_compare(closure_t* closure_1,
                    closure_t* closure_2) {
  timestamp_t* start_1 = closure_time_start(closure_1);
  timestamp_t* start_2 = closure_time_start(closure_2);
  if(!start_1) return -1;
  if(!start_2) return 1;
  return totalorder_compare(start_1, start_2);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

closure_t* closure_inst(const closure_vtbl_t* vtbl) {
  closure_t* closure = 
    (closure_t*) traceobj_inst((traceobj_vtbl_t*) vtbl);
  
  closure->readmask   = 0;
  closure->time_start = NULL;
  closure->time_end   = pointer_and_flags(NULL, 0);
  
  return closure;
}

void closure_call(closure_t* closure_req) {
  state_t* state = state_curr(NULL);
  closure_t* marker = NULL;
  context_t* context_saved = state->context;
  closure_t* closure_saved = state->closure;
  closure_t* closure;

  /* Push on a marker --- then we know when to stop popping. */
  closurestk_push(&state->closurestk, marker);

  /* Run closures in sequence until there are no more left to run */
  while(closure_req) {
    closure = tracetbl_add(state->context, closure_req);
    
    if(closure == closure_req) {
      logg("fresh-call: %s\n", closure_name(closure));
      codeloc_fresh_closure(closure);
      
      closure_vtbl(closure)->traceobj_vtbl.init(closure);
      closurestk_push(&state->closurestk, closure);
      closure->time_start = timestamp_advance(TIMESTAMP_CLOSURE_BEGIN, closure);
      traceobj_make_owner(closure);
      closure_req = closure_invoke(closure);
    }
    else {
      logg("memo-match: %s\n", closure_name(closure));
      codeloc_match_closure(closure);
      
      timestamp_killall(state->time_now,
                        closure_time_start(closure));
      
      closure_propagate(closure_time_start(closure),
                        closure_time_end(closure));
      
      state->time_now = closure_time_end(closure);
      break;
    }
  }
  
  if(!closure_req)
    codeloc_null_closure();

  logg("tail-call sequence complete.");
  
  /* Pop off and assign time stamps until we hit our marker */
  while((closure = closurestk_pop(&state->closurestk)) != marker) {
    closure->time_end = timestamp_advance(TIMESTAMP_CLOSURE_END, closure);
  }
    
  /* Restore the original context */
  state->closure = closure_saved;
  context_set(context_saved);
}

closure_t* closure_invoke(closure_t* closure) {
  state_t* state = state_curr(NULL);  
  closure_vtbl_t* vtbl = closure_vtbl(closure);
  
  state->closure  = closure;

  context_set(traceobj_context((traceobj_t*) closure));
  
  logg("invoking %p", closure);
  logg("");

  return vtbl->invk(closure);
}

void closure_reinvoke(closure_t* closure) {
  state_t* state = state_curr(NULL);
  timestamp_t* time_end_0 = state->time_end;
  
  state->time_now = closure_time_start(closure);
  state->time_end = closure_time_end(closure);
  
  logg("reinvoking %s\n", closure_name(closure));
  codeloc_awoke_closure(closure);
  
  closure_call(closure_invoke(closure));
  
  timestamp_killall(state->time_now, closure_time_end(closure));

  /* Don't forget to restore the end-time !!*/
  state->time_end = time_end_0;
}

void closure_propagate(timestamp_t* start, timestamp_t* end) {
  state_t*     state      = state_curr(NULL);
  timestamp_t* time_end_0 = state->time_end;
  closure_t*   closure;

  state->time_now = start;
  state->time_end = end;

  logg("beginning");
  
  while((closure = closure_dequeue()) != NULL) {    
    closure_reinvoke(closure);
  }

  logg("done");

  /* Don't forget to restore the end-time !!*/
  state->time_end = time_end_0;
}

void closure_enqueue(closure_t* closure, read_t* read, void* new_value) {
  logg("closure=%p", closure);
  if(closure) {
    codeloc_enque_closure(closure);
    if(!closure_onqueue(closure)) {  
      state_t* state = state_curr(NULL);
      context_t* context = traceobj_context((traceobj_t*) closure);  
      closure_t* closure_rem = tracetbl_rem(context, closure);
      assert(closure == closure_rem);
      pqueue_push(&state->pqueue, closure);
      closure_kill_allocs(closure);
      closure->time_end = pointer_and_flags(closure->time_end, ONQUEUE);
    }
    if(read) {
      /* Last: Store new read value */
      read->value = new_value;
    }
  }
}

closure_t* closure_dequeue() {  
  state_t* state = state_curr(NULL);
  closure_t* closure;

  while(!pqueue_isempty(&state->pqueue) &&
        (closure = pqueue_peek(&state->pqueue))) {    
    timestamp_t* time =
      closure_time_start(closure);
    
    if(!time) {
      /* Dead closure: pop it and kill it for good.  Continue looking
         for a live closure to pop. */
      closure = pqueue_pop(&state->pqueue);
      closure->time_end = pointer_and_flags(closure->time_end, 0);
      closure_kill(closure, NULL);
      logg("popped a dead closure\n");
      continue;
    }
    else if(state->time_end &&
            totalorder_compare(state->time_end, time) <= 0) {
      /* At the end of the reuse interval -- return NULL */
      return NULL;
    }
    else {
      /* Otherwise, found a live closure to return */
      closure = pqueue_pop(&state->pqueue);
      closure->time_end = pointer_and_flags(closure->time_end, 0);
      tracetbl_put(traceobj_context((traceobj_t*)closure), (traceobj_t*) closure);
      logg("closure=%p", closure);
      return closure;      
    }
  }
  /* Queue is empty */
  return NULL;
}

/* Called by: closure_enqueue, closure_kill */
void closure_kill_allocs(closure_t* closure) {
  state_t* state = state_curr(NULL);
  traceobj_t* traceobjs;

  logg("closure=%p", closure);       
  traceobjs = traceobj_unlink((traceobj_t*) closure);
  if(traceobjs) {
    traceobj_t* traceobj = traceobjs;
    do {
      logg("killing block=%p", traceobj);
      traceobj_kill_ownee(traceobj);
      traceobj = pointer_part(traceobj->next);
    }
    while(traceobj != traceobjs);

    if(!state->deadlist)
      state->deadlist = traceobjs;
    else
      traceobj_link(traceobjs, state->deadlist, 0, 0);
  }
}

/* Called by: timestamp_killall, closure_dequeue */
void closure_kill(closure_t* closure, timestamp_t* time) {
  int safe_to_free = 0;

  if(time &&
     (assert(time == closure_time_start(closure)), 1))
  {
    closure_vtbl_t* vtbl = closure_vtbl(closure);

    if(closure_onqueue(closure)) {
      /* Mark [time_start] so it won't be reinvoked */
      closure->time_start = NULL;
    }
    else {
      /* Enqueued closures are already removed from tracetbl ---
         all others must be removed now. */
      context_t* context = traceobj_context((traceobj_t*)closure);
      closure_t* closure_rem = tracetbl_rem(context, closure);
      assert(closure == closure_rem);

      /* Enqueued closure already have their allocations killed ---
         all others are dealt with now */
      closure_kill_allocs(closure);
      
      /* Not on the queue means safe to free */
      safe_to_free = 1;
    }

    logg("closure=%p time=%p start=%p end=%p safe-to-free=%d",
         closure, time,
         closure_time_start(closure),
         closure_time_end(closure),
         safe_to_free
         );

    /* Un-initialization: After we are sure the closure has been found
       and removed from its tractbl, we can uninitialize it.  After
       this the traceobj operations [hash] and [eqiv] will no longer
       have correct behavior. */
    vtbl->uini(closure);
  }
  else if(!time) {
    /* It was enqueued, but not any more -- mark to free it. */
    logg("closure=%p time=%p", closure, time);
    safe_to_free = 1;
  }

  if(safe_to_free) {
    logg("freeing closure=%p", closure);
    traceobj_free((traceobj_t*)closure);
  }
}
