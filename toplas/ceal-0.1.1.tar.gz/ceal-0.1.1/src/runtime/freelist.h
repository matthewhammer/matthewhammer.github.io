/* Matthew A Hammer */
/* <hammer@tti-c.org */

#ifndef __SLIME_FREELIST_H__
#define __SLIME_FREELIST_H__

#include <inttypes.h>

typedef struct freelist_s freelist_t;

void  freelist_init(freelist_t* freelist, uintptr_t block_size);
void* freelist_pop(freelist_t* freelist);
void  freelist_push(freelist_t* freelist, void* ptr);


struct freelist_node_s {
  struct freelist_node_s* next;
};

typedef struct freelist_node_s freelist_node_t;

struct freelist_s {
  uintptr_t block_size;
  freelist_node_t* head;
};

#endif
