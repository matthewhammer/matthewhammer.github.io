/* Matthew Hammer <hammer@tti-c.org> */

#include <stdlib.h>
#include <assert.h>
#include "basemm.h"
#include "freeset.h"
#include "logging.h"

uintptr_t basemm_bytes_malloc = 0;
uintptr_t basemm_bytes_free = 0;
uintptr_t basemm_bytes_maxlive = 0;

#if SLIME_ENABLE_BASEMM_FREESET
static freeset_t global_freeset_ = {0,0,NULL};
freeset_t* global_freeset = &global_freeset_;
#endif

static void*
malloc_and_assert(uintptr_t size) {
  void* ptr = malloc(size);
  if(!ptr) {
    perror("malloc");
    abort();
  }
  return ptr;
}

void basemm_init() {
#if SLIME_ENABLE_BASEMM_FREESET
  {
    static int init_flag = 0;
    if(!init_flag) {
      freeset_init(global_freeset, SLIME_FREESET_MAX_BLOCK_SIZE);
      init_flag = 1;
    }
    else {
      logg("called multiple times");
    }
  }
#endif
}

void* basemm_malloc(uintptr_t size) {
#if SLIME_ENABLE_BASEMM_STATS
  basemm_bytes_malloc += size;
  if(basemm_bytes_malloc - basemm_bytes_free > basemm_bytes_maxlive) {
    basemm_bytes_maxlive = basemm_bytes_malloc - basemm_bytes_free;
  }
#endif
#if SLIME_ENABLE_BASEMM_FREESET
  if(size < SLIME_FREESET_MAX_BLOCK_SIZE) {
    return freeset_pop(global_freeset, size);
  }
  else
    return malloc_and_assert(size);
#else
  return malloc_and_assert(size);
#endif
}

void basemm_free(uintptr_t size, void* ptr) {
#if SLIME_ENABLE_BASEMM_STATS
  basemm_bytes_free += size;
#endif
#if SLIME_ENABLE_BASEMM_FREESET
  if(size < SLIME_FREESET_MAX_BLOCK_SIZE) {
    freeset_push(global_freeset, size, ptr);
  }
  else
    free(ptr);
#else
  free(ptr);
#endif
}
