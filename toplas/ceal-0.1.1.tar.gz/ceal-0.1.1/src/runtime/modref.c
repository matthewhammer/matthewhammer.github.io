/* Matthew Hammer <hammer@tti-c.org> */
/* Operations on modifiable-references (modrefs) */

#include <stdlib.h>
#include <assert.h>
#include "modref.h"
#include "basemm.h"
#include "logging.h"
#include "pointerflags.h"
#include "state.h"


ifun modref_init(modref_t* modref) {
  modref->value    = (void*) NULL;
  modref->u.events = pointer_and_flags(NULL, 0);
}

static uintptr_t
modref_isinitialized(modref_t* modref) {
  return flags_part(modref->u.events) & MODREF_INITIALIZED;
}


/* Return a timestamp for the given event based on its tag */
static timestamp_t*
modref_event_time(modref_event_t* event) {
  uintptr_t flags = flags_part(event->u.time);
  
  if(flags == MODREF_EVENT_READ) {
    return closure_time_start(pointer_part(event->u.closure));
  }
  else if(flags == MODREF_EVENT_WRITE) {
    return pointer_part(event->u.time);
  }
  else {
    abort();
  }
}

/* Insert and return a new ("blank") event between event1 and event2. */
static modref_event_t*
modref_event_insert(modref_event_t* event1,
                    modref_event_t* event2)
{
  modref_event_t* event =
    basemm_malloc(sizeof(modref_event_t));
  
  event->value  = (void*) NULL;
  event->u.uptr = (void*) NULL;

  assert(pointer_part(event1->next) == event2);
  
  event->prev  = event1;
  event1->next = pointer_and_flags(event, flags_part(event1->next));
  event->next  = event2;  
  if(event2) event2->prev = event;
  
  return event;
}

/* Remove the given event from its list. */
static modref_event_t*
modref_event_remove(modref_event_t* event) {
  modref_event_t* event1 = event->prev;
  modref_event_t* event2 = event->next;

  if(event1) event1->next = pointer_and_flags(event2, flags_part(event1->next));
  if(event2) event2->prev = event1;

  return event;
}

/* Returns one of the following:
   
   (i)  event e s.t., e is last-occuring before-or-at current time.
   (ii) the given modref, if no such e exists.

   In either case, the returned "event" can be used to insert a new
   event for the current time in the correct position.
*/
static modref_event_t*
modref_event_curr(modref_t* modref) {
  state_t*         state = state_curr(NULL);
  modref_event_t* event1 = (modref_event_t*) modref;
  modref_event_t* event2 = pointer_part(modref->u.events);
  
  while(event2 &&
        timestamp_isleq(modref_event_time(event2),
                        state->time_now)) {
    event1 = event2;
    event2 = pointer_part(event2->next);
  }

  return event1;
}

/* Enqueue each read following event0 until the next write event using
   the given new_value. */
static void
modref_enqueue_reads(modref_event_t* event0,
                     void* new_value)
{
  modref_event_t* event = pointer_part(event0->next);

  if(event) {
    uintptr_t tag;
    
    while(event &&
          (tag = flags_part(event->u.closure),
           tag == MODREF_EVENT_READ))
    {
      closure_t* closure = pointer_part(event->u.closure);
      closure_enqueue(closure, event, new_value);
      event = pointer_part(event->next);
    }
  }
}

/* Dereference the given modref wrt the current time. */
void* modref_deref(modref_t* modref) {
  modref_event_t* event;
  
  assert(modref_isinitialized(modref));
  
  event = modref_event_curr(modref);
  assert(event);
  return event->value;
}

read_t* modref_tmpread(modref_t* modref) {
  modref_event_t* event0;
  modref_event_t* event;

  /* -- find previous event */
  event0 = modref_event_curr(modref);

  /* -- insert an event after previous one */
  event = modref_event_insert(event0, pointer_part(event0->next));

  /* -- initialize event as read event --- note that we don't yet know
        the associated closure; this will be filled in via a call to
        modref_addread() */
  event->value = event0->value;
  event->u.closure = pointer_and_flags(NULL, MODREF_EVENT_READ);

  return event;
}

read_t* modref_addread(read_t* tmpread, closure_t* closure) {
  tmpread->u.closure = pointer_and_flags(closure, MODREF_EVENT_READ);
  return tmpread;
}

void modref_remread(read_t* read) {
  modref_event_remove(read);
  basemm_free(sizeof(modref_event_t), read);  
}

static int
modref_meta_check() {
  state_t* state = state_curr(NULL);
  return (state->time_now ==
          closure_time_start(state->metalvl));
}


void modref_write(modref_t* modref, void* value)
{
  modref_event_t* event0;
  modref_event_t* event;
  timestamp_t* time;
  
  /* -- Find closest previous event. */
  event0 = modref_event_curr(modref);
  
  /* -- Does new value match old value? */
  if(event0->value != value)
    modref_enqueue_reads(event0, value);
  
  /* -- Are we changing the initial value ? */
  if(event0 == (modref_event_t*) modref) {
    modref->value = value;
  }
  /* -- If not, add a timestamp and a write event. */
  else {
    event = modref_event_insert(event0, pointer_part(event0->next));
    time  = timestamp_advance(TIMESTAMP_WRITE, event);
    
    event->value  = value;
    event->u.time = pointer_and_flags(time, MODREF_EVENT_WRITE);
  }
  
  modref->u.events = pointer_add_flags(modref->u.events,
                                       MODREF_INITIALIZED);
}

void modref_remwrite(write_t* write, timestamp_t* time) {
  void* prev_value;

  if(write->prev) {
    prev_value = write->prev->value;
  }
  else {
    abort();
  }
      
  if(prev_value != write->value) {
    modref_enqueue_reads(write, prev_value);
  }

  modref_event_remove(write);
  basemm_free(sizeof(modref_event_t), write);
}
