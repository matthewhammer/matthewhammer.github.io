/* Matthew Hammer <hammer@tti-c.org> */

/* Blocks -- A case of traceobjects (see "traceobj.h") */

#ifndef __SLIME_BLOCK_H__
#define __SLIME_BLOCK_H__

#include "traceobj.h"

typedef traceobj_t block_t;
typedef traceobj_vtbl_t block_vtbl_t;

block_t*   block_inst(const block_vtbl_t* vtbl);
void*      block_alloc(block_t* block);
block_t*   block_ofptr(void* ptr);
void       block_kill(block_t* block);

void       block_comb(block_t* block_req, block_t* block_rsp);
timestamp_t* block_time(block_t* block);

#endif
