/* Matthew Hammer <hammer@tti-c.org> */
/* Operations on blocks */

#include <stdlib.h>
#include "block.h"
#include "state.h"
#include "logging.h"
#include "closure.h"

block_t* block_inst(const block_vtbl_t* vtbl) {
  return (block_t*) traceobj_inst((traceobj_vtbl_t*) vtbl);
}

void* block_alloc(block_t* block_req) {
  static block_t* finger = NULL;
  state_t* state = state_curr(NULL);  
  block_t* block = tracetbl_add(state->context, block_req);

  /* BUILD-TODO: why is the following function without a prototype? */
  traceobj_make_ownee(block);
  
  /* We always place allocations at the end of the current closure's
     allocation list.  The finger keeps track of the last fresh
     allocation performed in a nested sequence of allocations.  If the
     finger is non-NULL, it means that this allocation is nested
     within the previous one in the allocation list.  We indicate this
     with a pointer flag.
  */
  traceobj_link(block, (traceobj_t*) state->closure, 0, finger != NULL);

  logg("fresh=%d block=%p body=%p vtbl=%p finger=%p",
       (block == block_req),
       block, block + 1,
       block->vtbl, finger);

  if(block == block_req)
    codeloc_fresh_block(block);
  else
    codeloc_match_block(block);
  
  if(block == block_req) {
    block_t* saved_finger = finger;
    finger = block;
    block->vtbl->init(block);
    finger = saved_finger;
  }
  
  return (block + 1) /* return requested space */;
}

block_t* block_ofptr(void* ptr) {
  return ((block_t*) ptr) - 1;
}

void block_kill(block_t* block) {
  state_t* state = state_curr(NULL);
  traceobj_unlink(block);  
  traceobj_kill_ownee(block);

  /* BUG-FIX: The dead-list can be in one of two states.  First, it
     can be NULL, which corresponds to an empty dead-list.  Inserting
     traceobjs (linked in a loop) is then just a matter of setting the
     dead-list pointer.  Second, it can be non-NULL, in which case we
     use traceobj_link to insert a loop of traceobjs at the end of the
     current list (in O(1)).  The original bug was not
     detecting/handling the first special case. */
  if(state->deadlist) {
    traceobj_link(block, state->deadlist, 0, 0);
  }
  else {
    state->deadlist = block;
  }
}

void block_comb(block_t* block_req, block_t* block_rsp) {
  closure_t* closure = traceobj_closure(block_rsp); 
  logg("block_req=%p block_rsp=%p closure=%p",
       block_req, block_rsp, closure);
  closure_enqueue(closure, NULL, NULL);
  traceobj_unlink(block_rsp);
}

timestamp_t* block_time(block_t* block) {
  closure_t* closure = traceobj_closure(block);
  if(closure)
    return closure_time_start(closure);
  else
    return NULL;
}
