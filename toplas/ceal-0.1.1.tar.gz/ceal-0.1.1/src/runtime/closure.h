/* Matthew Hammer <hammer@tti-c.org> */

/* Closures -- A case of traceobjects (see "traceobj.h"). */

#ifndef __SLIME_CLOSURE_H__
#define __SLIME_CLOSURE_H__

typedef struct closure_vtbl_s closure_vtbl_t;

#include "traceobj.h"
#include "totalorder.h"
#include "modref.h"
#include "codeloc.h"

struct closure_vtbl_s {
  traceobj_vtbl_t traceobj_vtbl;
  closure_t* (*invk) (closure_t* closure); /* Invoke the closure */
  void       (*uini) (closure_t* closure); /* "Undoes" any reads */
};

struct closure_s {
  traceobj_t traceobj;
  uintptr_t  readmask;
  timestamp_t* time_start;
  timestamp_t* time_end;
};

closure_t*      closure_inst(const closure_vtbl_t* vtbl);
void            closure_call(closure_t* closure);

closure_vtbl_t* closure_vtbl(closure_t* closure);
const char*     closure_name(closure_t* closure);
timestamp_t*    closure_time_start(closure_t* closure);
timestamp_t*    closure_time_end(closure_t* closure);
int             closure_compare(closure_t* closure_1, closure_t* closure_2);

void            closure_enqueue(closure_t* closure, read_t* read, void* new_value);
void            closure_propagate(timestamp_t* start, timestamp_t* end);
void            closure_kill(closure_t* closure, timestamp_t* time);
void            closure_kill_allocs(closure_t* closure);

#endif
