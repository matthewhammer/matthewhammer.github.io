/* Matthew Hammer <hammer@tti-c.org> */
/* SLIME testing/profiling system */

#ifndef __SLIME_TEST_TYPES_H__
#define __SLIME_TEST_TYPES_H__

#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "../ceal.h"

/**
 * \defgroup ceal_testsys Test Harnesss
 * @{
 */

typedef struct test_params_s       test_params_t;
typedef struct test_stats_s        test_stats_t;
typedef struct test_input_hooks_s  test_input_hooks_t;
typedef struct test_output_hooks_s test_output_hooks_t;
typedef struct test_app_hooks_s    test_app_hooks_t;
typedef struct test_app_s          test_app_t;
typedef struct test_state_s        test_state_t;

#define PHASE_FROMSCRATCH "i"
#define PHASE_ALLINSREM   "p"
#define PHASE_VERIFIER    "v"
#define PHASE_CHECKRESULT "V"

typedef enum {
  TEST_FLAGVAL__FIRST,
  TEST_FLAGVAL_OFF,
  TEST_FLAGVAL_ON,
  TEST_FLAGVAL_FORCE_OFF,
  TEST_FLAGVAL_FORCE_ON,
  TEST_FLAGVAL__LAST,
} test_flagval_t;

/* -- Test Params -- */
struct test_params_s {
  const char *app_name;
  const char *phases;
  int rand_seed;
  int input_size;
  test_flagval_t print_inout;
  test_flagval_t enable_codelocs;
  test_flagval_t inout_files;

  /* rlim_max_as: resource limit for maximum virtual memory (address space)
     See: RLIMIT_AS from manpage getrlimit(2) */
  rlim_t rlim_max_as;
};

typedef struct timeval timeval_t;

/* -- Test Stats -- */
struct test_stats_s {
  stats_t   stats_begin;
  stats_t   stats_end;
  stats_t   stats_delta;

  timeval_t      time_begin;
  timeval_t      time_end;
  timeval_t      time_delta;
};

/* Input Hooks -- used to generate, print and change each of an
   application's inputs.  An iterator is provided to move through each
   "position" of the input, and forward/backward change operations
   (e.g., insert/delete in the case of a list) are provided that work
   on the current position.

   The change operations must be repeatable, but must always be done
   in pairs of forw/back.  iter_isdone indicates whether iter_next can
   be be called to retrieve the next "position" of the input.  If it
   returns non-zero, iter_next is undefined.
*/
struct test_input_hooks_s {
  modref_t*      (*generate)    (int n);
  void           (*print)       (modref_t* m, FILE* f);
  void*          (*iter_new)    (modref_t* m);
  void           (*iter_next)   (void* iter);
  int            (*iter_isdone) (void* iter);
  void           (*change_forw) (void* iter);
  void           (*change_back) (void* iter);
};

/* -- Output Hooks -- */
struct test_output_hooks_s {
  int  (*equals) (modref_t* m1, modref_t* m2);
  void (*print)  (modref_t* m, FILE* f);
};

/* -- Application Hooks -- */
struct test_app_hooks_s {
  int  (*input_hooks)  (test_input_hooks_t** hooks);
  int  (*output_hooks) (test_output_hooks_t** hooks);                        
  void (*input_sizes)  (int n, int* ns);
  void (*run)          (modref_t** inputs, modref_t** outputs);
  void (*run_verif)    (modref_t** inputs, modref_t** outputs);
};

/* -- Test Applications -- */
struct test_app_s {
  const char*       name;
  test_app_hooks_t* hooks;
};

/* -- See: ./apps/test_apps.c */
extern test_app_t* test_apps[];

/* -- Test State -- */
struct test_state_s {
#define MAX_ARITY 2

  slime_t*             slime;
  test_params_t        params;

  /* app */
  test_app_t*          app;

  /* inputs */
  int                  input_arity;
  int                  input_sizes[MAX_ARITY];
  test_input_hooks_t*  input_hooks[MAX_ARITY];
  modref_t*            inputs[MAX_ARITY];
  
  /* outputs */
  int                  output_arity;
  test_output_hooks_t* output_hooks[MAX_ARITY];
  modref_t*            outputs[MAX_ARITY];
  
  /* stats -- fromscratch */
  test_stats_t         stats_fromscratch;
  
  /* stats -- changeall */
  test_stats_t         stats_changeall;
  FILE*                codeloc_out;

  /* stats, outputs -- verify */
  test_stats_t         stats_verif;
  modref_t*            outputs_verif[MAX_ARITY];
  
#undef MAX_ARITY
};

/* @} */

#endif
