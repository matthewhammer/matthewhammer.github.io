#include <stdlib.h>
#include <string.h>

#include "ceal.h"

#include "test_types.h"
#include "test_utils.h"
#include "test_params.h"
#include "test_time.h"
#include "test_stats.h"

#include "basemm.h"

static FILE*
inout_file_open(test_state_t* test_state, const char* label, int idx) {  
  int use_inout_files = test_flagval(test_state->params.inout_files);
  static int ext = 0;
    
  if(use_inout_files) {
    return fopen(cheap_sprintf("%s_%d.%08d", label, idx, ext++), "w+");
  }
  else {
    fprintf(stderr, " %6s_%d = ", label, idx);
    return stderr;
  }  
}

static void
inout_file_close(test_state_t* test_state, FILE* file) {
  int use_inout_files = test_flagval(test_state->params.inout_files);
  if(use_inout_files) {
    fclose(file);
  }
  else {
    fflush(file);
  }
}

static void
print_input(test_state_t* test_state) {
  int i;
  slime_meta_start();
  for(i = 0; i < test_state->input_arity; i++) {
    FILE* file = inout_file_open(test_state, "input", i);
    test_state->input_hooks[i]->
      print(test_state->inputs[i], file);
    fprintf(file, "\n");
    inout_file_close(test_state, file);
  }
}

static void
print_output(test_state_t* test_state, modref_t** outputs) {
  int i;
  slime_meta_end();
  for(i = 0; i < test_state->output_arity; i++) {
    FILE* file = inout_file_open(test_state, "output", i);
    test_state->output_hooks[i]->print(outputs[i], file);
    fprintf(file, "\n");
    inout_file_close(test_state, file);
  }
}

static void
setup_inout(test_state_t* test_state) {
  int do_print_inout = test_flagval(test_state->params.print_inout);
  int i;
  
  /* -- get input hooks from app hooks */
  test_state->input_arity  =
    test_state->app->hooks->
    input_hooks(test_state->input_hooks);

  /* -- get output hooks from app hooks */
  test_state->output_arity =
    test_state->app->hooks->
    output_hooks(test_state->output_hooks);

  /* -- get input sizes (divide up the input size parameter among the inputs) */
  test_state->app->hooks->
    input_sizes(test_state->params.input_size,
                test_state->input_sizes);

  /* -- Generate each input */
  for(i = 0; i < test_state->input_arity; i++) {
    test_state->inputs[i] = test_state->input_hooks[i]->
      generate(test_state->input_sizes[i]);
  }

  /* -- Print input. */
  if(do_print_inout)
    print_input(test_state);
  
  /* -- Make a destination for each output */
  for(i = 0; i < test_state->output_arity; i++) {
    test_state->outputs[i] = modref();
    test_state->outputs_verif[i] = modref();
  }
}

static int
verifier_check(test_state_t* test_state) {
  int i;
  int result = 1;

  /* -- Compare each verifier output to the corresponding self-adjusting output. */
  slime_meta_end();
  for(i = 0; i < test_state->output_arity; i++) {
    int equals =
      test_state->output_hooks[i]->
      equals(test_state->outputs[i],
             test_state->outputs_verif[i]);
    result = result && equals;
  }
  return result;
}

static int
allinsrem(test_state_t* test_state) {
  int change_count   = 0;
  int do_print_inout = test_flagval(test_state->params.print_inout);
  int i;

  /* -- Work relative to the beginning of the computation. */
  slime_meta_start();
    
  /* -- For each input: */
  for(i = 0; i < test_state->input_arity; i++) {
    test_input_hooks_t* input_hooks = test_state->input_hooks[i];
    
    /* -- Get a new iterator */
    void* iter =
      input_hooks->
      iter_new(test_state->inputs[i]);

    /* -- For each position in this input: */
    while(!(input_hooks->iter_isdone(iter))) {
      int forw_back;
      
      /* -- Change forward then backward. */
      for(forw_back = 0; forw_back < 2; forw_back++) {
        change_count += 1;
        
        if(forw_back == 0) {
          input_hooks->change_forw(iter);
        }
        else if(forw_back == 1) {
          input_hooks->change_back(iter);
        }
        else { abort(); }
        
        /* -- Print changed input. */
        if(do_print_inout) {
          print_input(test_state);
        }

        /* -- Propagate. */
        codeloc_begin(test_state->codeloc_out);
        slime_propagate();
        codeloc_end();
        
        /* -- Print changed output. */
        if(do_print_inout) {
          print_output(test_state, test_state->outputs);
        }
        
        slime_meta_start();
      }
      
      /* -- Next input position. */
      input_hooks->iter_next(iter);
    }    
  }
  return change_count;
}

static void
print_basemm_stats(const char* prefix) {
  
  printf("%s/all-malloc-bytes: %llu (%s)\n", prefix,
         (unsigned long long) basemm_bytes_malloc,
         string_of_size(2, basemm_bytes_malloc));

  printf("%s/all-free-bytes: %llu (%s)\n", prefix,
         (unsigned long long) basemm_bytes_free,
         string_of_size(2, basemm_bytes_free));

  printf("%s/all-maxlive-bytes: %llu (%s)\n", prefix,
         (unsigned long long) basemm_bytes_maxlive,
         string_of_size(2, basemm_bytes_maxlive));
}

static void
phase_fromscratch(test_state_t* test_state) {
  int do_print_inout = test_flagval(test_state->params.print_inout);
  const char* prefix = ">> fromscratch";
  test_stats_t* stats = &test_state->stats_fromscratch;
  fprintf(stderr, "%s: beginning from-scratch run.\n",  __FUNCTION__);
  slime_stats_save(&stats->stats_begin, slime_stats_curr());
  time_save(&stats->time_begin);

  /* -- Run the (self-adjusting) application */  
  test_state->app->hooks->
    run(test_state->inputs,
        test_state->outputs);  
  
  time_save(&stats->time_end);
  time_diff(&stats->time_delta, &stats->time_end, &stats->time_begin);
  slime_stats_save(&stats->stats_end, slime_stats_curr());
  slime_stats_diff(&stats->stats_delta, &stats->stats_end, &stats->stats_begin);
  fprintf(stderr, "%s: from-scratch run complete.\n",  __FUNCTION__);

  /* -- Print output. */
  if(do_print_inout)
    print_output(test_state, test_state->outputs);
  
  printf("%s/time: %g (%s)\n", prefix,
         time_as_double(&stats->time_delta),
         time_as_string(&stats->time_delta)
         );
  
  print_basemm_stats(prefix);
}

static void
phase_allinsrem(test_state_t* test_state) {
  const char* prefix = ">> allinsrem";
  float divisor;    
  test_stats_t* stats = &test_state->stats_changeall;
  
  /* TEMP: move this somewhere reasonable? */
  if(test_flagval(test_state->params.enable_codelocs)) {
    test_state->codeloc_out = fopen("codeloc.log", "w+");
  } else {
    test_state->codeloc_out = NULL;
  }      
  
  fprintf(stderr, "%s: beginning changes.\n",  __FUNCTION__);
  slime_stats_save(&stats->stats_begin, slime_stats_curr());
  time_save(&stats->time_begin);
  
  divisor = allinsrem(test_state);
  
  time_save(&stats->time_end);
  time_diff(&stats->time_delta, &stats->time_end, &stats->time_begin);
  slime_stats_save(&stats->stats_end, slime_stats_curr());
  slime_stats_diff(&stats->stats_delta, &stats->stats_end, &stats->stats_begin);
  fprintf(stderr, "%s: all changes complete.\n", __FUNCTION__);
  
  printf("%s/time-sum: %g (%s for %d updates)\n",
         prefix,
         time_as_double(&stats->time_delta),
         time_as_string(&stats->time_delta),
         (int) divisor);
  
  printf("%s/time-ave: %g (ave over %d updates)\n",
         prefix, time_as_double(&stats->time_delta) / divisor,
         (int) divisor
         );
  
  test_stats_print(stats, prefix, divisor);
  print_basemm_stats(prefix);
}

static void
phase_verifier(test_state_t* test_state) {
  int do_print_inout = test_flagval(test_state->params.print_inout);
  const char* prefix = ">> verifier";
  test_stats_t* stats = &test_state->stats_verif;
  int result_check;

  /* -- Print input. */
  if(do_print_inout)
    print_input(test_state);
  
  fprintf(stderr, "%s: beginning verifier run.\n",  __FUNCTION__);
  slime_stats_save(&stats->stats_begin, slime_stats_curr());
  time_save(&stats->time_begin);

  /* -- Run the application's verifier.
     -- this is a non-tracing, non-reusing (i.e., static) version. */
  slime_meta_start();
  test_state->app->hooks->
    run_verif(test_state->inputs,
              test_state->outputs_verif);
  
  time_save(&stats->time_end);
  time_diff(&stats->time_delta, &stats->time_end, &stats->time_begin);
  slime_stats_save(&stats->stats_end, slime_stats_curr());
  slime_stats_diff(&stats->stats_delta, &stats->stats_end, &stats->stats_begin);
  fprintf(stderr, "%s: verifier run complete.\n",  __FUNCTION__);
  
  printf("%s/time: %g (%s)\n", prefix,
         time_as_double(&stats->time_delta),
         time_as_string(&stats->time_delta)
         );

  /* -- Print output. */
  if(do_print_inout)
    print_output(test_state, test_state->outputs_verif);
  
  print_basemm_stats(prefix);
}

static void
phase_checkresult(test_state_t* test_state) {
  const char* prefix = ">> verifier";
  int result_check;
  
  fprintf(stderr, "%s: checking verifier result.\n",  __FUNCTION__);
  result_check = verifier_check(test_state);
  fprintf(stderr, "%s: check complete.\n",  __FUNCTION__);
  
  printf("%s/check: %d (%s)\n", prefix,
         result_check,
         result_check ? "passed" : "failed");
}

/* -- This is the main application-testing routine.  */
void test_app(test_state_t* test_state) {
  const char* phase = NULL; 

  setup_inout(test_state);

  printf(">> input-size : %llu (%s)\n",
         (unsigned long long) test_state->params.input_size,
         string_of_size(10, test_state->params.input_size)
         );

  for(phase = test_state->params.phases;
      phase[0] != 0;
      phase ++) {
    if(!strncmp(PHASE_FROMSCRATCH, phase, 1)) {
      phase_fromscratch(test_state);
    }
    else if(!strncmp(PHASE_ALLINSREM, phase, 1)) {
      phase_allinsrem(test_state);
    }
    else if(!strncmp(PHASE_VERIFIER, phase, 1)) {
      phase_verifier(test_state);
    }
    else if(!strncmp(PHASE_CHECKRESULT, phase, 1)) {
      phase_checkresult(test_state);
    }    
    else {
      fprintf(stderr, "don't know what phase this is: %c\n", phase[0]);      
    }
  }
}
