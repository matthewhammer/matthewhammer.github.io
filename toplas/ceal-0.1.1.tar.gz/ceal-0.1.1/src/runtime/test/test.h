/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __CEAL_TEST__
#define __CEAL_TEST__

#include "test_types.h"
#include "test_params.h"
#include "test_utils.h"
#include "test_stats.h"

void test_app(test_state_t* test_state);

#endif
