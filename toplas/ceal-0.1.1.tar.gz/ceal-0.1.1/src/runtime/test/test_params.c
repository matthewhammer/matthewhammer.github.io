#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "ceal.h"
#include "test_params.h"
#include "test_time.h"

const char* test_flagval_name(test_flagval_t flagval) {
  static const char* flagval_names[] = {
    "(first)", "off", "on", "force-off", "force-on", "(last)"
  };
  assert(flagval > TEST_FLAGVAL__FIRST);
  assert(flagval < TEST_FLAGVAL__LAST);
  return flagval_names[flagval];
}

int test_flagval(test_flagval_t flagval) {
  return (flagval == TEST_FLAGVAL_ON ||
          flagval == TEST_FLAGVAL_FORCE_ON);
}

void test_params_print(test_params_t* test_params, FILE* f) {
  const char* fmt_int = "test-params: %15s = %d\n";
  const char* fmt_lng = "test-params: %15s = %ld\n";
  const char* fmt_flg = "test-params: %15s = %s\n";
  const char* fmt_str = "test-params: %15s = %s\n";

  fprintf(f, fmt_str, "app",               test_params->app_name ? test_params->app_name : "(default)" );
  fprintf(f, fmt_flg, "phases",            test_params->phases);
  fprintf(f, fmt_int, "rand_seed",         test_params->rand_seed);
  fprintf(f, fmt_lng, "rlim-max-as",       test_params->rlim_max_as);
  fprintf(f, fmt_int, "input-size",        test_params->input_size);
  fprintf(f, fmt_flg, "print-inout",       test_flagval_name(test_params->print_inout));
  fprintf(f, fmt_flg, "inout-files",       test_flagval_name(test_params->inout_files));
}

void test_params_default(test_params_t* test_params) {
  test_params->app_name          = NULL;
  test_params->phases            = (PHASE_FROMSCRATCH
                                    PHASE_ALLINSREM
                                    PHASE_VERIFIER
                                    PHASE_CHECKRESULT);
  test_params->rand_seed         = -1;
  test_params->input_size        = 10;
  test_params->print_inout       = TEST_FLAGVAL_OFF;
  test_params->inout_files       = TEST_FLAGVAL_OFF;
  test_params->enable_codelocs   = TEST_FLAGVAL_OFF;
  test_params->rlim_max_as       = RLIM_INFINITY;
}

int test_params__get_argv_int(char** argv, int argc, int argi) {
  if(argi >= argc) {
    fprintf(stderr, "expected an integer after %s\n", argv[argi-1]);
    exit(-1);
  }    
  return atoi(argv[argi]);
}

char* test_params__get_argv_string(char** argv, int argc, int argi) {
  if(argi >= argc) {
    fprintf(stderr, "expected a string after %s\n", argv[argi-1]);
    exit(-1);
  }    
  return argv[argi];
}

int test_params_from_argv(test_params_t* test_params,
                          int argc, char** argv) {
  int i;
  for(i = 1; i < argc; i++) {
    char* arg = argv[i];
    if(!strncmp("-actk", arg, 5) ||
       !strncmp("+actk", arg, 5)) {
      return i;
    }
    if(!strcmp("-app", arg)) {
      char* name = test_params__get_argv_string(argv, argc, ++i);
      test_params->app_name = name;
    }
    else if(!strcmp("-list-apps", arg)) {
      test_app_listall(stdout, "", " ", "\n");
      exit(0);
    }
    else if(!strcmp("-input-size", arg)) {
      test_params->input_size =
        test_params__get_argv_int(argv, argc, ++i);
    }
    else if(!strcmp("-phases", arg)) {
      char* phases = test_params__get_argv_string(argv, argc, ++i);
      test_params->phases = phases;
    }
    else if(!strcmp("-print-inout", arg)) {
      test_params->print_inout = TEST_FLAGVAL_FORCE_ON;
    }
    else if(!strcmp("+print-inout", arg)) {
      test_params->print_inout = TEST_FLAGVAL_FORCE_OFF;
    }
    else if(!strcmp("-inout-files", arg)) {
      test_params->print_inout = TEST_FLAGVAL_ON;
      test_params->inout_files = TEST_FLAGVAL_FORCE_ON;
    }
    else if(!strcmp("+inout-files", arg)) {
      test_params->inout_files = TEST_FLAGVAL_FORCE_OFF;
    }
    else if(!strcmp("-enable-codelocs", arg)) {
      test_params->enable_codelocs = TEST_FLAGVAL_FORCE_ON;
    }
    else if(!strcmp("-srand", arg)) {
      int seed;
      char* srand_val;

      /* First try to get the random seed as a string, see if its a
         special value (e.g., "time") */        
      srand_val = test_params__get_argv_string(argv, argc, ++i);
      
      if(!strcmp(srand_val, "time") ||
         !strcmp(srand_val, "clock")) {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        seed = tv.tv_usec;        
      }
      else {
        /* Instead of seeding by clock, use the specified seed (an int) */
        seed = test_params__get_argv_int(argv, argc, i);
      }
      srand(seed);
      test_params->rand_seed = seed;
    }
    else if(!strcmp("-rlim-max-as", arg)) {
      rlim_t megabytes = test_params__get_argv_int(argv, argc, ++i);
      rlim_t bytes = megabytes << 20;
      struct rlimit setrlimit_arg = {bytes, bytes};
      int retval = setrlimit(RLIMIT_AS, &setrlimit_arg);
      test_params->rlim_max_as = bytes;
      if(retval != 0) {
        perror("setrlimit");
        exit(EXIT_FAILURE);
      }
    }    
    else {
      fprintf(stderr, __FILE__":"__FUNCTION__": argument not recognized: %s\n", arg);
      exit(EXIT_FAILURE);
    }
  }
  return i;
}

