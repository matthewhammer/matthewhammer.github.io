#include "test_stats.h"
#include "test_utils.h"
#include "test_time.h"

void static print_divided(test_stats_t* stats,
                          const char* prefix,
                          const char* suffix,
                          int divisor)
{
  /* TODO */
  
/*   float divisorf = (float) divisor; */
  
/*   printf("%s-time%s = %g\n", prefix, suffix, */
/*          time_as_double(&stats->time_delta)); */
  
/*   printf("%s-closure_wakeup%s = %g\n", prefix, suffix, */
/*          stats->stats_delta.entries[ACTK_STATS_PROP_QUEUEPOP].val / divisorf); */
  
/*   printf("%s-closure_init%s = %g\n", prefix, suffix, */
/*          stats->stats_delta.entries[ACTK_STATS_CLOSURE_INIT].val / divisorf); */

/*   printf("%s-closure_enter%s = %g\n", prefix, suffix, */
/*          stats->stats_delta.entries[ACTK_STATS_CLOSURE_ENTER].val / divisorf); */
    
/*   printf("%s-closure_invalidate%s = %g\n", prefix, suffix, */
/*          stats->stats_delta.entries[ACTK_STATS_CLOSURE_INVALIDATE].val / divisorf); */
  
/*   printf("%s-closure-cost%s = %g\n", prefix, suffix, */
/*          (stats->stats_delta.entries[ACTK_STATS_CLOSURE_ENTER].val + */
/*           stats->stats_delta.entries[ACTK_STATS_CLOSURE_INVALIDATE].val) */
/*          / divisorf); */
}


void test_stats_print(test_stats_t* stats, const char* prefix, int divisor) {
  /*
  if(divisor > 0) {
    print_divided(stats, prefix, "-sum", 1);
    print_divided(stats, prefix, "-ave", divisor);
  }
  else {
    print_divided(stats, prefix, "", 1);
  }
  */

  /*
  print_size(stdout, strapp2(prefix, "-space-maxlive"),
             stats->stats_end.entries[ACTK_STATS_TOTAL_MAXLIVE].val);
  */
}
