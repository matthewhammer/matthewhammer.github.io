#include "test_types.h"

void test_stats_print(test_stats_t* stats, const char* prefix, int divisor);
