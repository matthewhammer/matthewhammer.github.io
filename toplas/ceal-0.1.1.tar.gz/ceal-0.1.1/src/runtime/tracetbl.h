/* Matthew Hammer <hammer@tti-c.org> */

/* Trace Lookup Table -- A lookup table for trace objects
   (heap-allocated blocks and closures).  See "traceobj.h" for more
   information about trace objects. */

#ifndef __SLIME_TRACETBL_H__
#define __SLIME_TRACETBL_H__

typedef struct tracetbl_s tracetbl_t;

#include <inttypes.h>
#include "traceobj.h"

tracetbl_t*  tracetbl_init(tracetbl_t* tracetbl);
traceobj_t*  tracetbl_add(tracetbl_t* tracetbl, traceobj_t* traceobj);
void         tracetbl_put(tracetbl_t* tracetbl, traceobj_t* traceobj);
traceobj_t*  tracetbl_rem(tracetbl_t* tracetbl, traceobj_t* traceobj);

#if 0
traceobj_t** tracetbl_get(tracetbl_t* tracetbl, traceobj_t* traceobj);
void         tracetbl_mov(tracetbl_t* tracetbl, traceobj_t** slot);
#endif

struct tracetbl_s {
  traceobj_t** objs;
  uintptr_t size;
  uintptr_t num;
};

#endif
