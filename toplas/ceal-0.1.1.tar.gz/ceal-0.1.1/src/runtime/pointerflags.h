/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __SLIME_POINTER_FLAGS__
#define __SLIME_POINTER_FLAGS__

#include <inttypes.h>

#define FLAG_MASK ((uintptr_t)3)
#define PTR_MASK (~FLAG_MASK)

static void*
pointer_part(void* ptr) {
  return (void*)((uintptr_t)ptr & PTR_MASK);
}

static uintptr_t
flags_part(void* ptr) {
  return ((uintptr_t)ptr) & FLAG_MASK;
}

static void*
pointer_and_flags(void* ptr, uintptr_t flags) {
  return (void*)( ((uintptr_t) ptr & PTR_MASK) |
                  (FLAG_MASK & flags) );
}

static void*
pointer_add_flags(void* ptr, uintptr_t flags) {
  return pointer_and_flags(ptr, flags_part(ptr) | flags);
}

static void*
pointer_rem_flags(void* ptr, uintptr_t flags) {
  return pointer_and_flags(ptr, flags_part(ptr) & ~flags);
}

#endif
