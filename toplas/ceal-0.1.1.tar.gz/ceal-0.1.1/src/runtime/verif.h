/* Matthew Hammer <hammer@tti-c.org> */
#ifndef __SLIME_VERIF__
#define __SLIME_VERIF__

#include "modref.h"

/* The elaborator replaces appearences of __ISVERIF__ with either
   non-zero or zero depending on if it appears in a verifier or
   non-verifier function, respectively */
extern int __ISVERIF__;

/* The elaborator replaces "verif(f)" with the verifier for
   self-adjusting function f. */
#define verif(f) ((void* __attribute__((slime_verif)))(f))

/* Blocks (allocation) */
void* verif_block_alloc(uintptr_t size);

/* Modrefs */
void  verif_modref_init(modref_t* m);
void* verif_modref_read(modref_t* m);
void  verif_modref_write(modref_t* m, void* val);

#endif
