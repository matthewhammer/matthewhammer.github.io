/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __SLIME_HASH_H__
#define __SLIME_HASH_H__

#include <inttypes.h>
#include <stdint.h>

/* Figure out the size of a machine word. */
#if (defined(__i386__))
#define SLIME_HASH_BITS 32
#include "hash_util32.h"

#elif (defined(__x86_64__))
#define SLIME_HASH_BITS 64
#include "hash_util64.h"

#else
#error "Unrecognized machine"
#endif

/* The following routines are customized statically for the word-size
   of the machine. */

uintptr_t
hash_oneword(uintptr_t word);

uintptr_t
hash_buffer(unsigned char* bytes,
            uintptr_t bytec,
            uintptr_t hashin);

#endif
