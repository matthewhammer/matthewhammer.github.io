/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __SLIME_STATE_H__
#define __SLIME_STATE_H__

typedef struct state_s state_t;

#include "codeloc.h"
#include "traceobj.h"
#include "closurestk.h"
#include "totalorder.h"
#include "pqueue.h"

state_t*  state_init(state_t* state);
state_t*  state_curr(state_t* state);
void      state_uini(state_t* state);

typedef struct deadlist_s {
  traceobj_t* next;
  traceobj_t* prev;
} deadlist_t;

struct state_s {
  pqueue_t     pqueue;     /* Priority queue -- holds affected closures. */
  closurestk_t closurestk; /* Closure stack -- for assigning end-times. */
  deadlist_t*  deadlist;   /* Dead-list -- tracks dead allocations */
  codeloc_t*   codeloc;    /* Current code location -- See "codeloc.h" */
  context_t*   context;    /* Current context -- See "context.h" */
  closure_t*   metalvl;    /* "Meta-Level" "closure" -- simplifies a few things */
  closure_t*   closure;    /* Current closure -- See "closure.h" */
  timestamp_t* time_now;   /* Current time. */
  timestamp_t* time_end;   /* Used for propagation only.  NULL otherwise. ---
                              Currently this can be (and is) used to test for
                              "propagation mode". */
};

#endif
