#include "closurestk.h"
#include <stdlib.h>


static void
closurestk_moveto_allempty(closurestk_t* closurestk) {
  closurestk_chunk_t* chunk = closurestk->nonempty;
  closurestk->nonempty = chunk->hdr.tail;
  chunk->hdr.tail = closurestk->allempty;
  closurestk->allempty = chunk;
}

static void
closurestk_moveto_nonempty(closurestk_t* closurestk) {
  closurestk_chunk_t* chunk = closurestk->allempty;

  if(chunk) {
    closurestk->allempty = chunk->hdr.tail;
  }
  else {
    chunk = malloc(sizeof(closurestk_chunk_t));
    chunk->hdr.num = 0;
  }
  
  chunk->hdr.tail = closurestk->nonempty;
  closurestk->nonempty = chunk;
}


closurestk_t* closurestk_init(closurestk_t* closurestk) {
  closurestk->nonempty = NULL;
  closurestk->allempty = NULL;
  return closurestk;
}

closure_t* closurestk_push(closurestk_t* closurestk, closure_t* closure) {
  closurestk_chunk_t* chunk = closurestk->nonempty;

  if(!chunk || chunk->hdr.num == CHUNK_SIZE) {
    closurestk_moveto_nonempty(closurestk);
    return closurestk_push(closurestk, closure);
  }
  else {  
    chunk->objs[chunk->hdr.num ++] = closure;
    return closure;
  }
}

closure_t* closurestk_pop(closurestk_t* closurestk) {
  closurestk_chunk_t* chunk = closurestk->nonempty;
  
  if(chunk) {  
    if(chunk->hdr.num == 0) {
      closurestk_moveto_allempty(closurestk);
      return closurestk_pop(closurestk);
    }
    else {
      return chunk->objs[-- chunk->hdr.num];
    }
  }
  else {
    return NULL;
  }
}
