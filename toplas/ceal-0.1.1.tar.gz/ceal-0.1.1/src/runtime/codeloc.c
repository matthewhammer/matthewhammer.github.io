/* Matthew Hammer <hammer@tti-c.org> */
#include <stdlib.h>
#include <stdio.h>
#include "codeloc.h"
#include "state.h"
#include "closure.h"

#if SLIME_ENABLE_CODELOCS

static FILE* codeloc_out = NULL;

codeloc_t*
codeloc_curr(codeloc_t* codeloc) {
  state_t* state = state_curr(NULL);
  codeloc_t* codeloc0 = state->codeloc;
  if(codeloc) state->codeloc = codeloc;
  return codeloc0;
}

void codeloc_begin(FILE* f) {  
  codeloc_out = f;
  if(codeloc_out)
    fprintf(codeloc_out, "begin\n");
}

void codeloc_end(void) {
  if(codeloc_out)
    fprintf(codeloc_out, "end\n\n");
}

static void
codeloc_curr_print() {
  codeloc_t* codeloc = codeloc_curr(NULL);  
  fprintf(codeloc_out, "%s:%d", codeloc->func, codeloc->line);
}

static void
codeloc_edge(const char* source_label,
             const char* target_label,
             const char* target_name)
{
  if(codeloc_out) {
    codeloc_curr_print();
    fprintf(codeloc_out,
            " %s %s:%s\n",
            source_label,
            target_label,
            target_name);
  }
}

static void
codeloc_closure_edge(const char* source_label,
                     const char* target_label,
                     closure_t*  target_closure)
{  
  const char* target_name = 
    closure_vtbl(target_closure)->
    traceobj_vtbl.name(target_closure);
  
  codeloc_edge(source_label,
               target_label,
               target_name);
}

static void
codeloc_block_edge(const char* source_label,
                   const char* target_label,
                   block_t*    target_block)
{  
  const char* block_name =
    target_block->vtbl->name(target_block);
  
  codeloc_edge(source_label,
               target_label,
               block_name);
}

void codeloc_fresh_closure(closure_t* closure) {
  codeloc_closure_edge("call", "fresh", closure);
}

void codeloc_match_closure(closure_t* closure) {
  codeloc_closure_edge("call", "match", closure);
}

void codeloc_enque_closure(closure_t* closure) {
  codeloc_closure_edge("write", "awoke", closure);
}

void codeloc_awoke_closure(closure_t* closure) {
  codeloc_closure_edge("deque", "awoke", closure);
}

void codeloc_null_closure() {
  codeloc_edge("return", "-", "-");
}

void codeloc_fresh_block(block_t* block) {
  codeloc_block_edge("alloc", "fresh", block);
}

void codeloc_match_block(block_t* block) {
  codeloc_block_edge("alloc", "match", block);
}

#else
/* The following stubs should be eliminated through inlining wherever
   they are called, assuming whole-program compilation. */
   
codeloc_t* codeloc_curr(codeloc_t* codeloc) { return NULL; }

void codeloc_begin(FILE* f) {}
void codeloc_end(void) {}

void codeloc_fresh_closure(closure_t* closure) {}
void codeloc_match_closure(closure_t* closure) {}
void codeloc_enque_closure(closure_t* closure) {}
void codeloc_awoke_closure(closure_t* closure) {}
void codeloc_null_closure() {}

void codeloc_fresh_block(block_t* block) {}
void codeloc_match_block(block_t* block) {}

#endif
