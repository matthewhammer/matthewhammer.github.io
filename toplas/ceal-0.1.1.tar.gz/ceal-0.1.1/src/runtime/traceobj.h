/* Matthew Hammer <hammer@tti-c.org> */

/* Trace Objects -- Generalize both closures and heap-allocated blocks
   regarding support for recording, matching and reuse within the
   lookup tables of the trace.
   
   I use an explicit virtual-table approach to implement these in lieu
   of class support in C (recall that CIL doesn't currently support
   C++ programs).  For object-oriented people disgusted with my use of
   C, just think of traceobj_vtbl_t has specifying the signature of a
   class and traceobj_t as specifying the layout of the instances.
*/

#ifndef __SLIME_TRACEOBJ_H__
#define __SLIME_TRACEOBJ_H__

typedef union  traceobj_owner_u traceobj_owner_t;
typedef struct traceobj_s       traceobj_t;
typedef struct traceobj_vtbl_s  traceobj_vtbl_t;

/* Closures -- full definition in "closure.h" */
typedef struct closure_s closure_t;

/* Contexts -- full definition in "context.h" */
typedef struct context_s context_t;

#include <inttypes.h>
#include "tracetbl.h"
#include "timestamp.h"
#include "hash.h"

struct traceobj_vtbl_s {
  /* Pre-init stage: */
  const char*(*name) (traceobj_t* traceobj); /* A name for debugging */
  uintptr_t  (*size) (traceobj_t* traceobj); /* Total size in bytes */
  uintptr_t  (*sing) (traceobj_t* traceobj); /* Non-zero iff a singleton equiv-class */
  uintptr_t  (*buff) (traceobj_t* traceobj, unsigned char* buff); /* Fill buffer with bytes respecting equiv. */
  uintptr_t  (*hash) (traceobj_t* traceobj, uintptr_t hashin); /* Hash value, respecting equivalence */
  uintptr_t  (*eqiv) (traceobj_t* traceobj_1, traceobj_t* traceobj_2); /* Define equiv-class */
  timestamp_t* (*time) (traceobj_t* traceobj); /* Time in the timeline */
  
  /* Initialization. */
  void (*init) (traceobj_t* traceobj);

  /* Asymmetric way of combining equiv traceobjects.  The first is one
     requested by running code (but still uninitialized), and the
     second is from a reusable portion of the trace (and has thus been
     previously initialized). */
  void (*comb) (traceobj_t* traceobj_req, traceobj_t* traceobj_rsp);
};


/* The "immediate owner" (or just "owner" for short) of a live block
   is an executing/executed closure.  The immediate owner of a dead
   block is a reuse context.

   Side Note: The immediate owner of an executed closure (live in the
   timeline) is still a strange notion and we currently don't support
   it.  If that closure is never mentioned explicitly in the surface
   code (e.g., never bound to a name) we can safely treat it as if the
   timeline is the closure's owner.  On the other hand, if we allow
   first-class closures then we'll have to worry about having both an
   owner and a context (which won't ordinary be the same thing unless
   the closure is dead).
*/
union traceobj_owner_u {
  context_t* context; /* use if dead block or live-exec closure, mask low bits */
  closure_t* closure; /* use if live block or live-susp closure, mask low bits */
  uintptr_t flags;
  /*
    Flags:
    bit 0: isalive= 1 (treat next/prev as also alive) or 0 (treat next/prev as also dead)
    bit 1: isowner= 1 (next/prev are "children") or 0 (next/prev are "siblings")

    Define: CONTEXT(traceobj) =
      if not isalive then context
      else if isowner then context
      else closure->context

    Define: OWNER(traceobj) =
      if not isalive then NULL
      else if isowner then NULL
      else closure

    Define: TIME(traceobj) =
      let owner = OWNER(traceobj) in
      if owner then owner->begtime
      else End-of-Timeline    
  */
};

struct traceobj_s {
  traceobj_vtbl_t* vtbl;
  traceobj_owner_t owner;
  traceobj_t* next;
  traceobj_t* prev;
  void* body[0];
};

/* Always returns 0 */
uintptr_t traceobj_sing_false(traceobj_t* traceobj); 

/* Always returns non-zero */
uintptr_t traceobj_sing_true(traceobj_t* traceobj); 

/* Instantiate a traceobj given its vtbl. -- TODO: in the future this
   should also take a size parameter since the size op in the vtbl
   requires an instance to run. */
traceobj_t* traceobj_inst(const traceobj_vtbl_t* vtbl); 

/* Non-zero iff live */
uintptr_t   traceobj_isalive(traceobj_t* traceobj); 

/* Non-zero iff is an owner */
uintptr_t   traceobj_isowner(traceobj_t* traceobj); 

/* Get context of traceobj -- result shouldn't be NULL. */
context_t* traceobj_context(traceobj_t* traceobj); 

/* Get owning closure of traceobj -- result may be NULL. */
closure_t* traceobj_closure(traceobj_t* traceobj); 

/* Set the given traceobj as live -- updates context as current
   context, sets isowner flag to true. */
void traceobj_make_owner(traceobj_t* traceobj);

/* Set the given traceobj as live -- updates owner as current closure,
   sets isowner flag to false. */
void traceobj_make_ownees(traceobj_t* traceobj);

/* Clears the islive flag -- changes the owner to the context of the
   former owner. */
void traceobj_kill_ownee(traceobj_t* traceobj);


/* Insert the first traceobj sequence after the second.  Both are
   assumed to start as loops.  The flag arguments control the SEQCONT
   bits of the links that are created between the joined
   sequences. The flag [flag_A_B] toggles the flag on
   [last(traceobjs_A)->next] and the flag [flag_B_A] toggles the flag
   on [last(traceobjs_B)->next]. */
void traceobj_link(traceobj_t* traceobjs_A,   
                   traceobj_t* traceobjs_B,
                   uintptr_t flag_A_B,
                   uintptr_t flag_B_A);

/* Remove the sequence of traceobjs given the first one (may be a
   singleton sequence).  Returns the first traceobj after the removed
   sequence, if any.  If the unlinked sequence is the only sequence,
   it returns NULL. */
traceobj_t* traceobj_unlink(traceobj_t* traceobjs);

 /* Free traceobj (reclaim to freeset) -- it should be freed only when
    it is certain to be dead (e.g., at the end of a change
    propagation). */
void traceobj_free(traceobj_t* traceobj);

#endif
