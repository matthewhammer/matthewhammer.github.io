/* Matthew A Hammer <hammer@tti-c.org */
/* Base Memory Management -- explicit, non-moving memory management,
   optimized for lots of small objects. */

#ifndef __SLIME_BASEMM_H__
#define __SLIME_BASEMM_H__

#include <inttypes.h>

extern uintptr_t basemm_bytes_malloc;
extern uintptr_t basemm_bytes_free;
extern uintptr_t basemm_bytes_maxlive;

void  basemm_init();
void* basemm_malloc(uintptr_t size);
void  basemm_free(uintptr_t size, void* ptr);

#endif
