/* Matthew Hammer <hammer@tti-c.org> */
/* Meta operations on SLIME computation */

#include <assert.h>
#include <stdlib.h>
#include "langmeta.h"
#include "basemm.h"
#include "state.h"
#include "logging.h"
#include "pointerflags.h"

slime_t* slime_open(void) {
  basemm_init();
  {
    state_t* state = basemm_malloc(sizeof(state_t));
    state_init(state);
    state_curr(state);
    return state;
  }
}

slime_t* slime_current(void) {
  return state_curr(NULL);
}

void slime_switch(slime_t* slime) {
  state_curr(slime);
}

static void
free_the_dead(void) {
  state_t* state = state_curr(NULL);
  int pass;

  for(pass = 0; pass < 2; pass++) {
    traceobj_t* dead = state->deadlist;
    while(dead) {
      traceobj_t* next = pointer_part(dead->next);

      switch(pass) {
      case 0: {
#if 0
        /* BUG (sort of--the assertion is buggy, not necessarily the
           code): This assertion doesn't always hold.  Consider a
           nested allocation.  Say l_2 is allocated under l_1.  Now
           say l_1 is killed.  Then l_2 will be killed, but its
           liveness flag won't be changed. */
        
        /* See: block_kill */
        assert(traceobj_isalive(dead) == 0);
#endif
        
        traceobj_t* result = tracetbl_rem(traceobj_context(dead), dead);
        assert(result == dead);
        break;
      }

      case 1:
        traceobj_free(dead);
        break;
      }
      
      dead = next;
      if(next == state->deadlist)
        break;
    }
  }

  state->deadlist = NULL;
}

void slime_kill(void* ptr) {
  block_kill(block_ofptr(ptr));
}


void slime_propagate(void) {  
  state_t* state = state_curr(NULL);
  closure_t* metalvl = state->metalvl;
  logg("beginning");
  closure_propagate(closure_time_start(metalvl),
                    closure_time_end(metalvl));
  logg("freeing the dead");
  free_the_dead();
  logg("done");
  slime_meta_end();
}


void slime_close(slime_t* slime) {
  /* TODO */
}


void slime_meta_start(void) {
  state_t* state = state_curr(NULL);
  closure_t* metalvl = state->metalvl;
  state->closure = metalvl;
  state->context = NULL;
  state->time_now = closure_time_start(metalvl);
}

void slime_meta_end(void) {
  state_t* state = state_curr(NULL);
  closure_t* metalvl = state->metalvl;
  state->closure = metalvl;
  state->context = NULL;
  state->time_now = closure_time_end(metalvl);
}

int slime_meta_check(void) {
  state_t* state = state_curr(NULL);
  closure_t* metalvl = state->metalvl;

  if(state->closure == metalvl &&
     state->context == NULL) {
    if(state->time_now == closure_time_start(metalvl)) {
      return -1;
    }
    else if(state->time_now == closure_time_end(metalvl)) {
      return 1;
    }
    else {
      abort();
    }    
  }
  else
    return 0;  
}
