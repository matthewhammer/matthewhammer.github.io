/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __SLIME_MODREF_H__
#define __SLIME_MODREF_H__

typedef struct modref_event_s modref_event_t;
typedef modref_event_t read_t;
typedef modref_event_t write_t;

#include "ceal.h"
#include "traceobj.h"
#include "timestamp.h"
#include "closure.h"

ifun    modref_init(modref_t* modref);

void*   modref_deref(modref_t* modref);
read_t* modref_tmpread(modref_t* modref);
read_t* modref_addread(read_t* tmpread, closure_t* closure);
void    modref_remread(read_t* read);

void    modref_write(modref_t* modref, void* val);
void    modref_remwrite(write_t* write, timestamp_t* time);

typedef enum modref_event_tag_e {
  MODREF_EVENT_READ,
  MODREF_EVENT_WRITE,
} modref_event_tag_t;

typedef enum modref_tag_e {
  MODREF_INITIALIZED = 1,
} modref_tag_t;
   
struct modref_event_s {
  void*          value; /* read/write value */
  modref_event_t* next; /* next event for modref */
  modref_event_t* prev; /* prev event for modref */
  union {
    modref_event_tag_t tag; /* packed into lower bits */
    closure_t*     closure; /* read closure (for read events) */
    timestamp_t*      time; /* write time (for write events) */
    void*             uptr; /* for convenience */
  } u;
};

struct modref_s {
  void* value; /* "initial" write value */
  union {
    /* tag: packed into lower bits */
    modref_tag_t tag;    
    /* events: doubly-linked events
       --- order is monotonic wrt timeline. */
    modref_event_t* events; 
  } u;
};

#endif
