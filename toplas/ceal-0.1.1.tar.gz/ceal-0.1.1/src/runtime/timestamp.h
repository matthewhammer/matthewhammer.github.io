/* Matthew Hammer <hammer@tti-c.org> */

/* Time stamps -- implemented with total order maintenance data
   structure.  Each timestamp t holds one of three values:

   1) A (read) closure start-time.
   2) A (read) closure end-time.
   3) A write.
*/

#ifndef __SLIME_TIMESTAMP_H__
#define __SLIME_TIMESTAMP_H__
#include <stdio.h>
#include "totalorder.h"

typedef to_node_t timestamp_t;

typedef enum timestamp_tag_e {
  TIMESTAMP_CLOSURE_BEGIN = 0,
  TIMESTAMP_CLOSURE_END   = 1,
  TIMESTAMP_WRITE         = 2,
} timestamp_tag_t;

timestamp_t* timestamp_advance(timestamp_tag_t tag, void* data);
int          timestamp_isleq(timestamp_t* time1, timestamp_t* time2);
int          timestamp_isgt(timestamp_t* time1, timestamp_t* time2);
void         timestamp_kill(timestamp_t* time, void* data);
void         timestamp_killall(timestamp_t* start, timestamp_t* end);
void         timestamp_printall(FILE* file);


#endif
