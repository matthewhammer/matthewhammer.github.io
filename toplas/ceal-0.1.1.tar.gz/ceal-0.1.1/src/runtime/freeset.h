/* Matthew A Hammer <hammer@tti-c.org> */

#ifndef __SLIME_FREESET_H__
#define __SLIME_FREESET_H__

#include <inttypes.h>
#include "freelist.h"

typedef struct freeset_s freeset_t;

void  freeset_init(freeset_t* freeset, uintptr_t max_block_size);
void* freeset_pop(freeset_t* freeset, uintptr_t size);
void  freeset_push(freeset_t* freeset, uintptr_t size, void* ptr);

struct freeset_s {
  uintptr_t max_block_size;
  uintptr_t freelistc;
  freelist_t* freelistv;
};

#endif
