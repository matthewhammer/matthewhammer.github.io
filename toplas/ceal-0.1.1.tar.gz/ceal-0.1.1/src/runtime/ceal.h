/* Matthew Hammer <hammer@tti-c.org> */
/* CEAL header file -- includes all symbols for core & meta CEAL
   programs both before and after being compiled to target C code.
   The "surface" CEAL code uses core- and meta-language primitives
   whose symbols are included here.  The target CEAL code uses runtime
   symbols included here as well. */

#ifndef __CEALH__
#define __CEALH__

#include "langcore.h"
#include "langmeta.h"
#include "runtime.h"
#include "test/test.h"

#endif
