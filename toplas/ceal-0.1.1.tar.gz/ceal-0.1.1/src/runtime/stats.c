/* Matthew Hammer <hammer@tti-c.org> */

#include <stdlib.h>
#include "stats.h"

stats_t* slime_stats_curr() {

  return NULL;
}

void slime_stats_save(stats_t* stats_dst,
                      stats_t* stats_src) {

}

void slime_stats_diff(stats_t* stats_dst,
                      stats_t* stats_1,
                      stats_t* stats_2) {
  
}
