/* Matthew Hammer <hammer@tti-c.org> */

/* Code locations are intended for various debugging and profiling
   uses.  They are introduced automatically by the SLIME frontend for
   interesting uses of the SLIME runtime.  In particular, these
   include the following:

   -- closure_call (including "tailcalls")
   -- block_alloc
   -- modref_write

   For each of these runtime instructions, the current codeloc is
   updated by calling codeloc_curr(codeloc) where "codeloc" is
   statically unique.
*/
#ifndef __SLIME_CODELOC__
#define __SLIME_CODELOC__

#include <stdio.h>

typedef struct codeloc_s codeloc_t;

struct codeloc_s {
  const char* file;
  const char* func;
  int line;
  int byte;
};

#include "closure.h"
#include "block.h"

codeloc_t* codeloc_curr(codeloc_t* codeloc);

void codeloc_begin(FILE* f);
void codeloc_end(void);

void codeloc_fresh_closure(closure_t* closure);
void codeloc_match_closure(closure_t* closure);
void codeloc_enque_closure(closure_t* closure);
void codeloc_awoke_closure(closure_t* closure);
void codeloc_null_closure();

void codeloc_fresh_block(block_t* block);
void codeloc_match_block(block_t* block);

#endif
