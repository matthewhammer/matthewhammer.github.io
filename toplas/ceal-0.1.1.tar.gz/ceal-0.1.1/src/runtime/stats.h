/* Matthew Hammer <hammer@tti-c.org> */
/* SLIME runtime statistics -- for use by associated testing/profiling system */

#ifndef __SLIME_STATS_H__
#define __SLIME_STATS_H__

typedef struct stats_s stats_t;

struct stats_s {


};

stats_t* slime_stats_curr();
void     slime_stats_save(stats_t* stats_dst, stats_t* stats_src);
void     slime_stats_diff(stats_t* stats_dst, stats_t* stats_1, stats_t* stats_2);

#endif
