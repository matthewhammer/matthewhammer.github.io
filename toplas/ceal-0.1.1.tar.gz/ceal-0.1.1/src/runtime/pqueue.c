/* Matthew A Hammer <hammer@tti-c.org> */

#include "pqueue.h"
#include "basemm.h"
#include "closure.h"
#include "logging.h"
#include <string.h>
#include <stdlib.h>

void pqueue__grow(pqueue_t* pq);
void pqueue__bubble_up(pqueue_t* pq, int pos);
void pqueue__bubble_down(pqueue_t* pq, int pos);

#define UP(pos) ((pos - 1) >> 1)
#define DOWN(pos) ((pos << 1) + 1)
#define SETPOS(pq, a, pos) ((pq)->data[pos] = a)

static int 
compare(pqueue_t* pq, pqueue_elt_t e1, pqueue_elt_t e2) {
  return closure_compare(e1, e2);
}

static void
swap(pqueue_t* pq, uintptr_t pos1, uintptr_t pos2) {
  pqueue_elt_t e1 = pq->data[pos1];
  pqueue_elt_t e2 = pq->data[pos2];
  pq->data[pos1] = e2;
  pq->data[pos2] = e1;
}

pqueue_t* pqueue_init(pqueue_t* pq) {
  pq->size = 16;
  pq->num = 0;
  pq->data = (pqueue_elt_t*)
    basemm_malloc(pq->size * sizeof(pqueue_elt_t));
  return pq;
}

uintptr_t pqueue_isempty(const pqueue_t* pq) {
  return pq->num == 0;
}

void pqueue__bubble_up(pqueue_t* pq, int pos) {
  while(pos > 0) {
    int up = UP(pos);
    if (compare(pq, pq->data[pos], pq->data[up]) < 0) {
      swap(pq, pos, up);
      pos = up;
    }
    else
      return;
  }
}

void pqueue_push(pqueue_t* pq, pqueue_elt_t elt) {
  if(pq->num == pq->size)
    pqueue__grow(pq);
  SETPOS(pq, elt, pq->num ++);
  pqueue__bubble_up(pq, pq->num - 1);

  logg("pqueue newsize is %d\n", pq->num);
}

pqueue_elt_t pqueue_peek(const pqueue_t* pq) {
  return pq->data[0];
}

void pqueue__bubble_down(pqueue_t* pq, int pos) {
  int down;

  while((down = DOWN(pos)) < pq->num) {
    int tmp = down + 1;
    
    if ((tmp < pq->num) &&
        compare(pq, pq->data[tmp], pq->data[down]) < 0) {
      down = tmp;
    }
    
    if (compare(pq, pq->data[pos], pq->data[down]) > 0) {
      swap(pq, pos, down);
      pos = down;
    }
    else
      break;
  }
}

pqueue_elt_t pqueue_pop(pqueue_t* pq) {
  pqueue_elt_t elt_out = pq->data[0];
  swap(pq, 0, -- pq->num);
  pqueue__bubble_down(pq, 0);
  return elt_out;
}

void pqueue_cleanup(pqueue_t* pq) {
  basemm_free(pq->size * sizeof(pqueue_elt_t), pq->data);
  pq->data = NULL;
}

void pqueue__grow(pqueue_t* pq) {
  pqueue_elt_t* tmp;
  uintptr_t newsize = pq->size * 2;
  tmp = basemm_malloc(newsize * sizeof(pqueue_elt_t));
  memcpy(tmp, pq->data, sizeof(pqueue_elt_t) * pq->num);
  pqueue_cleanup(pq);  
  pq->size = newsize;
  pq->data = tmp;
  logg("pqueue newsize is %d", newsize);
}
