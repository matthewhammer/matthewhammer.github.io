/* Matthew Hammer <hammer@tti-c.org> */
/* Operations on trace objects */

#include <assert.h>
#include <stdlib.h>
#include "traceobj.h"
#include "basemm.h"
#include "state.h"
#include "pointerflags.h"
#include "logging.h"

#define SEQCONT 1
#define ISALIVE 1
#define ISOWNER 2

uintptr_t
traceobj_sing_false(traceobj_t* traceobj) {
  return 0;
}

uintptr_t
traceobj_sing_true(traceobj_t* traceobj) {
  return 1;
}

traceobj_t*
traceobj_inst(const traceobj_vtbl_t* vtbl) {
  uintptr_t size = vtbl->size(NULL);
  traceobj_t* traceobj = basemm_malloc(size);
  traceobj->vtbl = vtbl;
  traceobj->owner.closure = NULL;
  traceobj->next = traceobj;
  traceobj->prev = traceobj;
  return traceobj;
}

uintptr_t
traceobj_isalive(traceobj_t* traceobj) {
  return traceobj->owner.flags & ISALIVE;
}

uintptr_t
traceobj_isowner(traceobj_t* traceobj) {
  return traceobj->owner.flags & ISOWNER;
}

context_t*
traceobj_context(traceobj_t* traceobj) {
  if(!traceobj_isalive(traceobj))
    return pointer_part(traceobj->owner.context);

  else if(traceobj_isowner(traceobj))
    return pointer_part(traceobj->owner.context);

  else {
    return traceobj_context(pointer_part(traceobj->owner.closure));
  }
}

closure_t*
traceobj_closure(traceobj_t* traceobj) {
  if(!traceobj_isalive(traceobj))
    return NULL;

  else if(traceobj_isowner(traceobj))
    return NULL;
  
  else
    return pointer_part(traceobj->owner.closure);
}

void traceobj_make_ownee(traceobj_t* traceobj) {
  state_t* state = state_curr(NULL);
  traceobj->owner.closure =
    pointer_and_flags(state->closure, ISALIVE);
}

void traceobj_kill_ownee(traceobj_t* traceobj) {
  context_t* context = traceobj_context(traceobj);
  closure_t* owner = traceobj_closure(traceobj);

#if 0
  /* BUG (sort of): This assertion doesn't always hold.  Consider a
     nested allocation.  Say l_2 is allocated under l_1.  Now say l_1
     is killed.  Then l_2 will be killed.  Now say l_1 is re-used.
     Will l_2 be toggled as alive?  I don't believe so. */

  /* See: block_alloc */
  assert(traceobj_isalive(traceobj));
#endif
  
  logg("traceobj=%p body=%p owner=%p context=%p",
       traceobj, traceobj+1, owner, context);
  
  traceobj->owner.context = pointer_and_flags(context, 0);
}

void traceobj_make_owner(traceobj_t* traceobj) {
  state_t* state = state_curr(NULL);
  traceobj->owner.context =
    pointer_and_flags(state->context, ISALIVE | ISOWNER);
}

void traceobj_link(traceobj_t* traceobjs_A_frst,
                   traceobj_t* traceobjs_B_frst,
                   uintptr_t flag_A_B,
                   uintptr_t flag_B_A)
{
  traceobj_t* traceobjs_A_last = traceobjs_A_frst->prev;
  traceobj_t* traceobjs_B_last = traceobjs_B_frst->prev;

  /* We start with two loops, A and B, and want to link these together
   * into a single loop like this (note that A_f is written twice to
   * avoid having to draw a loop):
   *
   * A_f <==> ... <==> A_l <~~> B_f <==> ... <==> B_l <~~> A_f
   *  \__________________/      \___________________/
   *     traceobjs_A         ^      traceobjs_B         ^
   *                         |                          |
   *                      new link                  new link
   *                     (flag_A_B)                (flag_B_A)
   */

  traceobjs_A_frst->prev = traceobjs_B_last;
  traceobjs_A_last->next = pointer_and_flags(traceobjs_B_frst,
                                             flag_A_B ? SEQCONT : 0);
  
  traceobjs_B_frst->prev = traceobjs_A_last;
  traceobjs_B_last->next = pointer_and_flags(traceobjs_A_frst,
                                             flag_B_A ? SEQCONT : 0);  
}

traceobj_t* traceobj_unlink(traceobj_t* traceobjs) {
  traceobj_t* traceobj_frst = traceobjs;
  traceobj_t* traceobj_last = traceobjs; 
  traceobj_t* traceobj_prev = traceobj_frst->prev;
  traceobj_t* traceobj_next = traceobj_frst->next;

  assert((flags_part(traceobjs) & SEQCONT) == 0);
  
  /* Find a continuous sequence starting with traceobj_frst.  Setup
   * the pointers so that we have:
   *
   * [prev] <--> [frst] <==> ... <==> [last] <--> [next]
   *
   * where "<-->" are double links without SEQCONT flag and "<==>" are
   * double links with SEQCONT flag.
   */  

  while(flags_part(traceobj_next) & SEQCONT) {
    traceobj_last = pointer_part(traceobj_next);
    traceobj_next = traceobj_last->next;
  }
  traceobj_next = pointer_part(traceobj_next);

  /* Assert that we won't cut any continuous sequences */
  assert((flags_part(traceobj_prev->next) & SEQCONT) == 0);
  assert((flags_part(traceobj_last->next) & SEQCONT) == 0);
  
  /* Seperate and loop the sequence [frst] .. [last] as follows:
   *
   * (1) [prev] <--> [next]
   * (2) [last] <--> [frst]     
   */

  traceobj_last->next = traceobj_frst;
  traceobj_frst->prev = traceobj_last;  
  
  /* If [traceobj_next] == [traceobj_frst] then there's nothing left
     in the loop.  There are a few consequences to this.  In
     particular, there is nothing to return and nothing to do with the
     remaining elements (there are none). */
  if(traceobj_next == traceobj_frst) {
    traceobj_next = NULL;
  }
  else {
    traceobj_prev->next = traceobj_next;
    traceobj_next->prev = traceobj_prev;
  }

  /* Last, if the deadlist was holding a pointer to the loop we are
     removing, then remove the loop from the deadlist as well. */ {
    state_t* state = state_curr(NULL); 
    if(state->deadlist == traceobj_frst)
      state->deadlist = traceobj_next;
  }
  
  return traceobj_next;
}

void traceobj_free(traceobj_t* traceobj) {
  uintptr_t size = traceobj->vtbl->size(traceobj);
  logg("traceobj=%p body=%p vtbl=%p next=%p seqcont=%d",
       traceobj, traceobj + 1, traceobj->vtbl,
       pointer_part(traceobj->next),
       flags_part(traceobj->next)
       );
  traceobj->vtbl = NULL;
  traceobj->owner.closure = NULL;
  basemm_free(size, traceobj);
}
