/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __SLIME_META_H__
#define __SLIME_META_H__

#include "state.h"

/**
 * \defgroup langmeta Meta-Language Primitives
 *
 * See \ref prims for a high-level explanation of how these primitives
 * are used.
 *
 * See \ref limitations for an overview of associated caveats.
 * @{
 */

/**\short An abstract type representing a self-adjusting core computation. */
typedef state_t slime_t;

/**\short Start a new computation */
slime_t* slime_open(void);

/**\short Get the current computation */
slime_t* slime_current(void);          

/**\short Switch to an existing computation */
void slime_switch(slime_t* slime); 

/**\short Kill a top-level allocation */
void slime_kill(void* ptr);        

/**\short Propagate the current computation. */
void slime_propagate(void);        

/**\short Close the given computation. */
void slime_close(slime_t* slime);

/**\short Set current time to computation's start-time. */
void slime_meta_start(void);

/**\short Set current time to computation's end-time. */
void slime_meta_end(void);         

/**\short Returns -1 for start, 1 for end, and 0 for neither. */
int  slime_meta_check(void);       

/**\short Inspect the value of a modref.  This is the meta-level
   analogue to \ref read. */
extern void* modref_deref(modref_t* m);

/* @} */

#endif
