/* Matthew Hammer <hammer@tti-c.org> */
/* SLIME API for surface programs */

#ifndef __SLIME_SURFACE_H__
#define __SLIME_SURFACE_H__
#include <stdint.h>

/**
 * \defgroup langcore Core-Language Primitives
 *
 * See \ref prims for a high-level explanation of how these primitives
 * are used.
 *
 * See \ref limitations for an overview of associated caveats.
 *
 * @{
 */

#ifdef _CEALC
#define afun void __attribute__((slime_function))
#define wfun void __attribute__((slime_function)) __attribute__((slime_nomemo))
#define ifun void __attribute__((slime_initializer))
#else
#define afun void
#define wfun void
#define ifun void
#endif

/**\short Modifiable references. */
typedef struct modref_s modref_t;

/**
   \short Creates a new scope and makes it active.

   It will remain active until the currently-executing function is
   complete, or until its replaced with another scope.  Support for
   this primitive (currently) has some important caveats.  See \ref
   limitations for details.
*/
extern void      scope();

/**
   \short Allocate and initialize memory blocks.

   The variadic arguments of \ref alloc correspond to an
   initialization function and series of zero or more initialization
   values.  After allocating a block of memory of the requested size
   (in bytes) this primitive invokes the given initialization
   function, supplying the address of the allocated block and any
   additional initialization values.
   
   As an example, consider the following usage to allocate memory for
   a pair of integers:
   
   \code
   int* pair = alloc(2 * sizeof(int), pair_initfn, 1, 2);
   printf("(%d, %d)", pair[0], pair[1]);
   \endcode

   Where \c pair_initfn is the following:

   \code
   void pair_initfn(int *pair, int fst, int snd) {
     pair[0] = fst;
     pair[1] = snd;
   }
   \endcode   

   In example uage above, the \ref alloc primitive allocates a block
   large enough to hold two integers.  Say \c p points at the new
   block.  Next, the primtive effectively executes \c initfn(p,1,2) to
   initialize this block.  Last, it returns \c p, whose value is then
   assigned to \c x in the example code.
*/
extern void*     alloc(uintptr_t size, ...);

/**\short Creates a new, empty modifiable reference and returns a pointer to it. */
extern modref_t* modref();

/**\short Reads and returns the current value of a modifiable
   reference.

   \warning Reading an unwritten modref is an error.

   \warning Unlike the other core primitives, \ref read may only be
   used inside core functions (i.e., those with return type \ref ceal)
*/
extern void* read(modref_t* m);

/**\short Writes the given modifiable reference \c m with the given
   value \c val.  */
extern void write(modref_t* m, void* val);
/* @} */

#endif
