#include <stdlib.h>
#include <assert.h>

#include "context.h"
#include "state.h"
#include "logging.h"
#include "verif.h"

ifun context_init(context_t* context) {
  tracetbl_init(context);
}

void context_set(context_t* context) {
  context_t* old_context = state_curr(NULL)->context;
  context_t* new_context = context;
  state_curr(NULL)->context = new_context;
    
  if(old_context != new_context) {
    logg("old=%p new=%p (current)", old_context, new_context);
  }
}
