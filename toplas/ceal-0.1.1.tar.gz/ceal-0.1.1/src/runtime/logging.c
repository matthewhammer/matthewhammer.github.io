/* Matthew Hammer <hammer@tti-c.org> */

#include "logging.h"

FILE* logg_file = NULL;

void logging_init() {
#if SLIME_ENABLE_LOGGING
#if SLIME_LOGGING_STDERR
  logg_file = stderr;
#else
  if(!logg_file) {
    logg_file = fopen("slime.log","w+");
  }
#endif
#endif
}
