/* Matthew Hammer <hammer@tti-c.org> */

/* Trace Stack -- A stack for traced closures that need to be assigned end-times. */

#ifndef __SLIME_CLOSURESTK__
#define __SLIME_CLOSURESTK__

#include <stdint.h>

/* -- Forward-declare some types: */

typedef struct closurestk_s closurestk_t;
typedef struct closurestk_chunk_s closurestk_chunk_t;
typedef struct closurestk_chunk_hdr_s closurestk_chunk_hdr_t;

struct closurestk_s {
  closurestk_chunk_t* nonempty;
  closurestk_chunk_t* allempty;
};

struct closurestk_chunk_hdr_s {
  closurestk_chunk_t* tail;
  uintptr_t num;  
};

/* -- The rest depends on closure_t (from "closure.h") */
#include "closure.h"

closurestk_t* closurestk_init(closurestk_t* closurestk);
closure_t* closurestk_push(closurestk_t* closurestk, closure_t* closure);
closure_t* closurestk_pop(closurestk_t* closurestk);

#define CHUNK_SIZE ((4096 - sizeof(closurestk_chunk_hdr_t)) / sizeof(closure_t*))

struct closurestk_chunk_s {
  closurestk_chunk_hdr_t hdr;
  closure_t* objs[CHUNK_SIZE];
};

#endif
