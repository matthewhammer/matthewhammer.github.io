/* Matthew Hammer <hammer@tti-c.org> */
/* Facilities for logging */

#ifndef __SLIME_LOGGING_H__
#define __SLIME_LOGGING_H__
#include <stdio.h>

extern FILE* logg_file;

void logging_init(void);

#if SLIME_ENABLE_LOGGING
#define logg(FMT, ...) \
  fprintf(logg_file, __FUNCTION__ ": " FMT "\n",##__VA_ARGS__)
#else
#define logg(...)
#endif
#endif
