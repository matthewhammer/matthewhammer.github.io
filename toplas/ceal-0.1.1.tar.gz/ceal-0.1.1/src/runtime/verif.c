/* Matthew Hammer <hammer@tti-c.org> */
#include "verif.h"
#include "basemm.h"
#include "pointerflags.h"

int __ISVERIF__ = 0xdeadbeef;

void* verif_block_alloc(uintptr_t size) {
  return basemm_malloc(size);
}

void verif_modref_init(modref_t* modref) {
  modref->u.events = NULL;
  modref->value = (void*) 0xDEADBEEF;
}

void verif_modref_write(modref_t* modref, void* value) {
  modref->u.events = pointer_add_flags(modref->u.events, MODREF_INITIALIZED);
  modref->value = value;
}

void* verif_modref_read(modref_t* modref) {
  return modref->value;
}
