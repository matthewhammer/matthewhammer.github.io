/* Matthew Hammer <hammer@tti-c.org> */
/* Operations on SLIME computation state */

#include <stdlib.h>
#include <assert.h>
#include "state.h"
#include "closurestk.h"
#include "logging.h"

static const char*
metalvl_closure_name(traceobj_t* traceobj)
{ return ("metalvl_closure"); }

static uintptr_t
metalvl_closure_size(traceobj_t* traceobj)
{ return sizeof(closure_t); }

static uintptr_t
metalvl_closure_sing(traceobj_t* traceobj)
{ return 1; }

#define METALVL_DUMMY_OP(return_stmt) \
  { assert(!("meta-level closure: " __FUNCTION__)); return_stmt; }

static uintptr_t
metalvl_closure_buff(traceobj_t* traceobj, unsigned char* buff)
     METALVL_DUMMY_OP(return 0);

static uintptr_t
metalvl_closure_hash(traceobj_t* traceobj)
     METALVL_DUMMY_OP(return 0);

static uintptr_t
metalvl_closure_eqiv(traceobj_t* traceobj_1, traceobj_t* traceobj_2)
     METALVL_DUMMY_OP(return 0);

static uintptr_t
metalvl_closure_time(traceobj_t* traceobj)
     METALVL_DUMMY_OP(return 0);

static void
metalvl_closure_init(traceobj_t* traceobj)
     METALVL_DUMMY_OP(return);

static void
metalvl_closure_comb(traceobj_t* traceobj_1, traceobj_t* traceobj_2)
     METALVL_DUMMY_OP(return);

static closure_t*
metalvl_closure_invk(closure_t* closure)
     METALVL_DUMMY_OP(return NULL);

static void
metalvl_closure_uini(closure_t* closure)
     METALVL_DUMMY_OP(return);

static closure_vtbl_t metalvl_closure_vtbl = {
  { metalvl_closure_name,
    metalvl_closure_size,
    metalvl_closure_sing,
    metalvl_closure_buff,
    metalvl_closure_hash,
    metalvl_closure_eqiv,
    metalvl_closure_time,
    metalvl_closure_init,
    metalvl_closure_comb,
  },
  metalvl_closure_invk,
  metalvl_closure_uini  
};

static closure_t*
metalvl_closure_new() {
  closure_t* closure = closure_inst(&metalvl_closure_vtbl);
  closure->time_start = totalorder_create(closure);
  closure->time_end   = totalorder_insert(closure->time_start, closure);
  return closure;
}

state_t* state_init(state_t* state) {
  logging_init();
  pqueue_init(&state->pqueue);
  closurestk_init(&state->closurestk);
  state->codeloc = NULL;
  state->context = NULL;
  state->closure = NULL;
  state->metalvl = metalvl_closure_new();
  state->closure = state->metalvl;
  state->time_now = state->metalvl->time_start;
  state->time_end = NULL;
  state->deadlist = NULL;
  return state;
}

state_t* state_curr(state_t* state) {
  static state_t* curr = NULL;
  if(state) curr = state;
  return curr;
}

void state_uini(state_t* state) {
  /* TODO */
  abort();
}
