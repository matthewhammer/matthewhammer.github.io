/* Matthew Hammer <hammer@tti-c.org> */

/* Contexts -- A case of blocks (see "traceobj.h"). */

#ifndef __SLIME_CONTEXT_H__
#define __SLIME_CONTEXT_H__

#include "traceobj.h"
#include "tracetbl.h"
#include "ceal.h"

struct context_s {
  tracetbl_t tracetbl;
};

ifun context_init(context_t* context);
void context_set(context_t* context);

/*
context_t* context_push(void);
void  context_restore(context_t* context);
*/

#endif
