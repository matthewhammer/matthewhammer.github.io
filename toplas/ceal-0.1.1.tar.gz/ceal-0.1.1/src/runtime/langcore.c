#include <assert.h>
#include <stdlib.h>

#include "langcore.h"

#define CORE_LANG_ERROR \
  assert(!"you cannot use the CEAL core primitives directly -- try first compiling with cealc")

void scope()
{ CORE_LANG_ERROR; return; }

void* alloc(uintptr_t size, ...)
{ CORE_LANG_ERROR; return NULL; }

modref_t* modref()
{ CORE_LANG_ERROR; return NULL; }

void* read(modref_t* m)
{ CORE_LANG_ERROR; return NULL; }

void write(modref_t* m, void* val)
{ CORE_LANG_ERROR; return; }
