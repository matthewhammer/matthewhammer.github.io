/* Matthew Hammer <hammer@tti-c.org> */

#include <assert.h>
#include <inttypes.h>
#include <stdlib.h>

#include "pointerflags.h"
#include "timestamp.h"
#include "state.h"
#include "closure.h"
#include "modref.h"

int timestamp_isleq(timestamp_t* time1, timestamp_t* time2) {
  return (totalorder_compare(time1, time2) <= 0);
}

int timestamp_isgt(timestamp_t* time1, timestamp_t* time2) {
  return (totalorder_compare(time1, time2) > 0);
}

timestamp_t*
timestamp_advance(timestamp_tag_t tag, void* data) {
  state_t* state    = state_curr(NULL);
  void* tagged_data = pointer_and_flags(data, tag);

  state->time_now = totalorder_insert(state->time_now, (uintptr_t) tagged_data);
  return state->time_now;
}

void
timestamp_killall_reads(timestamp_t* start,
                        timestamp_t* end) {
  timestamp_t* timestamp = totalorder_next(start);
  
  while(timestamp != end) {
    void* tagged_data = totalorder_getdata(timestamp);
    void*        data = pointer_part(tagged_data);
    uintptr_t     tag = flags_part(tagged_data);
    
    if (tag == TIMESTAMP_CLOSURE_BEGIN) {
      closure_t* closure = (closure_t*) data;
      closure_kill(closure, timestamp);
      closure = pointer_and_flags(NULL, TIMESTAMP_CLOSURE_BEGIN);      
      totalorder_setdata(timestamp, closure);
    }
        
    timestamp = totalorder_next(timestamp);
  }
}

void
timestamp_kill(timestamp_t* time, void* tagged_data) {
  void*    data = pointer_part(tagged_data);
  uintptr_t tag = flags_part(tagged_data);

  if (tag == TIMESTAMP_CLOSURE_BEGIN) {
    /* Here we assume that we've already removed this closure via a
       preceding call timestamp_killall_reads(): */
    closure_t* closure = (closure_t*) data;
    assert(closure == NULL);
  }
  else if (tag == TIMESTAMP_CLOSURE_END) {
    /* Nothing to do. */
  }
  else if (tag == TIMESTAMP_WRITE) {
    write_t* write = (write_t*) data;
    modref_remwrite(data, time);
  }
  else {
    abort();
  }
}

void
timestamp_killall(timestamp_t* start,
                  timestamp_t* end) {
  timestamp_killall_reads(start, end);
  totalorder_remove(start, end);  
}

void
timestamp_printall(FILE* file)
{
  if(file) {    
    state_t*    state = state_curr(NULL);
    timestamp_t* time = closure_time_start(state->metalvl);
    
    while(time) {
      void* tagged_data = (void*) totalorder_getdata(time);
      void*    data = pointer_part(tagged_data);
      uintptr_t tag = flags_part(tagged_data);

      if(tag == TIMESTAMP_CLOSURE_BEGIN)
      {
        closure_t*   closure = data;
        closure_vtbl_t* vtbl = closure_vtbl(closure);
        timestamp_t*   start = closure_time_start(closure);
        timestamp_t*     end = closure_time_end(closure);
        const char*     name = closure_name(closure);
        const char* start_or_end;
    
        if(time == start) { start_or_end = "start"; }
        else if(time == end) { start_or_end = "end"; }
    
        fprintf(file, "%-32s time=%p closure=%p (%s) vtbl=%p start=%p end=%p\n",
                name, time, closure, start_or_end, vtbl, start, end);

        if(time == start) /* List owned allocations */ {
          traceobj_t* alloc = pointer_part(closure->traceobj.next);
          
          while(alloc != closure) {
            const char* name =  alloc->vtbl->name(alloc);
            fprintf(file, "--  %-32s block=%p vtbl=%p next=%p seqcont=%d\n",
                    name,
                    alloc, alloc->vtbl,
                    pointer_part(alloc->next),                
                    flags_part(alloc->next));
            alloc = pointer_part(alloc->next);
          }
        }
      }
      else if(tag == TIMESTAMP_WRITE) {
        fprintf(file, "(write)\n");
      }
      
      time = totalorder_next(time);
    }

    if(state->deadlist) {
      traceobj_t* dead = state->deadlist;
      while(1) {
        fprintf(file, "dead: traceobj=%p vtbl=%p next=%p seqcont=%d\n",
                dead, dead->vtbl,
                pointer_part(dead->next),
                flags_part(dead->next)
                );
        dead = pointer_part(dead->next);
        if(dead == state->deadlist) break;
      }}
  }
}
