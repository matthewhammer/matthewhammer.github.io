/* Matthew Hammer <hammer@tti-c.org> */
#include <stdlib.h>
#include <string.h>
#include "tracetbl.h"
#include "basemm.h"
#include "state.h"
#include "logging.h"

#define EMPTY_SLOT ((uintptr_t) 1)

tracetbl_t* tracetbl_init(tracetbl_t* tracetbl) {
  tracetbl->objs = NULL;
  tracetbl->num = 0;
  tracetbl->size = 0;
  return tracetbl;
}

static uintptr_t
tracetbl_index(tracetbl_t* tracetbl, traceobj_t* traceobj) {
  uintptr_t hash = traceobj->vtbl->hash(traceobj, 0);  
  uintptr_t index = (hash % tracetbl->size);  
  return index;
}

static uintptr_t
tracetbl_probe(tracetbl_t* tracetbl, uintptr_t index) {
  return (index + 1) % tracetbl->size;
}

/* tracetbl_put_fast: We elide capacity checks (but still check for
   tombstones (empty slots)). */
static void
tracetbl_put_fast(tracetbl_t* tracetbl, traceobj_t* traceobj) {
  uintptr_t index = tracetbl_index(tracetbl, traceobj);
    
  while(1) {
    traceobj_t* traceobj_0 = tracetbl->objs[index];
    
    if ((uintptr_t)traceobj_0 <= EMPTY_SLOT) {
      tracetbl->objs[index] = traceobj;
      ++ tracetbl->num;
      return;
    }
    else {
      index = tracetbl_probe(tracetbl, index);
    }
  }
}

static void
tracetbl_resize(tracetbl_t* tracetbl, uintptr_t new_size) {
  tracetbl_t temp;
  
  temp.num = 0;
  temp.size = new_size;
  temp.objs = basemm_malloc(sizeof(traceobj_t*) * new_size);
  memset(temp.objs, 0, sizeof(traceobj_t*) * new_size);
  
  {int index; for(index = 0; index < tracetbl->size; index++) {
    traceobj_t* traceobj = tracetbl->objs[index];
    if ((uintptr_t)traceobj > EMPTY_SLOT)
      tracetbl_put_fast(&temp, traceobj);
  }}

  basemm_free(tracetbl->size * sizeof(traceobj_t*), tracetbl->objs);
  *tracetbl = temp;
}

static uintptr_t
tracetbl_test_match(traceobj_t* traceobj_req, traceobj_t* traceobj_rsp) {
  state_t* state = state_curr(NULL);
  const traceobj_vtbl_t* vtbl;
  timestamp_t* time_rsp;

  logg("req=%p rsp=%p", traceobj_req, traceobj_rsp);

  
  /* Check for reuse mode */
  if(!state->time_end) {
    logg("not in reuse mode");
    return 0;
  }

  /* Check if v-tables are the same */
  if(traceobj_req->vtbl != traceobj_rsp->vtbl) {
    logg("vtbls don't match");
    return 0;
  }

  vtbl = traceobj_rsp->vtbl;

#if 0
  /* TODO.  Is this check okay to elide? */
  /* Check if sizes are the same */
  if(vtbl->size(traceobj_req) != vtbl->size(traceobj_rsp)) {
    logg("sizes don't match");
    return 0;
  }
#endif
  
  time_rsp = vtbl->time(traceobj_rsp);

  /* Check if time is in reuse interval */
  if(time_rsp) {
    if(totalorder_compare(time_rsp, state->time_now) <= 0) {
      logg("time is too early");
      return 0;
    }
    if(totalorder_compare(time_rsp, state->time_end) >= 0) {
      logg("time is too late");
      return 0;
    }
  }

  /* Finally, check if the traceobjs are equivalent */
  if(vtbl->eqiv(traceobj_req, traceobj_rsp)) {
    logg("found match, req=%p rsp=%p", traceobj_req, traceobj_rsp);
    return 1;
  }
  else {
    logg("not equivalent");
    return 0;
  }
}

static uintptr_t
tracetbl_test_sing(tracetbl_t* tracetbl, traceobj_t* traceobj) {
  traceobj_vtbl_t* traceobj_vtbl = traceobj->vtbl;  
  return ( !tracetbl
           || traceobj_vtbl->sing == traceobj_sing_true
           || (traceobj_vtbl->sing != traceobj_sing_false &&
               traceobj_vtbl->sing(traceobj)) );  
}

static void
tracetbl_handle_too_small(tracetbl_t* tracetbl) {
  /* Grow the table, but only if needbe */
  if( tracetbl->size * SLIME_TRACETBL_MAX_CAPACITY < (tracetbl->num + 1)) {
    uintptr_t new_size = tracetbl->size * SLIME_TRACETBL_GROW_FACTOR;
    if(new_size < SLIME_TRACETBL_INITIAL_SIZE)
      new_size = SLIME_TRACETBL_INITIAL_SIZE;
    tracetbl_resize(tracetbl, new_size);
  }
}

static void
tracetbl_handle_too_big(tracetbl_t* tracetbl) {
  /* Shrink the table, but only if needbe */
  if (tracetbl->num == 0) {
    tracetbl_resize(tracetbl, 0);
  }
  else if (tracetbl->num > SLIME_TRACETBL_INITIAL_SIZE &&
           tracetbl->size * SLIME_TRACETBL_MIN_CAPACITY > tracetbl->num) {
    tracetbl_resize(tracetbl, tracetbl->size / SLIME_TRACETBL_SHRINK_FACTOR);  
  }  
}

traceobj_t* tracetbl_add(tracetbl_t* tracetbl, traceobj_t* traceobj_req) {
  traceobj_vtbl_t* traceobj_req_vtbl = traceobj_req->vtbl;

  logg("tracetbl=%p traceobj=%p (%s)",
       tracetbl, traceobj_req, traceobj_req->vtbl->name(traceobj_req));
  
  /* Decide if the traceobj should be added to the tracetbl at all.
     If no tracetbl is given, or if the traceobject is a singleton
     then we never perform the add, we just return the requested
     object. */
  if(tracetbl_test_sing(tracetbl, traceobj_req)) {
    logg("%p is sing", traceobj_req);
    return traceobj_req;
  }

  tracetbl_handle_too_small(tracetbl);   

  /* Try to match the traceobj.  If no match is found, then add the
     given traceobj.  Otherwise, return the match after combining it
     with the requested traceobj and freeing the requested
     traceobj. */
  {
    uintptr_t index = tracetbl_index(tracetbl, traceobj_req);

    while(1) {
      traceobj_t* traceobj_rsp = tracetbl->objs[index];
      
      if ((uintptr_t) traceobj_rsp <= EMPTY_SLOT) {
        tracetbl->objs[index] = traceobj_req;
        tracetbl->num ++;
        return traceobj_req;
      }
      else if (tracetbl_test_match(traceobj_req, traceobj_rsp)) {
        traceobj_vtbl_t* vtbl = traceobj_rsp->vtbl;
        vtbl->comb(traceobj_req, traceobj_rsp);
        basemm_free(vtbl->size(traceobj_req), traceobj_req);
        return traceobj_rsp;
      }
      else {
        index = tracetbl_probe(tracetbl, index);
      }
    }
  }
}

void tracetbl_put(tracetbl_t* tracetbl, traceobj_t* traceobj) {
  if(tracetbl_test_sing(tracetbl, traceobj))
    return;

  tracetbl_handle_too_small(tracetbl);
  tracetbl_put_fast(tracetbl, traceobj);
}

traceobj_t** tracetbl_get(tracetbl_t* tracetbl, traceobj_t* traceobj) {
  uintptr_t index;
  
  if(tracetbl_test_sing(tracetbl, traceobj))
    return NULL;

  index = tracetbl_index(tracetbl, traceobj);

  while(1) {
    traceobj_t* traceobj_0 = tracetbl->objs[index];
    
    if(traceobj_0 == traceobj) {
      return &(tracetbl->objs[index]);
    }
    else if(traceobj_0 == NULL) {
      return NULL;
    }
    else {
      index = tracetbl_probe(tracetbl, index);
    }
  }
}

/* Returns traceobj iff it was found and removed, otherwise returns null */
traceobj_t* tracetbl_rem(tracetbl_t* tracetbl, traceobj_t* traceobj) {
  traceobj_t*  result;
  traceobj_t** slot;

  logg("tracetbl=%p traceobj=%p", tracetbl, traceobj);
  
  if(tracetbl_test_sing(tracetbl, traceobj))
    return traceobj;
  
  slot = tracetbl_get(tracetbl, traceobj);

  if(!slot) {
    return NULL;
  }
  else {
    result = *slot;
    *slot = EMPTY_SLOT;
    tracetbl->num --;
    tracetbl_handle_too_big(tracetbl);    
    return result;
  }
}

void tracetbl_mov(tracetbl_t* tracetbl, traceobj_t** slot) {
  traceobj_t* traceobj;
  
  if(!slot || !tracetbl) {
    return;
  }
  else {
    traceobj = *slot;
    *slot = EMPTY_SLOT;
    tracetbl_put_fast(tracetbl, traceobj);
  }
}
