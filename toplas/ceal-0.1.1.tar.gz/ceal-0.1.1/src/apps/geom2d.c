#include "geom2d.h"
#include "ceal.h"
#include <math.h>

ifun
geom2d_point_init(geom2d_point_t* p,
                  float x, float y) {
  p->x = x;
  p->y = y;
}


ifun
geom2d_line_init(geom2d_line_t* line,
                 geom2d_point_t* p1,
                 geom2d_point_t* p2) {
  line->p1 = p1;
  line->p2 = p2;  
}

float
geom2d_cross(geom2d_point_t* p1,
             geom2d_point_t* p2) {
  return (p1->x * p2->y) - (p1->y * p2->x);
}

float
geom2d_mag(geom2d_point_t* p) {
  return sqrtf((p->x * p->x) + (p->y * p->y));
}

void
geom2d_sub(geom2d_point_t* p1, geom2d_point_t* p2,
           geom2d_point_t* diff) {
  diff->x = p1->x - p2->x;
  diff->y = p1->y - p2->y;
}

float
geom2d_dist(geom2d_point_t* p1, geom2d_point_t* p2) {
  return sqrt((p1->x - p2->x) * (p1->x - p2->x) +
              (p1->y - p2->y) * (p1->y - p2->y));
}

int
geom2d_iszero(float f) {
  return ((f >= -0.0001) &&
          (f <= +0.0001));
}

float
geom2d_line_point_distance(geom2d_line_t* line,
                           geom2d_point_t* p) {
  geom2d_point_t diff1;
  geom2d_point_t diff2;
  geom2d_point_t diff3;
  float numer;
  float denom;  

  geom2d_sub(line->p2, line->p1, &diff1);
  geom2d_sub(line->p1, p, &diff2);
  geom2d_sub(line->p2, line->p1, &diff3);

  numer = fabs(geom2d_cross(&diff1, &diff2));
  denom = geom2d_mag(&diff3);
  
  return numer / denom;
}

void*
geom2d_signtest(float diff,
                void* a,
                void* b)
{
  if(geom2d_iszero(diff))
    return a > b ? a : b;
  else if( diff < 0 )
    return a;
  else
    return b;
}

int
geom2d_isabove(geom2d_line_t* line,
               geom2d_point_t* p) {
  geom2d_point_t diff1;
  geom2d_point_t diff2;
  float cross;
  int result;
  geom2d_sub(line->p2, line->p1, &diff1);
  geom2d_sub(line->p1, p, &diff2);
  cross = geom2d_cross(&diff1, &diff2);
  if(geom2d_iszero(cross)) result = 0;
  else result = (int) geom2d_signtest(cross, (void*) 1, (void*) 0);
  return result;
}

geom2d_point_t*
geom2d_toleft(geom2d_point_t* p1,
              geom2d_point_t* p2) {
  return geom2d_signtest(p1->x - p2->x, p1, p2);  
}

geom2d_point_t*
geom2d_toright(geom2d_point_t* p1,
               geom2d_point_t* p2) {
  return geom2d_signtest(p1->x - p2->x, p2, p1);
}

geom2d_point_t*
geom2d_maxdist(geom2d_line_t* line, geom2d_point_t* p1, geom2d_point_t* p2) {
  float d1 = geom2d_line_point_distance(line, p1);
  float d2 = geom2d_line_point_distance(line, p2);
  return geom2d_signtest(d2 - d1, p1, p2);
}

void
geom2d_point_print(geom2d_point_t* p, FILE* f) {
  fprintf(f, "(%.2f, %.2f)", p->x, p->y);  
}
