/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __GEOM2D_H__
#define __GEOM2D_H__

#include <stdio.h>
#include "ceal.h"


typedef struct geom2d_point_s {
  float x;
  float y;
} geom2d_point_t;  

typedef struct geom2d_line_s {
  geom2d_point_t* p1;
  geom2d_point_t* p2;
} geom2d_line_t;

typedef struct geom2d_triangle_s {
  geom2d_point_t* p1;
  geom2d_point_t* p2;
  geom2d_point_t* p3;
} geom2d_triangle_t;


ifun
geom2d_point_init(geom2d_point_t* p,
                  float x, float y);

#define Point(x, y) alloc(sizeof(geom2d_point_t), geom2d_point_init, x, y);

ifun
geom2d_line_init(geom2d_line_t* line,
                 geom2d_point_t* p1,
                 geom2d_point_t* p2);

#define Line(p1, p2) alloc(sizeof(geom2d_line_t), geom2d_line_init, p1, p2);


float              geom2d_cross(geom2d_point_t* p1, geom2d_point_t* p2);
float              geom2d_mag(geom2d_point_t* p);
void               geom2d_sub(geom2d_point_t* p1, geom2d_point_t* p2, geom2d_point_t* diff);
float              geom2d_dist(geom2d_point_t* p1, geom2d_point_t* p2);
int                geom2d_iszero(float f);
float              geom2d_line_point_distance(geom2d_line_t* line, geom2d_point_t* p);
void*              geom2d_signtest(float diff, void* a, void* b);
int                geom2d_isabove(geom2d_line_t* line, geom2d_point_t* p);
geom2d_point_t*    geom2d_toleft(geom2d_point_t* p1, geom2d_point_t* p2);
geom2d_point_t*    geom2d_toright(geom2d_point_t* p1, geom2d_point_t* p2);
geom2d_point_t*    geom2d_maxdist(geom2d_line_t* line, geom2d_point_t* p1, geom2d_point_t* p2);

void               geom2d_point_print(geom2d_point_t* p, FILE* f);

#endif
