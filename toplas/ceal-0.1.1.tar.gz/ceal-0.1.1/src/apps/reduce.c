#include "coin.h"
#include "modlist.h"


afun reduce_pass(modref_t* list,
                 void* (*op)(void* env, void* a, void* b),
                 void* op_env, modref_t* dest) {
  coin_t*   coin = Coin_biased_4();
  modref_t* tail = dest;
  cons_cell_t* c = read(list);

  while(1) {
    void* val = c->hd;
    
    while(c = read(c->tl),
          (c != NULL && coin_flip(coin, c))) {
      val = op(op_env, val, c->hd);
    }

    cons_cell_t* c_r = Cons(val);    
    write(tail, c_r);
    tail = c_r->tl;
    
    if(c == NULL) {
      write(tail, NULL);
      break;
    }
  }
}

afun reduce(modref_t* list,
            void* (*op)(void* env, void* a, void* b),
            void* op_env, modref_t* dest) {

  modref_t* len_is_one = modref();
  lenlt(read(list), 2, len_is_one);

  if(read(len_is_one)) {
    cons_cell_t* c = read(list);
    write(dest, c->hd);
  }
  else {
    modref_t* next_list = modref();
    scope();
    reduce_pass(list, op, op_env, next_list);
    reduce(next_list, op, op_env, dest);
  }
}
