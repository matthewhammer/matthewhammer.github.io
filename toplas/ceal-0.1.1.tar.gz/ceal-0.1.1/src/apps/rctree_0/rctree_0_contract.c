/* Matthew Hammer <hammer@tti-c.org> */

#include "rctree_0.h"

/* == Contraction == */

/* Recursively inspects the edgelist to find out the following:
   -- node degree (by counting edges)
   -- "left" edge (the first edge we find)
   -- "right" edge (the second edge we find)
*/
afun rctree_inspect_edges(rctree_node_t* node,
                          cons_cell_t* cell,
                          uintptr_t count,
                          modref_t* degree,
                          modref_t* left,
                          modref_t* right) {
  if(!cell) {
    write(degree, (void*) count);
  }
  else {
    if(count == 0) {
      write(left, read(cell->hd));
    }
    else if(count == 1) {
      write(right, read(cell->hd));
    }
    rctree_inspect_edges(node, read(cell->tl),
                         count+1, degree,
                         left, right);
  }
}


afun rctree_rake_node(rctree_node_t* node,
                      rctree_edge_t* edge) {
  rctree_edge_t* edge_mirror = read(edge->mirror);
  write(edge_mirror->desc, NULL);
  write(node->desc, NULL);
}

afun rctree_compress_node(rctree_node_t* node,
                          rctree_edge_t* edge_left,
                          rctree_edge_t* edge_right) {
  rctree_node_t*      node_left = read(edge_left->node);
  rctree_node_t*     node_right = read(edge_right->node);
  rctree_edge_t*    mirror_left = read(edge_left->mirror);
  rctree_edge_t*   mirror_right = read(edge_right->mirror);
  rctree_edge_t*  new_edge_left = Rctree_edge(node_right->desc, mirror_right->desc);
  rctree_edge_t* new_edge_right = Rctree_edge(node_left->desc,  mirror_left->desc);
  
  write(mirror_left->desc, new_edge_left);
  write(mirror_right->desc, new_edge_right);
  write(node->desc, NULL);
}

afun rctree_copy_edges(modref_t* node_desc,
                       cons_cell_t* cell,
                       uintptr_t count,
                       modref_t* dest,
                       modref_t* sing) {
  if(!cell) {
    write(dest, NULL);
    write(sing, (void*)(count <= 1));
  }
  else {
    rctree_edge_t* edge = read(cell->hd);
    rctree_node_t* edge_node   = edge ? read(edge->node) : NULL;
    rctree_edge_t* edge_mirror = edge ? read(edge->mirror) : NULL;
    uintptr_t edge_node_sing   = edge_node ? read(edge_node->sing) : 0;
    
    if(edge && !edge_node_sing) {      
      /* Create descendent for edge mirror */  {
        rctree_edge_t* edge_mirror_desc = Rctree_edge(node_desc, edge->desc);
        write(edge_mirror->desc, edge_mirror_desc);
      }

      /* (indirectly) include mirrored edge within edge-list of
         descendent */ {
        cons_cell_t* cell_out = Cons(edge->desc);
        write(dest, cell_out);
        rctree_copy_edges(node_desc,
                          read(cell->tl), count+1,
                          cell_out->tl, sing);        
      }
    }
    else {
      rctree_copy_edges(node_desc,
                        read(cell->tl), count,
                        dest, sing);
    }
  }
}

afun rctree_copy_node(rctree_node_t* node) {  
  rctree_node_t* node_desc = Rctree_node_desc(node);

  rctree_copy_edges(node->desc,
                    read(node->edges), 0,
                    node_desc->edges,
                    node_desc->sing);
}

afun rctree_contract_node(rctree_node_t* node)
{
  modref_t* modref_degree = modref();
  modref_t* modref_left   = modref();
  modref_t* modref_right  = modref();

  rctree_inspect_edges(node, read(node->edges), 0,
                       modref_degree,
                       modref_left,
                       modref_right);
  {
    uintptr_t degree = (uintptr_t) read(modref_degree);
    rctree_edge_t* left   = read(modref_left);
    rctree_edge_t* right  = read(modref_right);

    if(degree == 0) {
      abort();  /* TODO: is this the right spot to detect "final" nodes? */
    }
    else if(degree == 1) {
      rctree_node_t* left_node = read(left->node);

      if(left_node->coin_toss < node->coin_toss ||
         !(read(left_node->sing))) {
        rctree_rake_node(node, left);
      }
      else {
        rctree_copy_node(node);
      }
    }
    else if(degree == 2) {
      rctree_node_t* left_node = read(left->node);
      rctree_node_t* right_node = read(right->node);
      uintptr_t left_node_sing = (uintptr_t) read(left_node->sing);
      uintptr_t right_node_sing = (uintptr_t) read(right_node->sing);
      int coin_toss_check = 0;
        
      coin_toss_check = ((node->coin_toss > left_node->coin_toss) &&
                         (node->coin_toss > right_node->coin_toss));
      
      if(coin_toss_check &&
         !left_node_sing &&
         !right_node_sing) {
        rctree_compress_node(node, left, right);
      }
      else {
        rctree_copy_node(node);
      }
    }
    else {
      rctree_copy_node(node);
    }
  }
}

afun rctree_contract_all(cons_cell_t* cell) {
  if(cell) {
    rctree_contract_node(read(cell->hd));
    rctree_contract_all(read(cell->tl));
  }
}

afun rctree_gather_descs(cons_cell_t* cell,
                         modref_t* descs) {

  if(!cell) {
    write(descs, NULL);
  }
  else {
    rctree_node_t* node = read(cell->hd);
    rctree_node_t* desc = read(node->desc);

    if(desc) {
      cons_cell_t* desc_cell = Cons(node->desc);
      write(descs, desc_cell);
      rctree_gather_descs(read(cell->tl), desc_cell->tl);
    }
    else {
      rctree_gather_descs(read(cell->tl), descs);
    }
  }  
}

afun static print_hook(uintptr_t dummy, uintptr_t roundc, modref_t* nodes) {
  char* filename = malloc(255);
  FILE* f = NULL;
    
  sprintf(filename, "rctree.num%02d.round%02d.dot", dummy, roundc);
  f = fopen(filename, "w+");
  rctree_print(nodes, f);
  fclose(f);  
}

/* Do rounds of tree-contraction until the rc-tree is a single node. */
afun rctree_contract_rec(uintptr_t roundc,
                         modref_t* nodes,
                         modref_t* dest,
                         modref_t* dummy) {

  if(SLIME_RCTREE_0_DEBUG) {
    print_hook(read(dummy), roundc, nodes);
  }
  
  modref_t* len_is_one = modref();
  lenlt(read(nodes), 2, len_is_one);
  if(read(len_is_one)) {
    cons_cell_t* final_cell = read(nodes);
    rctree_node_t* final = read(final_cell->hd);
    write(dest, final);
  }
  else {    
    modref_t* descs = modref();
    rctree_contract_all(read(nodes));
    rctree_gather_descs(read(nodes), descs);
    rctree_contract_rec(roundc+1, descs, dest, dummy);
  }
}

afun rctree_contract(modref_t* nodes, modref_t* dest, modref_t* dummy) {
  scope();
  rctree_contract_rec(0, nodes, dest, dummy);
}
