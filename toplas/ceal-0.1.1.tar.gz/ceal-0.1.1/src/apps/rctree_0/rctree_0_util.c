/* Matthew Hammer <hammer@tti-c.org> */

#include "rctree_0.h"

static uintptr_t
coin_toss(uintptr_t prev_coin_toss,
          uintptr_t id) {
  uintptr_t a, b, c;
  a = b = (uintptr_t) id;
  c = prev_coin_toss;
  mix(a,b,c);
  return c;
}

ifun rctree_node_init(rctree_node_t* node,
                      uintptr_t id) {
  
  node->id         = id;
  node->coin_toss  = coin_toss(0, id);
  node->sing       = modref();
  node->desc       = modref();
  node->edges      = modref();
}

ifun rctree_node_desc_init(rctree_node_t* node_desc,
                           rctree_node_t* node) {
  node_desc->id         = node->id;
  node_desc->coin_toss  = coin_toss(node->coin_toss, node->id);
  node_desc->sing       = modref();
  node_desc->edges      = modref();
  node_desc->desc       = modref();
}

ifun rctree_edge_init(rctree_edge_t* edge,
                      modref_t* node,
                      modref_t* mirror) {
  edge->node   = node;
  edge->mirror = mirror;
  edge->desc   = modref();
}

ifun rctree_link_init(rctree_link_t* link,
                      modref_t* node_u,
                      modref_t* node_v) {
  link->node_u = node_u;
  link->node_v = node_v;

  link->uv.edge_modref = modref();
  link->vu.edge_modref = modref();
  
  link->uv.edge = Rctree_edge(node_v, link->vu.edge_modref);
  link->vu.edge = Rctree_edge(node_u, link->uv.edge_modref);
}

/* == Constructors == */

rctree_node_t*
Rctree_node(uintptr_t id) {
  rctree_node_t* node =
    alloc(sizeof(rctree_node_t),
          rctree_node_init,
          id);
  write(node->sing, 0);
  return node;
}


rctree_node_t*
Rctree_node_desc(rctree_node_t* node) {
  rctree_node_t* node_desc =
    alloc(sizeof(rctree_node_t),
          rctree_node_desc_init,
          node);
  write(node->desc, node_desc);
  return node_desc;
}

rctree_edge_t*
Rctree_edge(modref_t* node, modref_t* mirror) {
  rctree_edge_t* edge =
    alloc(sizeof(rctree_edge_t),
          rctree_edge_init,
          node, mirror);
  return edge;  
}

rctree_link_t*
Rctree_link(modref_t* node_u,
            modref_t* node_v) {
  rctree_link_t* link =
    alloc(sizeof(rctree_link_t),
          rctree_link_init,
          node_u, node_v);

  write(link->uv.edge_modref, link->uv.edge);
  write(link->vu.edge_modref, link->vu.edge);

  return link;
}
