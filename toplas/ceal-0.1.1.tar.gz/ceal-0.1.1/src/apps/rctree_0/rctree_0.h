/* Matthew Hammer <hammer@tti-c.org> */
/* Rake-Compress Trees. */

#ifndef __SLIME_RCTREE_0__
#define __SLIME_RCTREE_0__

#define SLIME_RCTREE_0_DEBUG 0

#include "ceal.h"
#include "conscell.h"

typedef struct rctree_node_s {
  uintptr_t id;         /* unique id -- shared only by descendents */
  uintptr_t coin_toss;  /* psuedo-random bit, 0='tails', 1='heads' */
  modref_t* sing;       /* singleton flag, holds 0 or 1, (1 iff a leaf). */
  modref_t* edges;      /* modlist of edge modrefs */
  modref_t* desc;       /* NULL or descendent-copy of node */
} rctree_node_t;

/* Edges: Each undirected edge in the tree is represented by two
   directed edges, whose type is given below.  Each directed edge in
   the pair holds a modref to the other, which we refer to as its
   "mirror".  Moreover, each (directed) edge holds a modref to its
   descendent, initially left empty.  During tree-contraction, each
   (directed) edge's descendent is setup by the edge's _target_ node,
   as opposed to its source node.  */
typedef struct rctree_edge_s {
  modref_t* node;   /* Adjacent node. */
  modref_t* mirror; /* Modref holding the 'mirror' to this edge */
  modref_t* desc;   /* Descendent of this edge. */
} rctree_edge_t;

/* An rctree_setup record represents a randomly-generated tree.  The
   nodelist field is suitable as an argument for tree-contraction.
   The other fields make it more convenient to change (mutate) the
   tree.  */
typedef struct rctree_setup_s {
  uintptr_t       nodec;
  rctree_node_t** nodes;
  modref_t**      node_modrefs;
  modref_t**      edgelist_ends;
  uintptr_t*      degrees;
  modref_t*       nodelist;
  modref_t*       dummy; /* <-- TEMP. */
} rctree_setup_t;

/* Abstraction for a pair of directed edges that form a single undirected edge. */
typedef struct rctree_link_s {
  modref_t* node_u;
  modref_t* node_v;
  struct {
    modref_t*      edge_modref;
    rctree_edge_t* edge;
    /*cons_cell_t*   edge_cell;*/
  } uv, vu;
} rctree_link_t;

rctree_node_t*  Rctree_node(uintptr_t id);
rctree_edge_t*  Rctree_edge(modref_t* node, modref_t* mirror);
rctree_link_t*  Rctree_link(modref_t* node_u, modref_t* node_v);

rctree_setup_t* rctree_random(uintptr_t n, uintptr_t max_degree);
void            rctree_print(modref_t* nodes, FILE* f);
afun            rctree_contract(modref_t* nodes, modref_t* dest, modref_t* dummy);

void            rctree_link(rctree_link_t* link_to_link);
void            rctree_cut(rctree_link_t* link_to_cut);

#endif
