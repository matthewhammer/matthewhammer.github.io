/* Matthew Hammer <hammer@tti-c.org> */

#include "rctree_0.h"
#include "hash.h"
#include "modlist.h"

rctree_setup_t*
rctree_random(uintptr_t n, uintptr_t max_degree)
{
  rctree_setup_t* setup = malloc(sizeof(rctree_setup_t));
  setup->nodec = n;
  setup->nodes = malloc(n * sizeof(rctree_node_t*));
  setup->node_modrefs = malloc(n * sizeof(modref_t*));
  setup->edgelist_ends = malloc(n * sizeof(modref_t*));
  setup->degrees = malloc(n * sizeof(uintptr_t));

  /* TEMP */ {
    setup->dummy = modref();
    write(setup->dummy, (void*)0);
  }
  
  /* Create n nodes and n uninitialized edgelists */
  for(int i = 0; i < n; i++) {
    rctree_node_t* node = Rctree_node(i);
    setup->nodes[i] = node;
    setup->edgelist_ends[i] = node->edges;
    
    setup->node_modrefs[i] = modref();
    write(setup->node_modrefs[i], node);
    setup->degrees[i] = 0;
  }
  
  /* Create (n - 1) edges */
  for(int i = 1; i < n; i++) {
    int j;
    
    /* Pick j such that degrees[j] < max_degree */
    while((j = rand() % i),
          setup->degrees[j] >= max_degree){}
    
    setup->degrees[i] += 1;
    setup->degrees[j] += 1;

    /* TODO: a lot of this is now repeated in rctree_link_init(): */
    modref_t* edge_ij_modref = modref();
    modref_t* edge_ji_modref = modref();
    
    rctree_edge_t* edge_ij = Rctree_edge(setup->node_modrefs[j], edge_ji_modref);
    rctree_edge_t* edge_ji = Rctree_edge(setup->node_modrefs[i], edge_ij_modref);
    
    write(edge_ij_modref, edge_ij);
    write(edge_ji_modref, edge_ji);
    
    cons_cell_t* edge_ij_cell = Cons(edge_ij_modref);
    cons_cell_t* edge_ji_cell = Cons(edge_ji_modref);
    
    write(setup->edgelist_ends[i], edge_ij_cell);
    write(setup->edgelist_ends[j], edge_ji_cell);
    
    setup->edgelist_ends[i] = edge_ij_cell->tl;
    setup->edgelist_ends[j] = edge_ji_cell->tl;
  }
  
  /* Terminate each edgelist */
  for(int i = 0; i < n; i++) {
      write(setup->edgelist_ends[i], NULL);
  }
  
  /* Mark singleton nodes.  */
  for(int i = 0; i < n; i++) {
    if(setup->degrees[i] <= 1)
        write(setup->nodes[i]->sing, 1);
  }

  setup->nodelist = modlist_ofarray(n, setup->node_modrefs);
  
  return setup;
}

void rctree_link(rctree_link_t* link_to_link) {
  rctree_link_t* link = link_to_link;
  abort();
}


void rctree_cut(rctree_link_t* link_to_cut) {
  rctree_link_t* link = link_to_cut;
  abort();
}


void
rctree_print(modref_t* nodes, FILE* f) {
  cons_cell_t* node_cell = NULL;
  fprintf(f, "digraph {\n");
  node_cell = modref_deref(nodes);
  while(node_cell) {
    rctree_node_t* node = modref_deref(node_cell->hd);

    fprintf(f, "node_%d [label=\"%d\\n%d %s\"];\n",
            node->id, node->id, node->coin_toss,
            modref_deref(node->sing) ? ", S" : ""
            );

    /* Spit-out "out-going" edges for node */
    {
      cons_cell_t* edge_cell = modref_deref(node->edges);
      while(edge_cell) {
        if(1) {
          rctree_edge_t* edge = modref_deref(edge_cell->hd); 
          rctree_node_t* edge_node = modref_deref(edge->node);
          fprintf(f, "node_%d -> node_%d;\n", node->id, edge_node->id);
        }
        edge_cell = modref_deref(edge_cell->tl);
      }
    }
    node_cell = modref_deref(node_cell->tl);
  }
  fprintf(f, "}\n");
}

