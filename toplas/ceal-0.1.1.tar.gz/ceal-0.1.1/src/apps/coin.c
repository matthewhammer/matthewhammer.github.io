#include <stdlib.h>
#include "coin.h"
#include "hash.h"

struct coin_s {
  uintptr_t seed1;
  uintptr_t seed2;
  uintptr_t bias;
};

#define DEF_COIN(BIAS) \
  ifun coin_init_##BIAS(coin_t* coin) {\
    coin->seed1 = rand();\
    coin->seed2 = rand();\
    coin->bias = BIAS;\
  }\
  coin_t* Coin_biased_##BIAS() {\
    return alloc(sizeof(coin_t), coin_init_##BIAS);\
  }

DEF_COIN(2);
DEF_COIN(4);
DEF_COIN(8);
DEF_COIN(16);

coin_t* Coin_fair() {
  return Coin_biased_2();
}

int coin_flip(coin_t* coin, void* x) {
  uintptr_t a = coin->seed1;
  uintptr_t b = coin->seed2;
  uintptr_t c = (uintptr_t) x;

  /* Mix the three words into [c] */
  mix(a, b, c);
  
  /* Modulus with the bias */
  return c % coin->bias;
}
