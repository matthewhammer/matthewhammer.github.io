#include "ceal.h"
#include "modlist.h"

void modstack_init(modref_t* stack) {
  write(stack, NULL);
}

afun modstack_push(modref_t* stack, void* x) {
  cons_cell_t* c_1 = Cons(x);
  cons_cell_t* c_0 = read(stack);
  write(c_1->tl, c_0);
  write(stack, c_1);
}
