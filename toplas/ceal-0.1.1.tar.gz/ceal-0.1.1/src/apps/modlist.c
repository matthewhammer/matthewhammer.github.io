#include <stdlib.h>
#include <stdio.h>
#include "modlist.h"
#include "coin.h"
#include "pair.h"
#include "logging.h"

modref_t* modlist_random(int n, void*(*gen_elt)(void)) {
  modref_t* list = modref();
  modref_t* tail = list;
   for(int i = 0; i < n; i++) {
    cons_cell_t* c = Cons(gen_elt());
    write(tail, c);
    tail = c->tl;
  }
  
  write(tail, NULL);
  return list;
}

modref_t* modlist_ofarray(int hdc, void** hds) {
  modref_t* list = modref();
  modref_t* tail = list;
  
  for(int i = 0; i < hdc; i++) {
    cons_cell_t* c = Cons(hds[i]);
    write(tail, c);
    tail = c->tl;
  }
  
  write(tail, NULL);
  return list;
}

modref_t* modlist_getend(modref_t* list) {
  modref_t* end = list;
  cons_cell_t* c = modref_deref(modref);  
  while(c) {
    end = c->tl;
    c = modref_deref(end);      
  }
  return end;
}

void modlist_print(modref_t* modref, FILE* f, void(*print_elt)(void* elt, FILE* f)) {
  cons_cell_t* c = modref_deref(modref);
  fprintf(f,"[");
  while(c) {
    print_elt(c->hd, f);
    c = modref_deref(c->tl);
    if(c) fprintf(f,"; ");    
  }
  fprintf(f,"]");
}

uintptr_t modlist_equals(modref_t* list1, modref_t* list2) {
  cons_cell_t* c1 = modref_deref(list1);
  cons_cell_t* c2 = modref_deref(list2);

  while(c1 && c2) {
    if(c1->hd != c2->hd)
      return 0;
    c1 = modref_deref(c1->tl);
    c2 = modref_deref(c2->tl);
  }
  
  if(!c1 && !c2)
    return 1;
  else
    return 0;  
}

uintptr_t modlist_equals_pred(modref_t* list1, modref_t* list2,
                              uintptr_t(*eq_elt)(void* elt_1, void* elt_2))
{
  cons_cell_t* c1 = modref_deref(list1);
  cons_cell_t* c2 = modref_deref(list2);

  while(c1 && c2) {
    if(!eq_elt(c1->hd, c2->hd))
      return 0;
    
    c1 = modref_deref(c1->tl);
    c2 = modref_deref(c2->tl);
  }
  
  if(!c1 && !c2)
    return 1;
  else
    return 0;  
}

void modlist_insert(modref_t* modref, void* element) {
  cons_cell_t* new_cell = Cons(element);
  cons_cell_t* tl = modref_deref(modref);
  write(new_cell->tl, tl);
  write(modref, new_cell);
}

void* modlist_remove(modref_t* modref) {
  cons_cell_t* c_dead = modref_deref(modref);
  void*        x_dead = c_dead->hd;
  cons_cell_t* c_tl = modref_deref(c_dead->tl);
  write(modref, c_tl);
  slime_kill(c_dead);  
  return x_dead;
}

afun traverse(cons_cell_t* c) {
  if(c == NULL) { }
  else {
    traverse(read(c->tl));
  }
}

afun map(cons_cell_t* c, void*(*f)(void*), modref_t* dest) {
    if(c == NULL) {
    write(dest, NULL);
  }
  else {
    cons_cell_t* c_new = Cons(f(c->hd));
    write(dest, c_new);
    map(read(c->tl), f, c_new->tl);
  }
}

afun filter(cons_cell_t* c, int(*f)(void*), modref_t* dest) {
  if(c == NULL)
    write(dest, NULL);
  else
    if(f(c->hd)) {
      cons_cell_t* c_new = Cons(c->hd);
      write(dest, c_new);
      filter(read(c->tl), f, c_new->tl);
    }
    else {
      filter(read(c->tl), f, dest);
    }
}

afun split(cons_cell_t* c,
           int(*f)(void* env, void* elt), void* f_env,
           modref_t* dest1, modref_t* dest2) {

  if(c == NULL) {
    write(dest1, NULL);
    write(dest2, NULL);
  }
  else {
    cons_cell_t* c_new = Cons(c->hd);
    if(f(f_env, c->hd)) {
      write(dest1, c_new);
      split(read(c->tl), f, f_env, c_new->tl, dest2);
    }
    else {
      write(dest2, c_new);
      split(read(c->tl), f, f_env, dest1, c_new->tl);
    }
  }
}

afun merge(cons_cell_t* c1, cons_cell_t* c2,
           int(*f)(void*, void*), modref_t* dest)
{
  if(c1 == NULL) {
    write(dest, c2);
  }
  else if(c2 == NULL) {
    write(dest, c1);
  }
  else
    if (f(c1->hd, c2->hd)) {
      cons_cell_t* c_new = Cons(c1->hd);
      write(dest, c_new);
      merge(read(c1->tl), c2, f, c_new->tl);
    }
    else {
      cons_cell_t* c_new = Cons(c2->hd);
      write(dest, c_new);
      merge(c1, read(c2->tl), f, c_new->tl);
    }
}

afun reverse_rec(cons_cell_t* c, cons_cell_t* reversed, modref_t* dest) {
  if(c == NULL) {
    write(dest, reversed);
  }
  else {
    cons_cell_t* c_new = Cons(c->hd);
    write(c_new->tl, reversed);
    reverse_rec(read(c->tl), c_new, dest);
  }
}

afun lenge(cons_cell_t* c, unsigned int n, modref_t* dest)
{
  if(n == 0) {
    if(c == NULL)
      write(dest, 1);
    else
      write(dest, 0);    
  }
  else if(c == NULL)
    write(dest, 1);
  else
    lenge(read(c->tl), n - 1, dest);
}

afun lenlt(cons_cell_t* c, unsigned int n, modref_t* dest)
{
  if(n == 0) {
    write(dest, 0);
  }
  else if(c == NULL) {
    write(dest, 1);
  }
  else
    lenlt(read(c->tl), n - 1, dest);
}

afun cross(modref_t* list_1, modref_t* list_2, modref_t* dest)
{
  cons_cell_t* cell_1 = read(list_1);
  
  if(cell_1 == NULL) {
    write(dest, NULL);
  }
  else {
    cons_cell_t* cell_2 = read(list_2);
    
    while(cell_2 != NULL) {
      pair_t* pair = Pair(cell_1->hd, cell_2->hd);
      cons_cell_t* cell_pair = Cons(pair);

      write(dest, cell_pair);
      dest = cell_pair->tl;
      
      cell_2 = read(cell_2->tl);
    }

    cross(cell_1->tl, list_2, dest);
  }
}
