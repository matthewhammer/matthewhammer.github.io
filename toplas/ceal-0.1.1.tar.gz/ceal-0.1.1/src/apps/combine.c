#include "coin.h"
#include "modlist.h"

/* This is deprecated --- use reduce (in reduce.c) instead */
afun combine(modref_t* list,
             void* (*op)(void* env, void* a, void* b),
             void* op_env, modref_t* dest) {
  
  /* Loop until the length of [list] is <= 1.*/
  /* Each iteration of this loop roughly halves the length of [list]. */
  while(1) {
    modref_t* len_is_one = modref();
    lenlt(read(list), 2, len_is_one);

    /* Is [list] at least two elements long? */
    if(read(len_is_one)) {
      /* No: Length of [list] is <= 1. */
      break;
    }
    else {
      /* Yes: Length of [list] is >= 2.  Compute a shorter [next_list]
         by combining some elements from [list].  During this
         combination, [c_1] ranges over the original [list].  [tail]
         keeps track of the tail modref of the [next_list] that
         results. */
      coin_t* coin = Coin_biased_16();
      modref_t *prev_list = list;
      modref_t *next_list = modref();
      modref_t *tail = next_list;
      cons_cell_t* c_1;

      list = next_list;
      c_1 = read(prev_list);
      
      while(c_1 != NULL) {
        void* val = c_1->hd;        
        
        while((c_1 = read(c_1->tl)),
              (c_1 != NULL && coin_flip(coin, c_1))) {
          val = op(op_env, val, c_1->hd);
        }

        cons_cell_t* c_2 = Cons(val);
        write(tail, c_2);
        tail = c_2->tl;
      }
      
      write(tail, NULL);
    }
  }

  /* Now length of the list is exactly 1.  Write this value as our
     result. */
  cons_cell_t* c = read(list);
  write(dest, c->hd);
}
