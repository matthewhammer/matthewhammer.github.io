#include <stdlib.h>
#include "ceal.h"
#include "exptrees.h"

static modref_t*
generate(int n) {
  return exptrees_random (n);
}


static void
print(modref_t* root, FILE* f) {
  
  node_t* n = modref_deref (root); 
  
  if (n->kind == LEAF) {
    leaf_t* l = (leaf_t*) n;
    fprintf (f, "%f", l->num);
  }
  else {
    fprintf (f, "(");
    print (n->left,f);

    if  (n->op == PLUS) {
      fprintf (f, " + ");      
    }
    else if  (n->op == MINUS) {
      fprintf (f, " - ");
    }
    else if  (n->op == TIMES) {
      fprintf (f, " * ");
    }
    else if  (n->op == DIV) {
      fprintf (f, " + ");
    }
    print (n->right,f);
    fprintf (f, ")");    
  }    
}

static int
equals(modref_t* m1, modref_t* m2) {
  return 0;
}

typedef struct iter_s {
  modref_t** leaves;
  int current;
  int size;
  leaf_t* leaf;
} iter_t;

static int numLeaves (modref_t* root) {
  node_t* node = modref_deref(root);
   
  if (node->kind == LEAF) {
    return 1;
  }
  else {
    return numLeaves (node->left) + numLeaves (node->right);
  }
}

static int findLeaves (modref_t* root, iter_t* iter, int i) {
  node_t* node = modref_deref (root);
   
  if (node->kind == LEAF) {
    iter->leaves[i] = root;
    return ++i;    
  }
  else {
    int j = findLeaves (node->left, iter,i);
    return findLeaves (node->right, iter,j);
  }
}


static void*
iter_new(modref_t* root) {
  int n = numLeaves (root);
  modref_t** leaves = malloc (sizeof (modref_t*) * n);
  iter_t* iter = malloc(sizeof(iter_t));
  iter->leaves = leaves;
  iter->current = 0;
  iter->size = n;
  iter->leaf = NULL;
  
  findLeaves (root,iter,0);

  return iter;
}

static void
iter_next(void* iter) {
  iter_t* i = iter;
  i->current++;
}

static int
iter_isdone(void* iter) {
  iter_t* i = iter;
  return i->current == (i->size)-1;
}

static void
change_forw(void* iter) {
  iter_t*    i = iter;
  
  modref_t* m = i->leaves[i->current];
  i->leaf = modref_deref (m);

  leaf_t* l = exptrees_leaf (100);
  write (m,l);
}

static void
change_back(void* iter) {
  iter_t*    i = iter;

  modref_t* m = i->leaves[i->current];

  leaf_t* l = modref_deref (m);
  slime_kill (l);

  write (m, i->leaf);
}

test_input_hooks_t test_input_exptrees = {
  generate,
  print,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};

test_output_hooks_t test_output_exptrees = {
  equals,
  print
};
