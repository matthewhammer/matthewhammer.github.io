#include "ceal.h"

/* output test hooks for [int] */
/* See: test_inout_int.c */
extern test_output_hooks_t test_output_int;

/* output test hooks for [float] */
/* See: test_inout_int.c */
extern test_output_hooks_t test_output_float;

/* output test hooks for [point2d] */
/* See: test_inout_point2d.c */
extern test_output_hooks_t test_output_point2d;

/* in/out test hooks for [int modlist] */
/* See: test_inout_int_modlist.c */
extern test_input_hooks_t test_input_int_modlist;
extern test_output_hooks_t test_output_int_modlist;

/* in/out test hooks for [char* modlist] */
/* See: test_inout_string_modlist.c */
extern test_input_hooks_t test_input_string_modlist;
extern test_output_hooks_t test_output_string_modlist;

/* in/out test hooks for [geom_point2d modlist] where points are drawn
   from (-1.0, 1.0) */
/* See: test_inout_point2d_modlist.c */
extern test_input_hooks_t test_input_point2d_modlist;
extern test_output_hooks_t test_output_point2d_modlist;

/* in/out test hooks for [geom_point2d modlist] where points are drawn
   from (1.0, 3.0) */
/* See: test_inout_point2d_modlist.c */
extern test_input_hooks_t test_input_point2d_B_modlist;
extern test_output_hooks_t test_output_point2d_B_modlist;

/* in/out test hooks for [exprtree] */
/* See: test_inout_exprtree.c */
extern test_input_hooks_t test_input_exprtree;
extern test_output_hooks_t test_output_exprtree;

/* in/out test hooks for [bstverif] */
/* See: test_inout_verif.c */
extern test_input_hooks_t test_input_bstverif;
extern test_output_hooks_t test_output_bstverif;

/* in/out test hooks for [bidigraph] */
/* See: test_inout_bidigraph.c */
extern test_input_hooks_t test_input_bidigraph;
/*extern test_output_hooks_t test_output_bidigraph;*/

/* in/out test hooks for [rctree] */
extern test_input_hooks_t test_input_rctree;
extern test_output_hooks_t test_output_rctree;

/* in/out test hooks for [rctree] */
extern test_input_hooks_t test_input_rctree3;
extern test_output_hooks_t test_output_rctree3;

/* in/out test hooks for [exptrees] */
extern test_input_hooks_t test_input_exptrees;
extern test_output_hooks_t test_output_exptrees;

/* in/out test hooks for [filter_sparse] */
extern test_input_hooks_t test_input_filter_sparse;
extern test_output_hooks_t test_output_filter_sparse;

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* See: [test_app_hooks_t.input_sizes] */
static void
test_input_sizes_for_1_input(int n, int* ns) {
  ns[0] = n;
}

/* See: [test_app_hooks_t.input_sizes] */
static void
test_input_sizes_for_2_equally_sized_inputs(int n, int* ns) {
  ns[0] = n / 2;
  ns[1] = n / 2;
}

