#include <stdlib.h>
#include <string.h>
#include "ceal.h"
#include "modlist.h"

#define STRING_SIZE 33

static char*
rand_string() {
  char* buff = basemm_malloc(STRING_SIZE);
  snprintf(buff, STRING_SIZE, "%032d", rand());
  return buff;
}

static modref_t*
generate(int n) {
  return modlist_random(n, rand_string);
}

static void
print_string(char* str, FILE* f) {
  fprintf(f, "%s", str);
}

static void
print(modref_t* modref, FILE* f) {
  modlist_print(modref, f, print_string);
}

static uintptr_t
string_eq(char* str1, char* str2) {
  return strcmp(str1, str2) == 0;
}

static int
equals(modref_t* m1, modref_t* m2) {
  return modlist_equals_pred(m1, m2, string_eq);
}

typedef struct iter_s {
  modref_t* modref;
} iter_t;

static void*
iter_new(modref_t* m) {
  iter_t* iter = malloc(sizeof(iter_t));
  iter->modref = m;
  return iter;
}

static void
iter_next(void* iter) {
  iter_t*      i = iter;
  modref_t*    m = i->modref;
  cons_cell_t* c = modref_deref(m);
  i->modref = c ? c->tl : NULL;
}

static int
iter_isdone(void* iter) {
  iter_t* i = iter;
  return i->modref == NULL;
}

static void
change_forw(void* iter) {
  iter_t*    i = iter;
  modref_t*  m = i->modref;
  modlist_insert(m, rand_string());
}

static void
change_back(void* iter) {
  iter_t*    i = iter;
  modref_t*  m = i->modref;
  char*    str = modlist_remove(m);
  basemm_free(STRING_SIZE, str);
}

test_input_hooks_t test_input_string_modlist = {
  generate,
  print,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};

test_output_hooks_t test_output_string_modlist = {
  equals,
  print
};
