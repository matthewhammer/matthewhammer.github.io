#include <assert.h>
#include <stdlib.h>
#include "rctree3.h"
#include "modlist.h"

static modref_t*
generate(int n) {
  modref_t* nodes = modref();
  rctree3_build(n, 0.5, nodes);
  return nodes;
}

static void
print_input(modref_t* nodes, FILE* f) {
  rctree3_print(nodes, f);
}

static void
print_output(modref_t* nodes, FILE* f) {
  rctree3_print(nodes, f);
}


static uintptr_t
eq_final_nodes(modref_t* m1, modref_t* m2) {
  rctree3_node_t* node1 = modref_deref(m1);
  rctree3_node_t* node2 = modref_deref(m2);

  if(0) {
    fprintf(stderr, "(%d == %d) |--> %d\n",
            node1->id, node2->id,
            node1->id == node2->id);
  }
  
  return node1->id == node2->id;
}

static int equals(modref_t* m1, modref_t* m2) {  
  return modlist_equals_pred(m1, m2, eq_final_nodes);
}

typedef struct iter_s {
  cons_cell_t* nodes;

  modref_t* node_a;
  modref_t* node_b;
  
  uintptr_t degree;
  uintptr_t adj_i;

  modref_t* ab_data;
} iter_t;


static void
begin_on_node(iter_t* i, modref_t* node) {
  i->node_a = node;
  i->degree = rctree3_node_degree(node);
  
  if(i->degree) {
    i->adj_i  = 0;
    i->node_b = rctree3_node_adj_i(node, 0);
  }
  else {
    abort();
  }  
}

static void*
iter_new(modref_t* modref_in) {
  iter_t* i = malloc(sizeof(iter_t));

  i->nodes = modref_deref(modref_in);
  begin_on_node(i, i->nodes->hd);
  
  return i;
}

static void
iter_next(void* iter) {
  iter_t* i = (iter_t*) iter;

  i->adj_i ++;
  
  if(i->adj_i < i->degree) {
    i->node_b = rctree3_node_adj_i(i->node_a, i->adj_i);
  }
  else {
    i->nodes = modref_deref(i->nodes->tl);
    begin_on_node(i, i->nodes->hd);
  }  
}

static int
iter_isdone(void* iter) {
  iter_t* i = (iter_t*) iter;
  return
    (i->nodes == NULL)
    ? 1
    : modref_deref(i->nodes->tl) == NULL;
}

static void
change_forw(void* iter) {
  iter_t* i = (iter_t*) iter;  
  i->ab_data = rctree3_cut(i->node_a, i->node_b);

#if 0
  rctree3_node_t* node_a = modref_deref(i->node_a);
  rctree3_node_t* node_b = modref_deref(i->node_b);
  fprintf(stderr, "cut %d %d\n", node_a->id, node_b->id);
#endif
}

static void
change_back(void* iter) {
  iter_t* i = (iter_t*) iter;
  rctree3_link(i->node_a, i->node_b, i->ab_data);

#if 0
  rctree3_node_t* node_a = modref_deref(i->node_a);
  rctree3_node_t* node_b = modref_deref(i->node_b);
  fprintf(stderr, "link %d %d\n", node_a->id, node_b->id);
#endif
}

test_input_hooks_t test_input_rctree3 = {
  generate,
  print_input,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};

test_output_hooks_t test_output_rctree3 = {
  equals,
  print_output
};
