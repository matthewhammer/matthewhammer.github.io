#include "ceal.h"

static void
print(modref_t* m, FILE* f) {
  fprintf(f, "%d", (int) modref_deref(m));
}

static int
equals(modref_t* m1, modref_t* m2) {
  intptr_t i1 = (intptr_t) modref_deref(m1);
  intptr_t i2 = (intptr_t) modref_deref(m2);
  /*fprintf(stderr, "%d == %d equals %d\n", i1, i2, i1 == i2);*/
  return (i1 == i2);
}

test_output_hooks_t test_output_int = {
  equals,
  print
};
