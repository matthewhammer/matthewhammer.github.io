#include <assert.h>
#include "../test_types.h"
#include "rctree_0.h"

static modref_t*
generate(int n) {
  rctree_setup_t* setup = rctree_random(n, 8);
  return (modref_t*) setup;
}

static void
print_input(modref_t* modref, FILE* f) {
  rctree_setup_t* setup = (rctree_setup_t*) modref;
  rctree_print(setup->nodelist, f);
}

static void
print_output(modref_t* modref, FILE* f) {
  rctree_node_t* node = modref_deref(modref);
  fprintf(f, "node %d", node->id);
}

static int equals(modref_t* m1, modref_t* m2) {
  rctree_node_t* node_1 = modref_deref(m1);
  rctree_node_t* node_2 = modref_deref(m2);
  return node_1->id == node_2->id;
}

typedef struct iter_s {
  rctree_setup_t* setup;
  
  /* Node u is the new leaf. */
  struct {
    modref_t*    modref;
    rctree_node_t* node;
  } u, v;

  /* setup->nodes[index] is node v */
  uintptr_t index;
  
  /* Link between u and v */
  rctree_link_t* link;

} iter_t;



static void*
iter_new(modref_t* modref_in) {
  iter_t* i = malloc(sizeof(iter_t));
  rctree_setup_t* setup = (rctree_setup_t*) modref_in;
  i->setup = setup;
  i->index = 0;
  
  /* Setup node u, the leaf we will link. */
  i->u.modref = modref();
  i->u.node = Rctree_node(setup->nodec);
  write(i->u.modref, i->u.node);
  write(i->u.node->sing, 1);
  write(i->u.node->edges, NULL);
  
  return i;
}

static void
iter_next(void* iter) {
  iter_t* i = (iter_t*) iter;
  i->index ++;
}

static int
iter_isdone(void* iter) {
  iter_t* i = (iter_t*) iter;
  return !(i->index < i->setup->nodec);
}

static void
increment_dummy(rctree_setup_t* setup) {
  write(setup->dummy, ((uintptr_t)(modref_deref(setup->dummy)))+1);
}

static void
change_forw(void* iter) {
  iter_t* i = (iter_t*) iter;

  /* node v is picked by current index */
  i->v.node = i->setup->nodes[i->index];
  i->v.modref = i->setup->node_modrefs[i->index];
    
  /* Create edges for new link */
  rctree_link_t* link = i->link = Rctree_link(i->u.modref, i->v.modref);
  
  /* Add edge u-->v to u's edges */
  /* Add edge v-->u to v's edges */
  modlist_insert(i->u.node->edges, link->uv.edge_modref);
  modlist_insert(i->v.node->edges, link->vu.edge_modref);
  
  /* Add node u to node list */
  modlist_insert(i->setup->nodelist, i->u.modref);
  
  /* Toggle singleton status of node v to "no". */
  write(i->v.node->sing, 0);

  /* TEMP */
  increment_dummy(i->setup);
}

static void
change_back(void* iter) {
  iter_t* i = (iter_t*) iter;

  /* Remove edges from nodes' edge lists */ 
  modlist_remove(i->u.node->edges);
  modlist_remove(i->v.node->edges);
  
  /* Remove node u from node list */
  modlist_remove(i->setup->nodelist);

  /* Toggle singleton status of node v, if needbe. */
  if(i->setup->degrees[i->index] <= 1)
    write(i->v.node->sing, 1);

  /* Clean-up the (memory for the) link */
  /* TODO: slime_kill(i->link); */
  
  i->link = NULL;

  /* TEMP */
  increment_dummy(i->setup);
}

test_input_hooks_t test_input_rctree = {
  generate,
  print_input,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};

test_output_hooks_t test_output_rctree = {
  equals,
  print_output
};
