#include "box.h"

static void
print(modref_t* m, FILE* f) {
  box_t* box = modref_deref(m);  
  fprintf(f, "%f", box->u._float);
}

static int
equals(modref_t* m1, modref_t* m2) {
  box_t* box_1 = modref_deref(m1);
  box_t* box_2 = modref_deref(m2);    
  return (box_1->u._float == box_2->u._float);
}

test_output_hooks_t test_output_float = {
  equals,
  print
};
