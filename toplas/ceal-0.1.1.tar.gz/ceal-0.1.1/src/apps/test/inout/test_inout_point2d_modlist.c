#include <stdlib.h>
#include "modlist.h"
#include "geom2d.h"

static float
randf(float min, float max) {
  return (max - min) * ((float) rand() / (RAND_MAX + 1.0)) + min;
}

static float
randf_uniform() {
  return randf(-0.99999999, 0.99999999);
}

static ifun
point2d_init_rand(geom2d_point_t* p) {
  p->x = randf_uniform();
  p->y = randf_uniform();
}

static geom2d_point_t*
point2d_rand() {
  return alloc(sizeof(geom2d_point_t), point2d_init_rand);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

static modref_t*
generate(int n) {
  return modlist_random(n, point2d_rand);
}

static void
print(modref_t* m, FILE* f) {
  modlist_print(m, f, geom2d_point_print);
}

static int
equals(modref_t* m1, modref_t* m2) {
  return modlist_equals(m1, m2);
}

typedef struct iter_s {
  modref_t* modref;
  cons_cell_t* orig_cell;
} iter_t;

static void*
iter_new(modref_t* m) {
  iter_t* iter = malloc(sizeof(iter_t));
  iter->modref = m;
  iter->orig_cell = NULL;
  return iter;
}

static void
iter_next(void* iter) {
  iter_t*         i = iter;
  modref_t*       m = i->modref;
  cons_cell_t*    c = modref_deref(m);
  i->modref = c ? c->tl : NULL;
}

static int
iter_isdone(void* iter) {
  iter_t* i = iter;
  return
    i->modref == NULL ||
    modref_deref(i->modref) == NULL;
}

#if 0
/* Deprecated Change Sequence: Insert-then-Delete */
static void
change_forw(void* iter) {
  iter_t*    i = iter;
  modref_t*  m = i->modref;  
  modlist_insert(m, point2d_rand());
}

static void
change_back(void* iter) {
  iter_t*    i = iter;
  modref_t*  m = i->modref;
  geom2d_point_t* p = modlist_remove(m);
  slime_kill(p);
}

#else
/* "Good" Change Sequence: Delete-Then-(re-)Insert */
static void
change_forw(void* iter) {
  iter_t*    i = iter;
  modref_t*  m = i->modref;
  i->orig_cell = modref_deref(m);
  write(m, modref_deref(i->orig_cell->tl));
}

static void
change_back(void* iter) {
  iter_t*    i = iter;
  modref_t*  m = i->modref;
  write(m, i->orig_cell);
}
#endif

test_input_hooks_t test_input_point2d_modlist = {
  generate,
  print,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};

test_output_hooks_t test_output_point2d_modlist = {
  equals,
  print,
};
