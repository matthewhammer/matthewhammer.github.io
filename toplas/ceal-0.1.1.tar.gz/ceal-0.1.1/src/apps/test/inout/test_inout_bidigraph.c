#include <stdlib.h>
#include "ceal.h"
#include "bidigraph.h"

static modref_t*
generate(int n) {
  return (modref_t*) bidigraph_generate(n);
}

static void
print(modref_t* modref, FILE* f) {
  bidigraph_t* graph = (bidigraph_t*) modref;
  bidigraph_print(graph, f);
}

typedef struct iter_s {
  bidigraph_t* graph;
  /* We do a random change at each node as follows.  Say we are at
     node, src, where edge1(src) goes to some other node, old_dst.  To
     perform a (forward) change we set edge1(src) to go to some
     randomly picked node, new_dst.  Then we change (back) edge1(src)
     to old_dst. */
  uintptr_t src_idx; /* source node of change-edge */
  bidigraph_node_t* new_dst;
  bidigraph_node_t* old_dst;
} iter_t;

static void*
iter_new(modref_t* m) {
  bidigraph_t* graph = (bidigraph_t*) m;
  iter_t* iter = malloc(sizeof(iter_t));
  iter->graph   = graph;
  iter->src_idx = 0;
  iter->old_dst = NULL;
  iter->new_dst = NULL;
  return iter;
}

static void
iter_next(void* iter) {
  iter_t* i = iter;
  i->src_idx ++;
}

static int
iter_isdone(void* iter) {
  iter_t* i = iter;
  return i->src_idx == i->graph->nodec;
}

static void
change_forw(void* iter) {
  iter_t* i = iter;

  bidigraph_node_t* src =
    i->graph->nodes[i->src_idx];  

  bidigraph_node_t* old_dst =
    modref_deref(src->edge2);

  bidigraph_node_t* new_dst =
    i->graph->nodes[rand() % i->graph->nodec];
    
  i->old_dst = old_dst;
  i->new_dst = new_dst;

  write(src->edge2, new_dst);
}

static void
change_back(void* iter) {
  iter_t* i = iter;
  
  bidigraph_node_t* src =
    i->graph->nodes[i->src_idx];
  
  write(src->edge2, i->old_dst);
}

test_input_hooks_t test_input_bidigraph = {
  generate,
  print,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};
