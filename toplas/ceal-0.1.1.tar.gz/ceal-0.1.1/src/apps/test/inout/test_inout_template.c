#include "../test_types.h"

static modref_t*
generate(int n) {


  return /* TODO -- generate data of size n */
}


static void
print(modref_t* modref, FILE* f) {
  /* TODO -- print data in modref to f */
}

static int
equals(modref_t* m1, modref_t* m2) {
  return /* TODO -- does result in m1 equal that in m2 ? */
}

typedef struct iter_s {
  /* TODO -- fields for iterator*/
} iter_t;

static void*
iter_new(modref_t* m) {
  iter_t* iter = malloc(sizeof(iter_t));
  /* TODO -- initialize the iterator */    
  return iter;
}

static void
iter_next(void* iter) {
  iter_t* i = iter;
  /* TODO -- advance iterator */
}

static int
iter_isdone(void* iter) {
  iter_t* i = iter;
  return /* TODO -- is it safe to call iter_next ? */
}

static void
change_forw(void* iter) {
  iter_t*    i = iter;
  /* TODO -- do forward change, e.g., an insertion. */
}

static void
change_back(void* iter) {
  iter_t*    i = iter;
  /* TODO -- do backward change, e.g., a deletion. */
}

test_input_hooks_t test_input_int_modlist = {
  generate,
  print,
  iter_new,
  iter_next,
  iter_isdone,
  change_forw,
  change_back
};

test_output_hooks_t test_output_int_modlist = {
  equals,
  print
};
