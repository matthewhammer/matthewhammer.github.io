#include "rctree3.h"
#include "../inout/test_inout.h"

static int
input_hooks(test_input_hooks_t** hooks) {
  rctree3_app = &rctree3_app_maxweight;
  hooks[0] = &test_input_rctree3;
  return 1;
}

static int
output_hooks(test_output_hooks_t** hooks) {
  hooks[0] = &test_output_rctree3;
  return 1;
}

static void
run(modref_t** inputs,
    modref_t** outputs)
{
  modref_t* TODO = modref();
  rctree3_contract_opt(inputs[0], outputs[0], TODO);
}

static test_app_hooks_t hooks = {
  input_hooks,
  output_hooks,
  test_input_sizes_for_1_input,
  run,
  verif(run),
};

test_app_t test_app_rctree3_maxweight = {"maxweight", &hooks};
