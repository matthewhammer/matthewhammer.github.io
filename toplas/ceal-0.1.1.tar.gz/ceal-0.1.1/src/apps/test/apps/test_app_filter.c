#include "modlist.h"
#include "../inout/test_inout.h"

static int
input_hooks(test_input_hooks_t** hooks) {
  hooks[0] = &test_input_int_modlist;
  return 1;
}

static int
output_hooks(test_output_hooks_t** hooks) {
  hooks[0] = &test_output_int_modlist;
  return 1;
}

static intptr_t
isodd (void* val) {
  intptr_t x = (intptr_t) val;
  x = (x / 3) + (x / 7) + (x / 9);  
  return x % 2;
}

static void
run( modref_t** inputs,
     modref_t** outputs) {
  scope();
  filter(read(inputs[0]), isodd, outputs[0]);
}

static test_app_hooks_t hooks = {
  input_hooks,
  output_hooks,
  test_input_sizes_for_1_input,
  run,
  verif(run),
};

test_app_t test_app_filter = {"filter", &hooks};
