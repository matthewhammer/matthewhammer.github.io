#include "quickhull.h"
#include "../inout/test_inout.h"

static int
input_hooks(test_input_hooks_t** hooks) {
  hooks[0] = &test_input_point2d_modlist;
  return 1;
}

static int
output_hooks(test_output_hooks_t** hooks) {
  hooks[0] = &test_output_point2d_modlist;
  return 1;
}

static void
run(modref_t** inputs,
    modref_t** outputs)
{
  /* TEMP (BUGFIX): */
  modref_t* m = modref();

  quickhull(inputs[0], outputs[0]);
}

static test_app_hooks_t hooks = {
  input_hooks,
  output_hooks,
  test_input_sizes_for_1_input,
  run,
  verif(run)
};

test_app_t test_app_quickhull = {"quickhull", &hooks};
