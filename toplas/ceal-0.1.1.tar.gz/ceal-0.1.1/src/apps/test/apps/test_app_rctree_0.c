#include "rctree_0.h"
#include "../test_types.h"
#include "../inout/test_inout.h"

static int
input_hooks(test_input_hooks_t** hooks) {
  hooks[0] = &test_input_rctree;
  return 1;
}

static int
output_hooks(test_output_hooks_t** hooks) {
  hooks[0] = &test_output_rctree;
  return 1;
}

static void
run(modref_t** inputs,
    modref_t** outputs) {
  modref_t* TODO = modref();
  rctree_setup_t* setup = (rctree_setup_t*) inputs[0];
  rctree_contract(setup->nodelist, outputs[0], setup->dummy);
}

static test_app_hooks_t hooks = {
  input_hooks,
  output_hooks,
  test_input_sizes_for_1_input,
  run,
  verif(run),
};

test_app_t test_app_rctree_0 = {"rctree_0", &hooks};
