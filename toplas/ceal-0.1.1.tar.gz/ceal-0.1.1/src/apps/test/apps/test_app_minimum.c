#include "modlist.h"
#include "reduce.h"
#include "../inout/test_inout.h"

static int
input_hooks(test_input_hooks_t** hooks) {
  hooks[0] = &test_input_int_modlist;
  return 1;
}

static int
output_hooks(test_output_hooks_t** hooks) {
  hooks[0] = &test_output_int;
  return 1;
}

static intptr_t
minint(void* dummy, intptr_t i1, intptr_t i2) {
  return (i1 < i2 ? i1 : i2);
}

static void
run(modref_t** inputs,
    modref_t** outputs) {

  /* TEMP (BUGFIX): */
  modref_t* m = modref();

  reduce(inputs[0], minint, NULL, outputs[0]);
}

static test_app_hooks_t hooks = {
  input_hooks,
  output_hooks,
  test_input_sizes_for_1_input,
  run,
  verif(run),
};

test_app_t test_app_minimum = {"minimum", &hooks};
