#include "diameter.h"
#include "../inout/test_inout.h"

static int
input_hooks(test_input_hooks_t** hooks) {
  hooks[0] = &test_input_point2d_modlist;
  hooks[1] = &test_input_point2d_B_modlist;
  return 2;
}

static int
output_hooks(test_output_hooks_t** hooks) {
  hooks[0] = &test_output_float;
  return 1;
}

static void
run(modref_t** inputs,
    modref_t** outputs)
{
  /* TEMP (BUGFIX): */
  modref_t* m = modref();

  distance(inputs[0], inputs[1], outputs[0]);
}

static test_app_hooks_t hooks = {
  input_hooks,
  output_hooks,
  test_input_sizes_for_2_equally_sized_inputs,
  run,
  verif(run)
};

test_app_t test_app_distance = {"distance", &hooks};
