/* Matthew Hammer <hammer@tt-c.org> */

#ifndef __CONSCELL_H__
#define __CONSCELL_H__

#include "ceal.h"

typedef struct cons_cell_s cons_cell_t;

cons_cell_t* Cons(void* hd);

#if !SLIME_CONSCELL_PACK
struct cons_cell_s {
  void* hd;
  modref_t* tl;
};
#else
struct cons_cell_s {
  void* hd;
  modref_t* tl[0];
  modref_t tl_modref;
};
#endif

ifun cons_cell_init(cons_cell_t* c, void* hd);

#endif
