/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __PAIR_H__
#define __PAIR_H__

#include "ceal.h"

typedef struct pair_s pair_t;

pair_t* Pair(void* fst, void* snd);

struct pair_s {
  void* fst;
  void* snd;
};

#endif
