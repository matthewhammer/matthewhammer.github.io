#include "mergesort.h"
#include "logging.h"
#include "coin.h"

afun mergesort_halve(coin_t* coin,
                     cons_cell_t* cell,
                     modref_t* dest1,
                     modref_t* dest2) {
  if(!cell) {
    write(dest1, NULL);
    write(dest2, NULL);
  }
  else {
    cons_cell_t* new_cell = Cons(cell->hd);
    
    if (coin_flip(coin, cell->hd)) {
      write(dest1, new_cell);
      mergesort_halve(coin, read(cell->tl), new_cell->tl, dest2);
    }
    else {
      write(dest2, new_cell);
      mergesort_halve(coin, read(cell->tl), dest1, new_cell->tl);
    }
  }
}

afun merge_sort(int (*isle)(void*, void*),
                modref_t* unsorted,
                modref_t* dest)
{
  modref_t* lenlt2 = modref();
  
  lenlt(read(unsorted), 2, lenlt2);

  if(read(lenlt2)) {
    write(dest, read(unsorted));
  }
  else {
    modref_t *unsorted_a = modref();
    modref_t *unsorted_b = modref();
    coin_t* coin = Coin_fair();

    scope();
    mergesort_halve(coin, read(unsorted), unsorted_a, unsorted_b);
    
    modref_t* sorted_a = modref();
    merge_sort(isle, unsorted_a, sorted_a);

    modref_t* sorted_b = modref();
    merge_sort(isle, unsorted_b, sorted_b);

    scope();
    merge(read(sorted_a), read(sorted_b), isle, dest);
  }
}
