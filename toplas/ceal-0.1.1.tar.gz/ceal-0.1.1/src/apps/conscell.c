#include "conscell.h"

#if !SLIME_CONSCELL_PACK
ifun cons_cell_init(cons_cell_t* c, void* hd) {
  c->hd = hd;
  logg("cell=%p head=%p (%d)", c, hd, hd);
  c->tl = modref();
}
#else
ifun cons_cell_init(cons_cell_t* c, void* hd) {
  c->hd = hd;
  logg("cell=%p head=%p (%d)", c, hd, hd);
  modref_init(c->tl);
}
#endif

cons_cell_t* Cons(void* hd) {
  return alloc(sizeof(cons_cell_t),
               &cons_cell_init,
               (void*)(hd));
}
