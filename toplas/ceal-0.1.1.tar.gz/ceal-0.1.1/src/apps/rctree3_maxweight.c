/* Matthew Hammer <hammer@tti-c.org> */

#include "rctree3.h"
#include <stdlib.h>
#include <stdio.h>

intptr_t max(intptr_t a, intptr_t b) {
  return a > b ? a : b;
}

static modref_t*
gen_node_data(int degree) {
  return NULL;
}

static modref_t*
gen_edge_data() {
  modref_t* edge_data = modref();
  write(edge_data, rand() % 64);  
  return edge_data;
}

static afun
finalize(rctree3_node_t* node,
         rctree3_slots_t* slots,
         modref_t* node_data,
         modref_t* scar_data_0,
         modref_t* scar_data_1,
         modref_t* scar_data_2,
         modref_t* node_data_dest) {
  intptr_t a, b, c;

  a = scar_data_0 ? read(scar_data_0) : INTPTR_MIN;
  b = scar_data_1 ? read(scar_data_1) : INTPTR_MIN;
  c = scar_data_2 ? read(scar_data_2) : INTPTR_MIN;

  write(node_data_dest, max(a, max(b, c)));
}

static afun
rake (rctree3_node_t* node,
      rctree3_slots_t* slots,
      modref_t* node_data,
      modref_t* edge_data,
      modref_t* scar_data_0,
      modref_t* scar_data_1,
      modref_t* scar_data_dest) {
  intptr_t a, b, c;

  a = read(edge_data);
  b = scar_data_0 ? read(scar_data_0) : INTPTR_MIN;
  c = scar_data_1 ? read(scar_data_1) : INTPTR_MIN;

  write(scar_data_dest, max(a, max(b, c)));  
}

static afun
compress(rctree3_node_t* node,
         rctree3_slots_t* slots,
         modref_t* node_data,
         modref_t* edge_data_0,
         modref_t* edge_data_1,
         modref_t* scar_data,
         modref_t* edge_data_dest) {
  intptr_t a, b, c;
  
  a = read(edge_data_0);
  b = read(edge_data_1);
  c = scar_data ? read(scar_data) : INTPTR_MIN;

  write(edge_data_dest, max(a, max(b, c)));  

}

static void
print_node_data(modref_t* node_data, FILE* file) {
  /* none. */
}

static void
print_weight(modref_t* weight, FILE* file) {
  intptr_t w = modref_deref(weight);

  if(w > INTPTR_MIN)
    fprintf(file, "%ld", (long) w);
  else    
    fprintf(file, "-inf");
}


rctree3_app_t rctree3_app_maxweight =
  { "maxweight",
    gen_node_data, gen_edge_data,
    finalize, rake, compress,
    verif(finalize), verif(rake), verif(compress),
    print_node_data,
    print_weight,
    print_weight
  };
