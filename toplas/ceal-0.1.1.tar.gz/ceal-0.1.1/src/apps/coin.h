#ifndef __COIN_H__
#define __COIN_H__

#include "ceal.h"

/* Coins -- Allow self-adjusting programs to make random decisions
   while maintaining necessary stability.

   Once a coin has been constructed (which is usually random), the
   user can "flip" a coin deterministically by supplying a word-value
   [x] (see: [coin_flip]).  The outcome of a flip given an [x] will
   either be 0 or 1.  Given the same [x] and the same coin, the
   outcome will always be the same.  Since a coin is deterministic,
   the program using such a coin is stable in the sense than
   re-evaluation of any series of identitical flips will yield
   identitical results.

   Each coin also carries a bias which controls the expected outcome
   of coin flips (expectation taken over all values of [x]).  A bias
   of 1 isn't interesting, any coin flip will yield 0. A bias of 2
   will yield a fair coin where the outcome of a flip is equally
   likely to be 0 or 1.  A biased coin is one where the bias is
   greater than 2, in which case the outcome of a coin flip is more
   likely to be 1 than 0.
*/

typedef struct coin_s coin_t;

coin_t* Coin_fair();
coin_t* Coin_biased_4();
coin_t* Coin_biased_8();
coin_t* Coin_biased_16();

/* Coin flipping -- given a word [x], flips the coin deterministically
   for [x] and returns either 1 or 0.  If the coin is biased, the
   expected number of 0's (expectation taken over all possible values
   for [x]) is _less_ than the number of 1's.  Higher biases will
   yield lower expectations of flipping a 0. */
int coin_flip(coin_t* coin, void* x);

#endif
