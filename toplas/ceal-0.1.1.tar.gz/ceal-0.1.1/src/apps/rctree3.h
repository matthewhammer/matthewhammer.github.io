/* Matthew Hammer <hammer@tti-c.org> */
/* Rake-Compress Trees. */

#ifndef __SLIME_RCTREE3__
#define __SLIME_RCTREE3__

#define SLIME_RCTREE3_DEBUG 0

#include "ceal.h"
#include "conscell.h"

typedef struct rctree3_node_s {
  uintptr_t id;

  /* TODO (Space Opt.): Pack the following 3 words into 1 word. */
  uintptr_t sing;
  uintptr_t final;
  uintptr_t dice;

  /* TODO (Space Opt.): Pack the following 2 modrefs. */
  modref_t* desc;
  modref_t* slots;

  modref_t* data;
} rctree3_node_t;

typedef struct rctree3_slots_s {
  uintptr_t degree;
  modref_t* slotv[3];
  
  /* Slot i holds either:
   *  (rctree3_edge_t*) modref ---  if (i < degree)
   *  NULL / data modref       ---  otherwise.
   */
} rctree3_slots_t;

typedef struct rctree3_edge_s {

  modref_t* node;   /* (rctree3_node_t*) */
  modref_t* mirror; /* (rctree3_edge_t*) */

  /* TODO (Space Opt.): Pack the following 1 modrefs. */
  modref_t* desc;   /* (rctree3_edge_t*) */
  
  modref_t* data;
} rctree3_edge_t;

/* == Data Operations == */
typedef struct rctree3_app_s {
  const char* name;
  modref_t* (*gen_node_data)(int degree);
  modref_t* (*gen_edge_data)();
  
  afun (*finalize)    (rctree3_node_t* node,
                       rctree3_slots_t* slots,
                       modref_t* node_data,
                       modref_t* scar_data_0,
                       modref_t* scar_data_1,
                       modref_t* scar_data_2,
                       modref_t* node_data_dest);

  
  afun (*rake)     (rctree3_node_t* node,
                    rctree3_slots_t* slots,
                    modref_t* node_data,
                    modref_t* edge_data,
                    modref_t* scar_data_0,
                    modref_t* scar_data_1,
                    modref_t* scar_data_dest);

  afun (*compress) (rctree3_node_t* node,
                    rctree3_slots_t* slots,
                    modref_t* node_data,
                    modref_t* edge_data_0,
                    modref_t* edge_data_1,
                    modref_t* scar_data,
                    modref_t* edge_data_dest);

  
  void (*finalize_verif) (rctree3_node_t* node,
                          rctree3_slots_t* slots,
                          modref_t* node_data,
                          modref_t* scar_data_0,
                          modref_t* scar_data_1,
                          modref_t* scar_data_2,
                          modref_t* node_data_dest);

  void (*rake_verif)     (rctree3_node_t* node,
                          rctree3_slots_t* slots,
                          modref_t* node_data,
                          modref_t* edge_data,
                          modref_t* scar_data_0,
                          modref_t* scar_data_1,
                          modref_t* scar_data_dest);

  void (*compress_verif) (rctree3_node_t* node,
                          rctree3_slots_t* slots,
                          modref_t* node_data,
                          modref_t* edge_data_0,
                          modref_t* edge_data_1,
                          modref_t* scar_data,
                          modref_t* edge_data_dest);

  void (*print_node_data)(modref_t* node_data, FILE* file);
  void (*print_final_data)(modref_t* final_data, FILE* file);
  void (*print_edge_data)(modref_t* edge_data, FILE* file);
} rctree3_app_t;

extern rctree3_app_t rctree3_app_nop;
extern rctree3_app_t rctree3_app_maxweight;
extern rctree3_app_t rctree3_app_arithexp;

extern rctree3_app_t* rctree3_app;
  

/* == Allocation Operations == */

rctree3_node_t*  Rctree3_Node(uintptr_t id,
                              uintptr_t sing,
                              modref_t* data);

rctree3_node_t*  Rctree3_Node_Desc(rctree3_node_t* ansc,
                                   uintptr_t sing,
                                   uintptr_t final,
                                   rctree3_slots_t* slots);

rctree3_node_t*  Rctree3_Final(rctree3_node_t* ansc);

rctree3_edge_t* Rctree3_Edge(modref_t* node,
                             modref_t* mirror,
                             modref_t* data);

rctree3_edge_t*  Rctree3_Edge_Compressed(modref_t* node,
                                         modref_t* mirror);

rctree3_slots_t* Rctree3_Slots(uintptr_t degree,
                               modref_t* slot_0,
                               modref_t* slot_1,
                               modref_t* slot_2);


/* == Common Operations (common to both the original implementation and the hand-optimized one) */

afun rctree3_final_node(rctree3_node_t* node,
                        rctree3_slots_t* slots);

afun rctree3_rake_node(rctree3_node_t* node,
                       rctree3_slots_t* slots,
                       rctree3_edge_t* edge_NA,
                       rctree3_edge_t* edge_AN);


afun rctree3_compress_node(rctree3_node_t* node, rctree3_slots_t* slots,
                           rctree3_edge_t* edge_NA, rctree3_node_t* node_A, rctree3_edge_t* edge_AN,
                           rctree3_edge_t* edge_NB, rctree3_node_t* node_B, rctree3_edge_t* edge_BN);

modref_t* rctree3_edge_desc(rctree3_node_t* a, rctree3_edge_t* ab,
                            rctree3_node_t* b, rctree3_edge_t* ba);

afun rctree3_print_hook(uintptr_t dummy, uintptr_t roundc, modref_t* nodes);

/* == Tree-Contraction == */

afun rctree3_contract(modref_t* nodes, modref_t* dest, modref_t* dummy);
afun rctree3_contract_opt(modref_t* nodes, modref_t* dest, modref_t* dummy);


/* == Meta Operations == */

void rctree3_build(uintptr_t n, float frac2, modref_t* dest);

void rctree3_print(modref_t* nodes, FILE* file);

modref_t* rctree3_cut(modref_t* node_a,
                      modref_t* node_b);

void rctree3_link(modref_t* node_a,
                  modref_t* node_b,
                  modref_t* data);

uintptr_t rctree3_node_degree(modref_t* a);

modref_t* rctree3_node_adj_i(modref_t* a, uintptr_t i);



#endif
