/* Matthew Hammer <hammer@tti-c.org> */

#include "sdest.h"
#include "hash.h"

ifun sdest_init(sdest_t* sdest) {
  modref_init(sdest->sdest);
}

sdest_t* Sdest(modref_t* dest) {
  sdest_t* sdest = alloc(sizeof(sdest_t), &sdest_init);
  write(sdest->sdest, dest);
  return sdest;
}

afun sdest_copy(modref_t* dest, void* value) {
  write(dest, value);  
}

sdest_t* sdest_next(sdest_t* sdest, void* value, modref_t* dest) {
  uintptr_t a, b, c;
  a = b = (uintptr_t) sdest;
  c = (uintptr_t) value;
  mix(a,b,c);

  /* -- Write given value into current dest held by sdest */
  sdest_copy(read(sdest->sdest), value);

  /* -- Probabilistically choose a new sdest or replace dest in current sdest. */
  if(c % 8) {    
    sdest_t* sdest = Sdest(dest);
    return sdest;
  }
  else {
    write(sdest->sdest, dest);
    return sdest;
  }
}

void sdest_done(sdest_t* sdest, void* value) {
  /* -- Write given value into current dest held by sdest */
  sdest_copy(read(sdest->sdest), value);
}
