#include <stdlib.h>
#include "ceal.h"
#include "bidigraph.h"

#if SLIME_CONSCELL_PACK
ifun bidigraph_node_init(bidigraph_node_t* node, uintptr_t id) {
  node->id = id;
  modref_init(node->flag);
  modref_init(node->edge1);
  modref_init(node->edge2);
}
#else
#error "not supported."
#endif

bidigraph_node_t*
Bidigraph_node(uintptr_t id) {
  bidigraph_node_t* node =
    alloc(sizeof(bidigraph_node_t),
          &bidigraph_node_init, id);
  return node;
}

bidigraph_t*
bidigraph_generate(uintptr_t n) {
  bidigraph_t* graph = malloc(sizeof(bidigraph_t));
  bidigraph_node_t** nodes = malloc(sizeof(bidigraph_node_t*) * n);
  uintptr_t i;

  /* Create all nodes */
  for(i = 0; i < n; i++) {
    nodes[i] = Bidigraph_node(i);
  }

#if 0
  /* Strategy #1 */
  /* Randomly link the nodes -- all nodes have out-degree 2. */
  /* Expected Update Time for random edge ins/rem: O(n) (??) */
  for(i = 0; i < n; i++) {
    write(nodes[i]->flag, NULL);
    write(nodes[i]->edge1, nodes[rand() % n]);
    write(nodes[i]->edge2, nodes[rand() % n]);    
  }

#elif 0
  /* Strategy #2 */
  /* Make a balanced binary tree. */
  /* Expected Update Time for random edge ins/rem: O(log n) */
  for(i = 0; i < n; i++) {
    write(nodes[i]->flag, NULL);
    
    if(i < (n>>1)) {
      write(nodes[i]->edge1, nodes[(i << 1) + 0]);
      write(nodes[i]->edge2, nodes[(i << 1) + 1]);
    }
    else {
      /* TODO: we should use make this graph cyclic right here. */
      /* One possibility is to create a back-edges to ancestors. */
      write(nodes[i]->edge1, NULL);
      write(nodes[i]->edge2, NULL);
     }
  }
#endif

  
  /* Initialize the graph, return it. */
  graph->nodes = nodes;
  graph->nodec = n;

  return graph;
}

/* print the binary directed graph as a dot file (see: manpage for dot(1)). */
void bidigraph_print(bidigraph_t* graph, FILE* f) {
  uintptr_t i;  
  fprintf(f, "digraph {\n");  
  for(i = 0; i < graph->nodec; i++) {
    bidigraph_node_t* node0 = graph->nodes[i];
    bidigraph_node_t* node1 = modref_deref(node0->edge1);
    bidigraph_node_t* node2 = modref_deref(node0->edge2);
    fprintf(f, "n_%p [label=\"%d\"];\n", node0, i);
    fprintf(f, "n_%p -> n_%p [label=\"1\"];\n", node0, node1);
    fprintf(f, "n_%p -> n_%p [label=\"2\"];\n", node0, node2);
  }
  fprintf(f, "}\n");
}

static afun 
append_step(cons_cell_t* list1_begin, modref_t* list1_end,
            cons_cell_t* list2_begin, modref_t* list2_end,
            modref_t*    out_begin,   modref_t* out_end)
{
  cons_cell_t* begin;
  modref_t* end;

  /* Choose the first cell of output-list. */
  if(list1_begin)      begin = list1_begin;
  else if(list2_begin) begin = list2_begin;
  else                 begin = NULL;

  /* Choose the last modref of output-list. */
  if(list2_begin)      end = list2_end;
  else if(list2_begin) end = list1_end;
  else                 end = out_begin;

  write(out_begin, begin);
  write(out_end, end);  
}

afun bidigraph_topsort_rec(bidigraph_node_t* node,
                           modref_t* m_00,  
                           modref_t* m_01)
{
  if(!node || read(node->flag)) {
    write(m_00, NULL);
    write(m_01, m_00);
  }
  else {
    write(node->flag, 1);
    cons_cell_t* c = Cons(node->id);
    modref_t* m_10 = modref();
    modref_t* m_11 = modref();
    modref_t* m_20 = modref();
    modref_t* m_21 = modref();
    
    write(m_00, c);

    bidigraph_topsort_rec(read(node->edge1), m_10, m_11);
    bidigraph_topsort_rec(read(node->edge2), m_20, m_21);

    append_step(read(m_10), read(m_11),
                read(m_20), read(m_21),
                c->tl, m_01);
  }
}

afun bidigraph_topsort(bidigraph_node_t* root,
                       modref_t* dest) {
  modref_t* last = modref();
  bidigraph_topsort_rec(root, dest, last);
  write(read(last), NULL);
}

