/* Matthew Hammer <hammer@tt-c.org> */

#ifndef __MODLIST_H__
#define __MODLIST_H__

#include "ceal.h"
#include "conscell.h"

modref_t* modlist_random(int n, void*(*gen_elt)(void));

modref_t* modlist_ofarray(int hdc, void** hds);

modref_t* modlist_getend(modref_t* list);

void modlist_print(modref_t* modref, FILE* f,
                   void(*print_elt)(void* elt, FILE* f));

uintptr_t modlist_equals(modref_t* list1, modref_t* list2);

uintptr_t modlist_equals_pred(modref_t* list1, modref_t* list2,
                              uintptr_t(*eq_elt)(void* elt_1, void* elt_2));

void modlist_insert(modref_t* modref, void* element);

void* modlist_remove(modref_t* modref);




afun map(cons_cell_t* c, void*(*f)(void*), modref_t* dest);

afun filter(cons_cell_t* c, int(*f)(void*), modref_t* dest);

afun split(cons_cell_t* c,
           int(*f)(void* f_env, void*), void* f_env,
           modref_t* dest1, modref_t* dest2);

afun merge(cons_cell_t* c1, cons_cell_t* c2,
           int(*f)(void*, void*), modref_t* dest);

afun reverse_rec(cons_cell_t* c, cons_cell_t* reversed, modref_t* dest);

afun lenge(cons_cell_t* c, unsigned int n, modref_t* dest);

afun lenlt(cons_cell_t* c, unsigned int n, modref_t* dest);

afun cross(modref_t* list_1, modref_t* list_2, modref_t* dest);

#endif
