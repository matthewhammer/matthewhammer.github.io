/* Matthew Hammer <hammer@tti-c.org> */

#include <stdlib.h>
#include <assert.h>
#include "rctree3.h"
#include "modlist.h"

typedef struct rctree3_build_s {
  float frac2;
  uintptr_t nodec;
  modref_t* nodes_tail;
} rctree3_build_t;


static uintptr_t
pick_degree(uintptr_t n, float frac2) {
  if(n == 0) return 0;
  if(n == 1) return 1;
  else if(n == 2) return 2;
  else {
    if(rand() < (frac2 * RAND_MAX)) return 2;
    else return 3;
  }
}

static uintptr_t
max(uintptr_t a, uintptr_t b) {
  return a > b ? a : b;
}

/* A recursive process (shaped like an imperfect binary tree) */
void rctree3_build_rec(rctree3_build_t* build,
                       modref_t* parent,
                       modref_t* mirror,
                       uintptr_t n)
{
  /* Pick the degree of the node */
  uintptr_t degree = pick_degree(n, build->frac2);  

  /* Generate some random data, for the node and edge: */
  modref_t* node_data = rctree3_app->gen_node_data(degree);
  modref_t* edge_data = rctree3_app->gen_edge_data();
  
  /* Create a new node. */
  rctree3_node_t*  node = Rctree3_Node(build->nodec++, degree == 1, node_data);
  modref_t* node_modref = modref();
  write(node_modref, node);
  
  /* Insert a list cell for the node. */
  cons_cell_t* node_cell = Cons(node_modref);
  write(build->nodes_tail, node_cell);
  build->nodes_tail = node_cell->tl; 

  /* Create two directional edges. */
  modref_t*          slot_0 = modref();
  rctree3_edge_t* back_edge = Rctree3_Edge(parent, mirror, edge_data);
  rctree3_edge_t* forw_edge = Rctree3_Edge(node_modref, slot_0, edge_data);
  write(slot_0, back_edge);
  write(mirror, forw_edge);

  /* Recur. */
  if(degree == 0)
  {
    abort();
  }
  else if(degree == 1)
  {
    rctree3_slots_t* slots = Rctree3_Slots(1, slot_0, NULL, NULL);
    write(node->slots, slots);
  }
  else if(degree == 2)
  {
    modref_t* slot_1 = modref();
    rctree3_slots_t* slots = Rctree3_Slots(2, slot_0, slot_1, NULL);
    write(node->slots, slots);
        
    rctree3_build_rec(build, node_modref, slot_1, n - 1);
  }
  else if(degree == 3)
  {
    float x = ((float)rand() / (float)RAND_MAX);
    uintptr_t n1 = max((uintptr_t)((n - 2) * x), 1);
    uintptr_t n2 = (n - 1) - n1;
    modref_t* slot_1 = modref();
    modref_t* slot_2 = modref();
    rctree3_slots_t* slots = Rctree3_Slots(3, slot_0, slot_1, slot_2);
    write(node->slots, slots);
    
    rctree3_build_rec(build, node_modref, slot_1, n1);    
    rctree3_build_rec(build, node_modref, slot_2, n2);
  }
  else
  {
    abort();
  }
}

/* Make a root (leaf) node and then begin with recursive process. */
void rctree3_build_begin(rctree3_build_t* build, uintptr_t n)
{
  modref_t*    node_data = rctree3_app->gen_node_data(1);  
  rctree3_node_t*   node = Rctree3_Node(build->nodec++, 1, node_data);
  modref_t*       slot_0 = modref();
  rctree3_slots_t* slots = Rctree3_Slots(1, slot_0, NULL, NULL);
  modref_t*  node_modref = modref();
  cons_cell_t* node_cell = Cons(node_modref);

  /* Initialize the node. */
  write(node_modref, node);
  write(node->slots, slots);  

  /* Insert node in list. */
  write(build->nodes_tail, node_cell);
  build->nodes_tail = node_cell->tl;

  /* Recursively build the rest of the tree. */
  rctree3_build_rec(build, node_modref, slot_0, n + 1);

  /* Terminate the node list. */
  write(build->nodes_tail, NULL);
}

void rctree3_build(uintptr_t n, float frac2, modref_t* dest)
{
  rctree3_build_t build;

  build.frac2 = frac2;
  build.nodec = 0;
  build.nodes_tail = dest;

  rctree3_build_begin(&build, n);
}


uintptr_t rctree3_node_degree(modref_t* a) {
  rctree3_node_t*   node = modref_deref(a);
  rctree3_slots_t* slots = modref_deref(node->slots);
  return slots->degree;
}

modref_t* rctree3_node_adj_i(modref_t* a, uintptr_t i) {
  rctree3_node_t*   node = modref_deref(a);
  rctree3_slots_t* slots = modref_deref(node->slots);
  modref_t**       slotv = slots->slotv;
  rctree3_edge_t*   edge = modref_deref(slotv[i]);
  return edge->node;
}

static int
rctree3_edge_find(modref_t* a, modref_t* b, rctree3_edge_t** edge_out) {
  rctree3_node_t*   node = modref_deref(a);
  rctree3_slots_t* slots = modref_deref(node->slots);
  modref_t**       slotv = slots->slotv;
  rctree3_edge_t*   edge = NULL;

  for(int i = 0; i < slots->degree; i++) {
    edge = modref_deref(slotv[i]);
    if(edge->node == b) {
      if(edge_out) *edge_out = edge;
      return i;
    }
  }
  abort();
}

static modref_t*
rctree3_cut_edge(modref_t* a, modref_t* b)
{
  rctree3_node_t*   node = modref_deref(a);
  rctree3_slots_t* slots = modref_deref(node->slots);
  modref_t**       slotv = slots->slotv;
  rctree3_edge_t*   edge = NULL;
  int         edge_index = rctree3_edge_find(a, b, &edge);
  modref_t*    edge_data = edge->data;
  
  rctree3_node_t*  new_node  = NULL;
  rctree3_slots_t* new_slots = NULL;
  
  if(slots->degree < 1) {
    abort();
  }
  else if(slots->degree == 1) {
    if(edge_index == 0)
      new_slots = Rctree3_Slots(0, NULL, NULL, NULL);
    else
      abort();
    new_node = node;
  }
  else if(slots->degree == 2) {
    if(edge_index == 0)
      new_slots = Rctree3_Slots(1, slotv[1], NULL, NULL);
    else if(edge_index == 1)
      new_slots = Rctree3_Slots(1, slotv[0], NULL, NULL);
    else
      abort();
    new_node = Rctree3_Node(node->id, 1, node->data);
  }
  else if(slots->degree == 3) {
    if(edge_index == 0)
      new_slots = Rctree3_Slots(2, slotv[1], slotv[2], NULL);
    else if(edge_index == 1)
      new_slots = Rctree3_Slots(2, slotv[0], slotv[2], NULL);
    else if(edge_index == 2)
      new_slots = Rctree3_Slots(2, slotv[0], slotv[1], NULL);
    else
      abort();
    new_node = node;
  }
  else
    abort();

  write(new_node->slots, new_slots);
  write(a, new_node);

  slime_kill(slotv[edge_index]);
  slime_kill(edge);
  slime_kill(slots);
  if(new_node != node)
    slime_kill(node);

  return edge->data;
}

modref_t*
rctree3_cut(modref_t* node_a, modref_t* node_b) {
  modref_t* ab_data = rctree3_cut_edge(node_a, node_b);
  modref_t* ba_data = rctree3_cut_edge(node_b, node_a);

  assert(ab_data == ba_data);
  return ab_data;
}

static void
rctree3_link_edge(modref_t* a, modref_t* slot_ab,
                  modref_t* b, modref_t* slot_ba,
                  modref_t* data)
{
  rctree3_node_t*   node = modref_deref(a);
  rctree3_slots_t* slots = modref_deref(node->slots);
  modref_t**       slotv = slots->slotv;
  rctree3_edge_t*   edge = NULL;
  
  rctree3_node_t*  new_node  = NULL;
  rctree3_slots_t* new_slots = NULL;
  rctree3_edge_t*  new_edge  = NULL;

  if(slots->degree == 0) {
    new_node  = node;
    new_slots = Rctree3_Slots(1, slot_ab, NULL, NULL);
  }
  else if(slots->degree == 1) {
    new_node  = Rctree3_Node(node->id, 0, node->data);
    new_slots = Rctree3_Slots(2, slotv[0], slot_ab, NULL);
  }
  else if(slots->degree == 2) {
    new_node  = node;
    new_slots = Rctree3_Slots(3, slotv[0], slotv[1], slot_ab);
  }
  else {
    abort();
  }

  new_edge = Rctree3_Edge(b, slot_ba, data);
  
  write(slot_ab, new_edge);  
  write(new_node->slots, new_slots);
  write(a, new_node);

  slime_kill(slots);
  if(new_node != node)
    slime_kill(node);
}

                  
void rctree3_link(modref_t* node_a, modref_t* node_b, modref_t* data) {
  modref_t* slot_ab = modref();
  modref_t* slot_ba = modref();

  rctree3_link_edge(node_a, slot_ab, node_b, slot_ba, data);
  rctree3_link_edge(node_b, slot_ba, node_a, slot_ab, data);
}
