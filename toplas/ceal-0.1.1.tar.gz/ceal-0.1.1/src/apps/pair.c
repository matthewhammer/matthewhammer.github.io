#include "pair.h"

ifun pair_init(pair_t* pair, void* fst, void* snd) {
  pair->fst = fst;
  pair->snd = snd;  
}

pair_t* Pair(void* fst, void* snd) {
  return alloc(sizeof(pair_t), &pair_init, fst, snd);
}
