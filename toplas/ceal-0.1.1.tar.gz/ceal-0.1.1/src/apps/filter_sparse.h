#include "ceal.h"
 
afun filter_sparse(int(*f)(void* env, void* elt), void* f_env,
                   modref_t* list, modref_t* dest);
