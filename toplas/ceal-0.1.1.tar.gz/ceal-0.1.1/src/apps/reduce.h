/* Matthew Hammer <hammer@tt-c.org> */

#ifndef __REDUCE_H__
#define __REDUCE_H__

#include "ceal.h"
#include "conscell.h"

afun reduce(modref_t* list,
            void* (*op)(void* env, void* a, void* b),
            void* op_env,
            modref_t* dest);

#endif
