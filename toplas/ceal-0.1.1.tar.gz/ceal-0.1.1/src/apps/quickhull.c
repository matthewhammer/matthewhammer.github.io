#include "quickhull.h"
#include "pointerflags.h"
#include "coin.h"
#include "modlist.h"
#include "filter_sparse.h"
#include "reduce.h"

/* Given a list of points ([points]) that are above and between the
   end-points of a given line ([line]), recursively find those points
   which fall on the convex hull above the given line and write them
   to [hull].  The points of [rest] are also appended to the hull. */

static
afun quickhull_rec(geom2d_line_t* line, modref_t* hull,
                   modref_t* points, cons_cell_t* rest) {
  modref_t* len_lt_1 = modref();

  lenlt(read(points), 1, len_lt_1);
  if(read(len_lt_1)) {
    write(hull, rest);
  }
  else {
    modref_t* mid = modref();
    reduce(points, geom2d_maxdist, line, mid);

    geom2d_point_t* mid_pt = read(mid);
    cons_cell_t*  mid_cell = Cons(mid_pt);

    modref_t*     left_points = modref();
    modref_t*    right_points = modref();
    geom2d_line_t*  left_line = Line(line->p1, mid_pt);
    geom2d_line_t* right_line = Line(mid_pt, line->p2);
    
    filter_sparse(geom2d_isabove, left_line, points, left_points);
    filter_sparse(geom2d_isabove, right_line, points, right_points);
    
    quickhull_rec(left_line, hull, left_points, mid_cell);
    quickhull_rec(right_line, mid_cell->tl, right_points, rest);
  }
}

static geom2d_point_t*
toleft(void* _, geom2d_point_t* p1, geom2d_point_t* p2) {
  return geom2d_toleft(p1, p2);
}

static geom2d_point_t*
toright(void* _, geom2d_point_t* p1, geom2d_point_t* p2) {
  return geom2d_toright(p1, p2);
}

/* Each point from list [c] is either filtered into [dest1], [dest2]
   or dropped.  A point is filtered into [dest1] ([dest2]) if it is
   above [line1] ([line2]). If it is above neither line, it is
   dropped. */
static afun
quickhull_split(cons_cell_t* c,
                 geom2d_line_t* line1, modref_t* dest1,
                 geom2d_line_t* line2, modref_t* dest2)
{
  if(c == NULL) {
    write(dest1, NULL);
    write(dest2, NULL);
  }
  else {
    geom2d_point_t* p = c->hd;
    
    if(geom2d_isabove(line1, p)) {
      cons_cell_t* c1 = Cons(p);
      write(dest1, c1);
      quickhull_split(read(c->tl),
                       line1, c1->tl,
                       line2, dest2);
    }
    else if(geom2d_isabove(line2, p)) {
      cons_cell_t* c2 = Cons(p);
      write(dest2, c2);
      quickhull_split(read(c->tl),
                       line1, dest1,
                       line2, c2->tl);
    }
    else {
      quickhull_split(read(c->tl),
                       line1, dest1,
                       line2, dest2);
    }
  } 
}

/** Find the convex hull of the given \c points and write it to \c hull */
afun quickhull(modref_t* points, modref_t* hull) {
  modref_t* len_lt_2 = modref();

  lenlt(read(points), 2, len_lt_2);

  if(read(len_lt_2)) {
    write(hull, read(points));
  }
  else {
    modref_t* min = modref();
    reduce(points, toleft, NULL, min);
    
    modref_t* max = modref();
    reduce(points, toright, NULL, max);

    geom2d_point_t* min_pt = read(min);
    geom2d_point_t* max_pt = read(max);
    
    geom2d_line_t* upper_line = Line(min_pt, max_pt);
    geom2d_line_t* lower_line = Line(max_pt, min_pt);
    
    cons_cell_t* c1 = Cons(min_pt);
    cons_cell_t* c2 = Cons(max_pt);
    cons_cell_t* c3 = Cons(min_pt);

    modref_t* upper_points = modref();
    modref_t* lower_points = modref();

    scope();
    quickhull_split(read(points),
                    upper_line, upper_points,
                    lower_line, lower_points);
    
    quickhull_rec(upper_line, c1->tl, upper_points, c2);
    quickhull_rec(lower_line, c2->tl, lower_points, c3);

    write(hull, c1);
    write(c3->tl, NULL);
  }  
}
