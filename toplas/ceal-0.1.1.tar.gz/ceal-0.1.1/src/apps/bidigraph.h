/* Mattthew Hammer <hammer@tti-c.org> */

#ifndef __SLIME_BIDIGRAPH__
#define __SLIME_BIDIGRAPH__

#include "ceal.h"
#include "conscell.h"

#if SLIME_CONSCELL_PACK
typedef struct bidigraph_node_s {
  uintptr_t id;

  modref_t* flag[0];
  modref_t flag_modref;

  modref_t* edge1[0];
  modref_t edge1_modref;

  modref_t* edge2[0];
  modref_t edge2_modref;
} bidigraph_node_t;
#else
#error "not supported."
#endif

typedef struct bidigraph_s {
  bidigraph_node_t** nodes;
  uintptr_t          nodec;
} bidigraph_t;

/* Node constructor: Creates a fresh node with given id */
bidigraph_node_t*
Bidigraph_node(uintptr_t id);

/* Graph constructor: Generates a random binary directed graph with node ids 0...n-1 */
bidigraph_t*
bidigraph_generate(uintptr_t n);

/* print the binary directed graph as a dot file (see: manpage for dot(1)). */
void bidigraph_print(bidigraph_t* graph, FILE* f);

/* Create a topological sort of the given graph.  The topsort is
   represented by an int modlist, which is written to the given
   destination. */
afun bidigraph_topsort(bidigraph_node_t* root, modref_t* dest);

#endif
