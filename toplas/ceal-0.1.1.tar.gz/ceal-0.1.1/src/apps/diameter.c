/* Matthew Hammer <hammer@tti-c.org> */
#include "geom2d.h"
#include "quickhull.h"
#include "modlist.h"
#include "reduce.h"
#include "pair.h"
#include "box.h"

static box_t*
pair_dist(pair_t* pair) {
  geom2d_point_t* p1 = pair->fst;
  geom2d_point_t* p2 = pair->snd;
  float distance = geom2d_dist(p1, p2);  
  return Box_float(distance);
}

static box_t*
maxf(void* __dummy, box_t* f1, box_t* f2) {
  if(f1->u._float > f2->u._float)
    return f1;
  else
    return f2;  
}

static box_t*
minf(void* __dummy, box_t* f1, box_t* f2) {
  if(f1->u._float < f2->u._float)
    return f1;
  else
    return f2;  
}

afun diameter(modref_t* points, modref_t* dest)
{
  modref_t* hull = modref();
  modref_t* pairs = modref();
  modref_t* dists = modref();

  quickhull(points, hull);
  cross(hull, hull, pairs);
  map(read(pairs), pair_dist, dists);
  reduce(dists, maxf, NULL, dest);
}

afun distance(modref_t* points_1,
              modref_t* points_2,
              modref_t* dest)
{
  modref_t* hull_1 = modref();
  modref_t* hull_2 = modref();

  modref_t* pairs = modref();
  modref_t* dists = modref();

  quickhull(points_1, hull_1);
  quickhull(points_2, hull_2);
  cross(hull_1, hull_2, pairs);
  map(read(pairs), pair_dist, dists);
  reduce(dists, minf, NULL, dest);
}
