/* Matthew Hammer <hammer@tti-c.org> */

#include <assert.h>
#include "rctree3.h"
#include "modlist.h"

void rctree3_print(modref_t* nodes, FILE* f) {
  cons_cell_t* node_cell = NULL;
  fprintf(f, "digraph {\n");
  node_cell = modref_deref(nodes);
  while(node_cell) {
    rctree3_node_t* node = modref_deref(node_cell->hd);

    fprintf(f, "node_%d [label=\"", node->id);

    if(node->final)
      rctree3_app->print_final_data(node->data, f);
    else
      rctree3_app->print_node_data(node->data, f);
    
    fprintf(f, "\"];\n");
    
    /* Spit-out "out-going" edges for node */
    {
      rctree3_slots_t* slots = modref_deref(node->slots);

      if(slots) {        
        for(int i = 0; i < slots->degree; i++) {
          rctree3_edge_t* edge = modref_deref(slots->slotv[i]);
          rctree3_node_t* edge_node = modref_deref(edge->node);

          fprintf(f, "node_%d -> node_%d [label=\"",
                  node->id, edge_node->id);
          
          rctree3_app->print_edge_data(edge->data, f);
          
          fprintf(f, "\"];\n");
        }
      }
      else {
        assert(node->final);
      }
      
      node_cell = modref_deref(node_cell->tl);
    }
  }
  fprintf(f, "}\n");
}
