#include <assert.h>
#include "pointerflags.h"
#include "coin.h"
#include "modlist.h"
#include "filter_sparse.h"

static afun
filter_sparse_onepass(int(*f)(void* env, void* elt),
                      void* f_env,
                      coin_t* coin,
                      cons_cell_t* cell,
                      modref_t* dest,
                      uintptr_t stop_cond,
                      modref_t* stop_cond_dest)
{
  if(cell == NULL) {
    write(dest, NULL);
    write(stop_cond_dest, stop_cond);
  }
  else {
    void* elt_and_mark = cell->hd;
    void* elt = pointer_part(elt_and_mark);
    uintptr_t mark = flags_part(elt_and_mark);
    cons_cell_t* cell_out;

    /* Determine [cell_out] and [stop_cond]: */
    if(mark) {
      stop_cond = 0;

      if(coin_flip(coin, elt)) {
        if(f(f_env, elt)) {
          cell_out = Cons(elt);
        }
        else {
          cell_out = NULL;
        }
      }
      else {
        cell_out = Cons(elt_and_mark);
      }
    }
    else {
      cell_out = Cons(elt);
    }

    /* Append cell_out */
    if(cell_out) {
      write(dest, cell_out);
      dest = cell_out->tl;
    }

    /* Recurse. */
    filter_sparse_onepass(f, f_env, coin, read(cell->tl), dest,
                          stop_cond, stop_cond_dest);
  }
}

static afun
filter_sparse_rec(int(*f)(void* env, void* elt), void* f_env,
                  modref_t* list, modref_t* dest)
{
  coin_t* coin = Coin_biased_16();
  modref_t* next_list = modref();
  modref_t* stop_cond = modref();

  scope();  
  filter_sparse_onepass(f, f_env, coin, read(list), next_list,
                        1, stop_cond);

  if(read(stop_cond)) {
    write(dest, read(list));
  }
  else {    
    filter_sparse_rec(f, f_env, next_list, dest);
  }
}

static void*
add_mark_to_pointer(void* ptr) {
  return pointer_and_flags(ptr, 1);
}

static void*
assert_no_mark(void* ptr) {
  assert(flags_part(ptr) == 0);
  return ptr;
}

afun filter_sparse(int(*f)(void* env, void* elt), void* f_env,
                   modref_t* list, modref_t* dest)
{  
  /* Mark each element of the list. */
  modref_t* marked_list = modref();
  scope();
  map(read(list), add_mark_to_pointer, marked_list);

  modref_t* filtered_list = modref();
  filter_sparse_rec(f, f_env, marked_list, filtered_list);
  
  scope();
  map(read(filtered_list), assert_no_mark, dest);  
}
