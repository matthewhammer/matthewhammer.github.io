/* Matthew Hammer <hammer@tti-c.org> */

#include "rctree3.h"
#include <stdio.h>

static modref_t*
gen_node_data(int degree) {
  return NULL;
}

static modref_t*
gen_edge_data() {
  modref_t* edge_data = modref();
  return edge_data;
}

static afun
finalize(rctree3_node_t* node,
         rctree3_slots_t* slots,
         modref_t* node_data,
         modref_t* scar_data_0,
         modref_t* scar_data_1,
         modref_t* scar_data_2,
         modref_t* node_data_dest) {
  
}

static afun
rake (rctree3_node_t* node,
      rctree3_slots_t* slots,
      modref_t* node_data,
      modref_t* edge_data,
      modref_t* scar_data_0,
      modref_t* scar_data_1,
      modref_t* scar_data_dest) {

}

static afun
compress(rctree3_node_t* node,
         rctree3_slots_t* slots,
         modref_t* node_data,
         modref_t* edge_data_0,
         modref_t* edge_data_1,
         modref_t* scar_data,
         modref_t* edge_data_dest) {

}

static void
print_node_data(modref_t* node_data, FILE* file) {

}

static void
print_final_data(modref_t* final_data, FILE* file) {

}

static void
print_edge_data(modref_t* edge_data, FILE* file) {
  
}

rctree3_app_t rctree3_app_nop =
  { "nop",
    gen_node_data, gen_edge_data,
    finalize, rake, compress,
    verif(finalize), verif(rake), verif(compress),
    print_node_data,
    print_final_data,
    print_edge_data
  };
