


/*
afun mergehull(modref_t* points, modref_t* hull) {
  modref_t* len_lt_2 = modref();
  lenlt(points, 2, len_lt_2);
  if(len_lt_2) {
    write(read(points, hull));
  }
  else {
    modref_t* points_1 = modref();
    modref_t* points_2 = modref();
    coin_t* coin = Coin(2);
    
    mergehull_split(points, coin, points_1, points_2);

  }
  

}
*/
