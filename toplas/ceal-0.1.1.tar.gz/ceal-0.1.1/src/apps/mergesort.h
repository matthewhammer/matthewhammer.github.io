/* (Mini) Modlist header file */
/* Matthew Hammer <hammer@tt-c.org> */

#ifndef __MERGESORT_H__
#define __MERGESORT_H__

#include "modlist.h"

/**
 * \defgroup apps_mergesort Mergesort
 * \ingroup apps
 * @{
 */ 

afun merge_sort(int (*isle)(void*, void*),
                modref_t* unsorted,
                modref_t* dest);

/* @} */

#endif
