#include "box.h"

ifun box_pointer_init(box_t* box, void* p) {
  box->u._pointer = p;  
}

box_t* Box_pointer(void* p) {
  return alloc(sizeof(box_t), box_pointer_init, p);
}

ifun box_float_init(box_t* box, float f) {
  box->u._float = f;
}

box_t* Box_float(float f) {
  return alloc(sizeof(box_t), box_float_init, f);
}

ifun box_uint_init(box_t* box, uintptr_t uint) {
  box->u._uint = uint;  
}

box_t* Box_uint(uintptr_t uint) {
  return alloc(sizeof(box_t), box_uint_init, uint);
}
