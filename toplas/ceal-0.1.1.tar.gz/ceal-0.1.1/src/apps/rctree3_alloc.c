 /* Matthew Hammer <hammer@tti-c.org> */

#include "rctree3.h"
#include "modlist.h"

static uintptr_t
throw_dice(uintptr_t prev_dice,
           uintptr_t id) {
  uintptr_t a, b, c;
  a = b = (uintptr_t) id;
  c = prev_dice;
  mix(a,b,c);
  
#if 0
  return c % 512;
#else
  return c;
#endif
}

ifun rctree3_node_init(rctree3_node_t* node,
                       uintptr_t id,
                       uintptr_t sing,
                       modref_t* data) {
  node->id       = id;
  node->dice     = throw_dice(0xdeadbeef, id);
  node->sing     = sing;
  node->final    = 0;
  node->data     = data;

  /* TODO: pack these: */
  node->desc     = modref();
  node->slots    = modref();
 }

rctree3_node_t*
Rctree3_Node(uintptr_t id, uintptr_t sing, modref_t* data) {
  return alloc(sizeof(rctree3_node_t), rctree3_node_init,
               id, sing, data);
}

ifun rctree3_node_desc_init(rctree3_node_t* node,
                            rctree3_node_t* ansc,
                            uintptr_t sing,
                            uintptr_t final) {
  node->id       = ansc->id;
  node->sing     = sing;
  node->final    = final;
  node->dice     = throw_dice(ansc->dice, ansc->id);
  node->data     = ansc->data;

  /* TODO: pack these: */
  node->desc     = modref();
  node->slots    = modref();
}

/* Create a descendent node from an ancestor node. */
rctree3_node_t*
Rctree3_Node_Desc(rctree3_node_t* ansc,
                  uintptr_t sing,
                  uintptr_t final,
                  rctree3_slots_t* slots)
{
  rctree3_node_t* desc = alloc(sizeof(rctree3_node_t),
                               rctree3_node_desc_init,
                               ansc, sing, final);
  
  write(ansc->desc, desc);
  write(desc->slots, slots);
  return desc;
}


ifun rctree3_final_init(rctree3_node_t* node,
                        rctree3_node_t* ansc) {
  node->id       = ansc->id;
  node->sing     = 0;
  node->final    = 1;
  node->dice     = throw_dice(ansc->dice, ansc->id);
  node->data     = modref();

  /* TODO: pack these: */
  node->desc     = modref();
  node->slots    = modref();
}

/* Create a final (descendent) node from an ancestor node. */
rctree3_node_t*
Rctree3_Final(rctree3_node_t* ansc)
{
  rctree3_node_t* desc = alloc(sizeof(rctree3_node_t),
                               rctree3_final_init,
                               ansc);
  write(ansc->desc, desc);
  write(desc->slots, NULL);
  return desc;
}

ifun rctree3_edge_init(rctree3_edge_t* edge,
                       modref_t* node,
                       modref_t* mirror,
                       modref_t* data) {
  edge->node   = node; 
  edge->mirror = mirror;
  edge->data   = data;
  
  edge->desc   = modref(); /* TODO: pack this. */
}

rctree3_edge_t*
Rctree3_Edge(modref_t* node,
             modref_t* mirror,
             modref_t* data)
{
  return alloc(sizeof(rctree3_edge_t),
               rctree3_edge_init, node, mirror, data);
}

ifun rctree3_edge_compressed_init(rctree3_edge_t* edge,
                                  modref_t* node,
                                  modref_t* mirror) {
  edge->node   = node;
  edge->mirror = mirror;

  edge->data   = modref();
  edge->desc   = modref(); /* TODO: pack this */
}

rctree3_edge_t*
Rctree3_Edge_Compressed(modref_t* node, modref_t* mirror) {
  return alloc(sizeof(rctree3_edge_t), rctree3_edge_compressed_init, node, mirror);
}

ifun rctree3_slots_init(rctree3_slots_t* slots,
                        uintptr_t degree,
                        modref_t* slot_0,
                        modref_t* slot_1,
                        modref_t* slot_2) {
  slots->degree = degree;
  slots->slotv[0] = slot_0;
  slots->slotv[1] = slot_1;
  slots->slotv[2] = slot_2;
}

rctree3_slots_t*
Rctree3_Slots(uintptr_t degree,
              modref_t* slot_0,
              modref_t* slot_1,
              modref_t* slot_2) {
  return alloc(sizeof(rctree3_slots_t),
               rctree3_slots_init, degree,
               slot_0, slot_1, slot_2);
}
