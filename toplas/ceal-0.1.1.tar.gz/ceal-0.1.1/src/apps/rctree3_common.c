#include <stdlib.h>
#include "rctree3.h"

rctree3_app_t* rctree3_app = NULL;

afun rctree3_final_node(rctree3_node_t* node,
                        rctree3_slots_t* slots)
{
  rctree3_node_t* desc = Rctree3_Final(node);

  if(!__ISVERIF__) {
    rctree3_app->finalize(node, slots,
                          (node->data),
                          (slots->slotv[0]),
                          (slots->slotv[1]),
                          (slots->slotv[2]),
                          desc->data);
  } else {
    rctree3_app->finalize_verif(node, slots,
                                (node->data),
                                (slots->slotv[0]),
                                (slots->slotv[1]),
                                (slots->slotv[2]),
                                desc->data);
  }
}

                          
afun rctree3_rake_node(rctree3_node_t* node,
                       rctree3_slots_t* slots,
                       rctree3_edge_t* edge_NA,
                       rctree3_edge_t* edge_AN)
{
  write(node->desc, NULL);

  if(!__ISVERIF__) {
    rctree3_app->rake(node, slots,
                      (node->data),
                      (edge_NA->data),
                      (slots->slotv[1]),
                      (slots->slotv[2]),
                      edge_AN->desc);
  }
  else {
    rctree3_app->rake_verif(node, slots,
                            (node->data),
                            (edge_NA->data),
                            (slots->slotv[1]),
                            (slots->slotv[2]),
                            edge_AN->desc);
  }
}

afun rctree3_compress_node(rctree3_node_t* node, rctree3_slots_t* slots,
                           rctree3_edge_t* edge_NA, rctree3_node_t* node_A, rctree3_edge_t* edge_AN,
                           rctree3_edge_t* edge_NB, rctree3_node_t* node_B, rctree3_edge_t* edge_BN)
{    
  rctree3_edge_t* edge_AB = Rctree3_Edge_Compressed(node_B->desc, edge_BN->desc);
  rctree3_edge_t* edge_BA = Rctree3_Edge_Compressed(node_A->desc, edge_AN->desc);

  write(edge_AN->desc, edge_AB);
  write(edge_BN->desc, edge_BA);

  write(node->desc, NULL);

  if(!__ISVERIF__) {
    rctree3_app->compress(node, slots,  
                          (node->data),
                          (edge_AN->data),
                          (edge_NB->data),
                          (slots->slotv[2]),
                          edge_AB->data);
  }
  else {
    rctree3_app->compress_verif(node, slots,  
                                (node->data),
                                (edge_AN->data),
                                (edge_NB->data),
                                (slots->slotv[2]),
                                edge_AB->data);
  }

  write(edge_BA->data, read(edge_AB->data));
}

/* rctree3_edge_desc:
 *
 * Given two nodes, A and B, and the edges between them, create an
 * edge B'->A' between the descendents B' and A'.  Returns the slot
 * that will hold the edge A'->B', but doesn't create this.
 *
 * Invariant: All edges of the form V'->U' (where U' and V' are
 * descendents of U and V) the will be created when contracting node U
 * (as opposed to V).
*/
modref_t*
rctree3_edge_desc(rctree3_node_t* a, rctree3_edge_t* ab,
                  rctree3_node_t* b, rctree3_edge_t* ba) {
  if(!b->sing) {
    rctree3_edge_t* ba_desc =
      Rctree3_Edge(a->desc, ab->desc, ba->data);
    
    write(ba->desc, ba_desc);
  }
  return ab->desc;
}

/* This is used for debugging the tree only.  The idea is to have this
   call "wakeup" at each round during change propagation and print out
   (to disk) the tree as it exists at that round. */
afun rctree3_print_hook(uintptr_t dummy, uintptr_t roundc, modref_t* nodes) {
  char* filename = malloc(255);
  FILE* f = NULL;

#if 1
  sprintf(filename, "rctree3.round%02d.dot", roundc);
#else
  sprintf(filename, "rctree3.num%02d.round%02d.dot", dummy, roundc);
#endif
  
  f = fopen(filename, "w+");
  rctree3_print(nodes, f);
  fclose(f);  
}


/* Deprecated. */
/* Note: This version isn't stable in practice.  We don't use it. */
afun rctree3_filter_unstable(cons_cell_t* cell,
                             modref_t* next_nodes,
                             uintptr_t stop_cond,
                             modref_t* stop_cond_dest)
{
  if(!cell) {
    write(next_nodes, NULL);
    write(stop_cond_dest, stop_cond);
  }
  else {
    rctree3_node_t* node = read(cell->hd);
    rctree3_node_t* desc = read(node->desc);

    if(!desc) {
      /* No descendent ==>
         The node has been raked or compressed. */
      rctree3_filter_unstable(read(cell->tl), next_nodes,
                              stop_cond, stop_cond_dest);
    }
    else {
      /* Has descendent ==>
         Append the node to next_nodes for the next round. */
      cons_cell_t* cell_out = Cons(node->desc);
      write(next_nodes, cell_out);
      next_nodes = cell_out->tl;

      rctree3_filter_unstable(read(cell->tl), next_nodes,
                              stop_cond && desc->final,
                              stop_cond_dest);
    }
  }
}

/* Deprecated. -- we've combined the filtering step and the
   contraction-round step into a single step. */
afun rctree3_filter(cons_cell_t* cell,
                    modref_t* next_nodes)
{
  if(!cell) {
    write(next_nodes, NULL);
  }
  else {
    rctree3_node_t* node = read(cell->hd);
    rctree3_node_t* desc = read(node->desc);

    if(!desc || desc->final) {
      /* No descendent ==>
         The node has been raked or compressed. */
      rctree3_filter(read(cell->tl), next_nodes);
    }
    else {
      /* Has descendent ==>
         Append the node to next_nodes for the next round. */
      cons_cell_t* cell_out = Cons(node->desc);
      write(next_nodes, cell_out);
      next_nodes = cell_out->tl;

      rctree3_filter(read(cell->tl), next_nodes);
    }
  }
}
