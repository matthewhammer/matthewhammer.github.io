#include "ceal.h"
#include "modlist.h"

void modstack_init(modref_t* stack);
afun modstack_push(modref_t* stack, void* x);
