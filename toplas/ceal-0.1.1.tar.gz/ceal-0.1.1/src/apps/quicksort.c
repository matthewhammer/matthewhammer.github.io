#include "quicksort.h"

typedef struct quicksort_split_dests_s {
  modref_t* le;
  modref_t* gt;
} quicksort_split_dests_t;

ifun static quicksort_split_dests_init (quicksort_split_dests_t* dests) {
  dests->le = modref();
  dests->gt = modref();
}

static quicksort_split_dests_t* Split_Dests(void* pivot) {
  return alloc(sizeof(quicksort_split_dests_t),
               quicksort_split_dests_init, pivot);
}

afun quicksort_pivot(int (*isgt)(void*, void*),
                     void* pivot,
                     cons_cell_t* list_cell,
                     modref_t* list,
                     modref_t* dest1, modref_t* dest2) {
  scope(pivot);
  split(read(list), isgt, pivot, dest1, dest2);
}

static int foo() {
  static int x = 0;
  return x++;
}

/** Recursively sort unsorted, result is appended with rest */
afun quicksort_rec(int (*isgt)(void*, void*),
                   modref_t* dest,
                   cons_cell_t* unsorted,
                   cons_cell_t* rest) {
  if(unsorted == NULL) {
    write(dest, rest);
  }
  else {
    void*                    pivot = unsorted->hd;
    cons_cell_t*        pivot_cell = Cons(pivot);
    quicksort_split_dests_t* dests = Split_Dests(pivot);

    quicksort_pivot(isgt, pivot, read(unsorted->tl), unsorted->tl, dests->le, dests->gt);
    quicksort_rec(isgt, dest, read(dests->le), pivot_cell);
    quicksort_rec(isgt, pivot_cell->tl, read(dests->gt), rest);

    foo(); /* TEMP */
  }
}

afun quicksort(modref_t* unsorted,
               int (*isgt)(void*, void*),
               modref_t* sorted) {
  quicksort_rec(isgt, sorted, read(unsorted), NULL);
}

