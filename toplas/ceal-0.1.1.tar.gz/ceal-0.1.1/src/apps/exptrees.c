#include <stdlib.h>
#include "ceal.h"
#include "exptrees.h"
#include "box.h"


// leaf initializer
ifun exptrees_leaf_init (leaf_t* p, float num) {
  p->kind = LEAF;
  p->num = num;
}

// leaf allocator
leaf_t* exptrees_leaf (float num) {
  return alloc (sizeof (leaf_t), &exptrees_leaf_init, num);
}

// node initializer
ifun exptrees_node_init (node_t *p, op_t op) {
  p->kind = NODE;
  p->op = op;
  
  p->left = modref ();
  p->right = modref ();
}

// node allocator
node_t* exptrees_node (op_t op) {
  return (alloc (sizeof (node_t), &exptrees_node_init, op));
}

// build a random tree with num_nodes nodes, 
// the tree can have some extra nodes (probably just one).
int exptrees_random_rec(int num_nodes, modref_t* dest) {  
  if(num_nodes > 2) {

    node_t* node = exptrees_node (rand() % 4);

    int n = num_nodes - 1;
    
    int n_l = exptrees_random_rec (n / 2, node->left);
    int n_r = exptrees_random_rec (n - n_l, node->right);

    write (dest,node);
    return (n_l + n_r + 1);
  }
  else if (num_nodes == 1) {
    leaf_t* leaf = exptrees_leaf (rand () % 100);
    write (dest, leaf);
    return 1;
  }
  else if (num_nodes == 2) {
    return (exptrees_random_rec (3, dest));
  }
  abort();
  return 0;
}

modref_t* exptrees_random(int num_nodes) {
  modref_t* root = modref();
  exptrees_random_rec (num_nodes, root);
  return root;
}

afun exptrees_eval_2 (node_t* t, box_t* a, box_t* b, modref_t* result) {
  float r_l = a->u._float;
  float r_r = b->u._float;

  if (t->op == PLUS) {
    write (result, Box_float(r_l + r_r)); 
  }
  else if (t->op == MINUS) {
    write (result, Box_float(r_l - r_r)); 
  }
  else if (t->op == TIMES) {
    write (result, Box_float(r_l * r_r)); 
  }
  else {
    write (result, Box_float(r_l + r_r));
  }
}  

afun exptrees_eval (modref_t* tree, modref_t* result) {
  
  node_t* t = read (tree);
   
  if (t->kind == LEAF) {
    leaf_t* l = (leaf_t*) t;
    write (result, Box_float(l->num));
  }
  else {
    modref_t* r_left = modref ();
    modref_t* r_right = modref ();
    
    exptrees_eval(t->left, r_left);
    exptrees_eval(t->right, r_right);
    exptrees_eval_2(t, read(r_left), read(r_right), result);
  }
}
