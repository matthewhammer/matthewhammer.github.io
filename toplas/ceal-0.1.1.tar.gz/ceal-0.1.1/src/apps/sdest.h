/* Matthew Hammer <hammer@tti-c.org> */

/* S-Destinations -- Can sometimes be a more stable alternative to
   write-once modrefs as destinations.  The main use is within
   recursive functions where a given incoming destination isn't
   written on every iteration.
   
   An S-dest acts as a proxy for the destination (modref) it currently
   holds and it's assumed that each destination will be replaced once
   its written--but this isn't necessary.  Once a s-dest is created
   for a given destination (modref) it can be written in one of two
   ways.  The operation [next] writes this destination and replaces it
   with a new given destination.  The operation [done] is similar to
   [next] except that it doesn't replace the current destination.
*/

#ifndef __SDEST_H__
#define __SDEST_H__

#include "ceal.h"

typedef struct sdest_s {
  modref_t* sdest[0];
  modref_t  sdest_modref;
} sdest_t;

sdest_t* Sdest(modref_t* dest);
sdest_t* sdest_next(sdest_t* sdest, void* value, modref_t* dest);
void     sdest_done(sdest_t* sdest, void* value);

#endif
