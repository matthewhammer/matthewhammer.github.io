/* Matthew Hammer <hammer@tti-c.org> */

#include <stdlib.h>
#include "rctree3.h"
#include "modlist.h"

static wfun
rake_step_1(rctree3_node_t* node,
            rctree3_slots_t* slots,
            rctree3_edge_t* edge);

static wfun
rake_step_2(rctree3_node_t*  node,
            rctree3_slots_t* slots,
            rctree3_edge_t*  edge,
            rctree3_node_t*  targ,
            rctree3_edge_t*  edge_mirror);

static wfun
compress_step_1(rctree3_node_t* node,
                rctree3_slots_t* slots,
                rctree3_edge_t* edge_0,
                rctree3_edge_t* edge_1);

static wfun
compress_step_2(rctree3_node_t* node,
                rctree3_slots_t* slots,
                rctree3_edge_t* edge_0,
                rctree3_edge_t* edge_1,
                rctree3_edge_t* edge_0_mirror,
                rctree3_edge_t* edge_1_mirror,
                rctree3_node_t* targ_0,
                rctree3_node_t* targ_1);

static wfun
copy_step_1(rctree3_node_t* node,
            rctree3_edge_t* edge_0,
            rctree3_edge_t* edge_1,
            rctree3_edge_t* edge_2);

static wfun
copy_step_2(rctree3_node_t* node,
            rctree3_edge_t* edge_0,
            rctree3_edge_t* edge_1,
            rctree3_edge_t* edge_2,
            rctree3_edge_t* edge_0_mirror,
            rctree3_edge_t* edge_1_mirror,
            rctree3_edge_t* edge_2_mirror,
            rctree3_node_t* targ_0,
            rctree3_node_t* targ_1,
            rctree3_node_t* targ_2);

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

static wfun
rake_step_1(rctree3_node_t* node,
            rctree3_slots_t* slots,
            rctree3_edge_t* edge) {

  rake_step_2(node, slots, edge,
              read(edge->node),
              read(edge->mirror));
}

static wfun
rake_step_2(rctree3_node_t*  node,
            rctree3_slots_t* slots,
            rctree3_edge_t*  edge,
            rctree3_node_t*  targ,
            rctree3_edge_t*  edge_mirror)
{
  modref_t** slotv = slots->slotv;
  
  if(!targ->sing || (targ->dice < node->dice)) {
    /* Perform Rake. */
    rctree3_rake_node(node, slots, edge, edge_mirror);
  }
  else {
    /* Don't Rake.  Instead, create a copy. */ 
    rctree3_slots_t* desc_slots =
      Rctree3_Slots(0, edge->desc, slotv[1], slotv[2]);
    
    Rctree3_Node_Desc(node, 0, 0, desc_slots);
  }      
}



static wfun
compress_step_1(rctree3_node_t* node,
                rctree3_slots_t* slots,
                rctree3_edge_t* edge_0,
                rctree3_edge_t* edge_1)
{
  compress_step_2(node, slots, edge_0, edge_1,
                  read(edge_0->mirror),
                  read(edge_1->mirror),
                  read(edge_0->node),
                  read(edge_1->node));                  
}

static wfun
compress_step_2(rctree3_node_t* node,
                rctree3_slots_t* slots,
                rctree3_edge_t* edge_0,
                rctree3_edge_t* edge_1,
                rctree3_edge_t* edge_0_mirror,
                rctree3_edge_t* edge_1_mirror,
                rctree3_node_t* targ_0,
                rctree3_node_t* targ_1)
{
  modref_t** slotv = slots->slotv;
  uintptr_t pred =
    (node->dice > targ_0->dice) &&
    (node->dice > targ_1->dice) &&
    (!targ_0->sing) &&
    (!targ_1->sing);
  
  if(pred)
  {
    rctree3_compress_node(node, slots,
                          edge_0, targ_0, edge_0_mirror, 
                          edge_1, targ_1, edge_1_mirror);
  }
  else { /* Create a copy. */ 
    uintptr_t desc_degree = (!targ_0->sing + !targ_1->sing);
    modref_t* desc_slot_0 = rctree3_edge_desc(node, edge_0, targ_0, edge_0_mirror);
    modref_t* desc_slot_1 = rctree3_edge_desc(node, edge_1, targ_1, edge_1_mirror);
    
    /* Re-order slots so that future non-edge slots (scars) are always last. */
    rctree3_slots_t* desc_slots =
      ((!targ_0->sing)
       ? Rctree3_Slots(desc_degree, desc_slot_0, desc_slot_1, slotv[2])
       : Rctree3_Slots(desc_degree, desc_slot_1, desc_slot_0, slotv[2]));
    
    Rctree3_Node_Desc(node, desc_degree <= 1, 0, desc_slots);
  }
}


static wfun
copy_step_1(rctree3_node_t* node,
            rctree3_edge_t* edge_0,
            rctree3_edge_t* edge_1,
            rctree3_edge_t* edge_2) {
  copy_step_2(node, edge_0, edge_1, edge_2,
              read(edge_0->mirror), read(edge_1->mirror), read(edge_2->mirror),
              read(edge_0->node), read(edge_1->node), read(edge_2->node));
}

static wfun
copy_step_2(rctree3_node_t* node,
            rctree3_edge_t* edge_0,
            rctree3_edge_t* edge_1,
            rctree3_edge_t* edge_2,
            rctree3_edge_t* edge_0_mirror,
            rctree3_edge_t* edge_1_mirror,
            rctree3_edge_t* edge_2_mirror,
            rctree3_node_t* targ_0,
            rctree3_node_t* targ_1,
            rctree3_node_t* targ_2) {

  uintptr_t desc_degree = (!targ_0->sing + !targ_1->sing + !targ_2->sing);
    
  modref_t* desc_slot_0 = rctree3_edge_desc(node, edge_0, targ_0, edge_0_mirror);
  modref_t* desc_slot_1 = rctree3_edge_desc(node, edge_1, targ_1, edge_1_mirror);
  modref_t* desc_slot_2 = rctree3_edge_desc(node, edge_2, targ_2, edge_2_mirror);
  
  /* Re-order slots so that future non-edge slots (scars) are always last. */
  rctree3_slots_t* desc_slots =
    ((!targ_0->sing)
     ? ( (!targ_1->sing)
         ? Rctree3_Slots(desc_degree, desc_slot_0, desc_slot_1, desc_slot_2)
         : Rctree3_Slots(desc_degree, desc_slot_0, desc_slot_2, desc_slot_1) )
     : ( (!targ_1->sing)
         ? Rctree3_Slots(desc_degree, desc_slot_1, desc_slot_2, desc_slot_0)
         : Rctree3_Slots(desc_degree, desc_slot_2, desc_slot_0, desc_slot_1) )
     );
  
  Rctree3_Node_Desc(node, desc_degree <= 1, 0, desc_slots);
}



afun rctree3_contract_node_opt(rctree3_node_t* node, rctree3_slots_t* slots)
{
  if(node->final)  {    
    /* Case: Final Node (from last round). */
    Rctree3_Final(node);
  }
  else{
    /* Case: Not (yet) a Final node */
    
    modref_t** slotv = slots->slotv;
    uintptr_t degree = slots->degree;
  
    if(degree == 0) /* Case: Final Node (in *next* round) */ {
      rctree3_final_node(node, slots);
    }
    else if(degree == 1) /* Case: Try to Rake. */ {
      /* Read Opt: 3 reads --> 2 reads */
      rake_step_1(node, slots, read(slotv[0]));
    }
    else if(degree == 2) /* Case: Try to Compress. */ {
      /* Read Opt: 6 reads --> 2 reads */
      compress_step_1(node, slots, read(slotv[0]), read(slotv[1]));
    }
    else if(degree == 3) /* Case: Copy/Descend. */ {
      /* Read Opt: 9 reads --> 2 reads */      
      copy_step_1(node, read(slotv[0]), read(slotv[1]), read(slotv[2]));
    }
    else {
      abort();
    }
  }
}


afun rctree3_contract_round_opt(cons_cell_t* cell,
                                modref_t* dest) {
  if(!cell) {
    write(dest, NULL);
  }
  else {
    rctree3_node_t* node = read(cell->hd);
    
    if(node) {
      rctree3_contract_node_opt(node, read(node->slots));
      rctree3_node_t* desc = read(node->desc);

      /* Has non-final descendent? */
      if(desc && (!desc->final)) {
        cons_cell_t* cell_out = Cons(node->desc);
        write(dest, cell_out);
        dest = cell_out->tl;        
      }
    }
    
    rctree3_contract_round_opt(read(cell->tl), dest);
  }
}


afun rctree3_contract_rec_opt(uintptr_t roundc,
                              modref_t* nodes,
                              modref_t* dest,
                              modref_t* dummy) {

  if(SLIME_RCTREE3_DEBUG) {
    rctree3_print_hook(read(dummy), roundc, nodes);
  }

  modref_t* stop_cond = modref();
  modref_t* next_nodes  = modref();
  
  rctree3_contract_round_opt(read(nodes), next_nodes);

  lenlt(read(next_nodes), 1, stop_cond);
  
  if(read(stop_cond)) {
    write(dest, read(next_nodes));
  }
  else {    
    rctree3_contract_rec_opt(roundc+1, next_nodes, dest, dummy);
  }
}


afun rctree3_contract_opt(modref_t* nodes, modref_t* dest, modref_t* dummy) {
  scope();
  rctree3_contract_rec_opt(0, nodes, dest, dummy);
}


/* BUGS (comments relocated here after being fixed): */

/* BUG: -- This illustrates a bug in my (old) normalization
   algorithm: The call returns a closure to tail-call, but we
   never invoke it. -- this occurs so long as we perform no
   reads at the call-site, but rather within the callee body
   itself. */

/* BUG: Using this pred within the conditional causes a nested
   conditional to appear in translated code.  When the nested
   conditional fails at some levels, it returns rather than
   going-to the else-branch. */
