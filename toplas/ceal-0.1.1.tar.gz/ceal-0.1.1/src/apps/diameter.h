/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __DIAMETER_H__
#define __DIAMETER_H__

#include "modlist.h"
#include "geom2d.h"

/**
 * \defgroup apps_diameter Diameter
 * \ingroup apps
 * @{
 */ 

afun diameter(modref_t* points,
              modref_t* dest);

/* @} */

/**
 * \defgroup apps_distance Distance
 * \ingroup apps
 * @{
 */ 

afun distance(modref_t* points_1,
              modref_t* points_2,
              modref_t* dest);

/* @} */

#endif
