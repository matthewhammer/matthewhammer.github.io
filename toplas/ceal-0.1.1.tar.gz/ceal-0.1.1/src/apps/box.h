/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __BOX_H__
#define __BOX_H__

#include "ceal.h"
#include "inttypes.h"

typedef struct box_s {
  union {
    void*     _pointer;
    uintptr_t _uint;
    float     _float;
  } u;
} box_t;

box_t* Box_pointer(void* p);
box_t* Box_float(float f);
box_t* Box_uint(uintptr_t uint);

#endif
