/* Matthew Hammer <hammer@tti-c.org> */

#include <stdlib.h>
#include "rctree3.h"
#include "modlist.h"
#include "modstack.h"

afun rctree3_contract_node(rctree3_node_t* node, rctree3_slots_t* slots)
{
  if(node->final)  {
    /* Case: Final Node (from last round). */    
    Rctree3_Final(node);
  }
  else{
    /* Case: Not a Final node */
    
    modref_t** slotv = slots->slotv;
    uintptr_t degree = slots->degree;
  
    if(degree == 0) /* Case: Final Node (in *next* round) */ {
      rctree3_final_node(node, slots);
    }
    else if(degree == 1) /* Case: Try to Rake. */ {
      rctree3_edge_t* edge = read(slotv[0]);
      rctree3_node_t* targ = read(edge->node);
    
      if(!targ->sing || (targ->dice < node->dice)) {
        rctree3_edge_t* edge_mirror = read(edge->mirror);
        rctree3_rake_node(node, slots, edge, edge_mirror);
      }
      else { /* Create a copy. */ 
        rctree3_slots_t* desc_slots =
          Rctree3_Slots(0, edge->desc, slotv[1], slotv[2]);

        Rctree3_Node_Desc(node, 0, 0, desc_slots);
      }    
    }
    else if(degree == 2) /* Case: Try to Compress. */ {
      rctree3_edge_t* edge_0 = read(slotv[0]);
      rctree3_edge_t* edge_1 = read(slotv[1]);

      rctree3_edge_t* edge_0_mirror = read(edge_0->mirror);
      rctree3_edge_t* edge_1_mirror = read(edge_1->mirror);
    
      rctree3_node_t* targ_0 = read(edge_0->node);
      rctree3_node_t* targ_1 = read(edge_1->node);
    
      uintptr_t pred =
        (node->dice > targ_0->dice) &&
        (node->dice > targ_1->dice) &&
        (!targ_0->sing) &&
        (!targ_1->sing);
    
      if(pred)
      {
        rctree3_compress_node(node, slots,
                              edge_0, targ_0, edge_0_mirror, 
                              edge_1, targ_1, edge_1_mirror);
      }
      else { /* Create a copy. */ 
        uintptr_t desc_degree = (!targ_0->sing + !targ_1->sing);
        modref_t* desc_slot_0 = rctree3_edge_desc(node, edge_0, targ_0, edge_0_mirror);
        modref_t* desc_slot_1 = rctree3_edge_desc(node, edge_1, targ_1, edge_1_mirror);

        /* Re-order slots so that future non-edge slots (scars) are always last. */
        rctree3_slots_t* desc_slots =
          ((!targ_0->sing)
           ? Rctree3_Slots(desc_degree, desc_slot_0, desc_slot_1, slotv[2])
           : Rctree3_Slots(desc_degree, desc_slot_1, desc_slot_0, slotv[2]));

        Rctree3_Node_Desc(node, desc_degree <= 1, 0, desc_slots);
      }
    }
    else if(degree == 3) /* Case: Copy/Descend. */ {
      rctree3_edge_t* edge_0 = read(slotv[0]);
      rctree3_edge_t* edge_1 = read(slotv[1]);
      rctree3_edge_t* edge_2 = read(slotv[2]);

      rctree3_edge_t* edge_0_mirror = read(edge_0->mirror);
      rctree3_edge_t* edge_1_mirror = read(edge_1->mirror);
      rctree3_edge_t* edge_2_mirror = read(edge_2->mirror);

      rctree3_node_t* targ_0 = read(edge_0->node);
      rctree3_node_t* targ_1 = read(edge_1->node);
      rctree3_node_t* targ_2 = read(edge_2->node);

      uintptr_t desc_degree = (!targ_0->sing + !targ_1->sing + !targ_2->sing);
    
      modref_t* desc_slot_0 = rctree3_edge_desc(node, edge_0, targ_0, edge_0_mirror);
      modref_t* desc_slot_1 = rctree3_edge_desc(node, edge_1, targ_1, edge_1_mirror);
      modref_t* desc_slot_2 = rctree3_edge_desc(node, edge_2, targ_2, edge_2_mirror);
    
      /* Re-order slots so that future non-edge slots (scars) are always last. */
      /* TODO: record this reordering somewhere ... or perhaps don't do it? */
      rctree3_slots_t* desc_slots =
        ((!targ_0->sing)
         ? ( (!targ_1->sing)
             ? Rctree3_Slots(desc_degree, desc_slot_0, desc_slot_1, desc_slot_2)
             : Rctree3_Slots(desc_degree, desc_slot_0, desc_slot_2, desc_slot_1) )
         : ( (!targ_1->sing)
             ? Rctree3_Slots(desc_degree, desc_slot_1, desc_slot_2, desc_slot_0)
             : Rctree3_Slots(desc_degree, desc_slot_2, desc_slot_0, desc_slot_1) )
         );
    
      Rctree3_Node_Desc(node, desc_degree <= 1, 0, desc_slots);
    }
    else {
      abort();
    }
  }
}

afun rctree3_contract_round(cons_cell_t* cell,
                            modref_t* dest,
                            modref_t* finals) {
  if(!cell) {
    write(dest, NULL);
  }
  else {
    rctree3_node_t* node = read(cell->hd);
    
    if(node) {
      rctree3_contract_node(node, read(node->slots));
      rctree3_node_t* desc = read(node->desc);

      /* Has non-final descendent? */
      if(desc) {
        if(desc->final) {
          modstack_push(finals, node->desc);
        }
        else {        
          cons_cell_t* cell_out = Cons(node->desc);
          write(dest, cell_out);
          dest = cell_out->tl;        
        }
      }
    }
    
    rctree3_contract_round(read(cell->tl), dest, finals);
  }
}

afun rctree3_contract_rec(uintptr_t roundc,
                          modref_t* nodes,
                          modref_t* dest,
                          modref_t* dummy) {

  if(SLIME_RCTREE3_DEBUG) {
    rctree3_print_hook(read(dummy), roundc, nodes);
  }
  modref_t* stop_cond = modref();
  modref_t* next_nodes  = modref();

  rctree3_contract_round(read(nodes), next_nodes, dest);

  lenlt(read(next_nodes), 1, stop_cond);
    
  if(!(read(stop_cond))) {
    rctree3_contract_rec(roundc+1, next_nodes, dest, dummy);
  }
}


afun rctree3_contract(modref_t* nodes, modref_t* dest, modref_t* dummy) {
  scope();
  modstack_init(dest);
  rctree3_contract_rec(0, nodes, dest, dummy);
}


/* BUGS (comments relocated here after being fixed): */

/* BUG: -- This illustrates a bug in my (old) normalization
   algorithm: The call returns a closure to tail-call, but we
   never invoke it. -- this occurs so long as we perform no
   reads at the call-site, but rather within the callee body
   itself. */

/* BUG: Using this pred within the conditional causes a nested
   conditional to appear in translated code.  When the nested
   conditional fails at some levels, it returns rather than
   going-to the else-branch. */
