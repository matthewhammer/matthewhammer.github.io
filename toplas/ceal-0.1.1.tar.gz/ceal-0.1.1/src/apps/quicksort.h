/* Matthew Hammer <hammer@tt-c.org> */

#ifndef __QUICKSORT_H__
#define __QUICKSORT_H__

#include "modlist.h"

/**
 * \defgroup apps_quicksort Quicksort
 * \ingroup apps
 * @{
 */ 

afun quicksort(modref_t* unsorted,
               int (*isgt)(void*, void*),
               modref_t* sorted);

/* @} */

#endif
