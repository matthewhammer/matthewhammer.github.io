/* Matthew Hammer <hammer@tti-c.org> */

#ifndef __QUICKHULL_H__
#define __QUICKHULL_H__

#include "modlist.h"
#include "geom2d.h"

#define QUICKHULL_SDESTS 0

/**
 * \defgroup apps_quickhull Quick-Hull
 * \ingroup apps
 * @{
 */ 

/** */
afun quickhull(modref_t* points, modref_t* hull);

/* @} */

#endif
