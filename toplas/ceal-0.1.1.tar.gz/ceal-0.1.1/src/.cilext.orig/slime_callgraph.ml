open Printf
open Cil
open Actk_util
open Actk_cfg
open Actk_program

type sac_callgraph = {
  cg_fn0 : sac_function ;
  cg_fns : Sac_fn_set.t ;
  cg_dom : Sac_fn_dom.D.t ;
}

(* Given a set of functions compute and record the call edges. *)
let compute_edges (fns : Sac_fn_set.t) = begin
  
  let clear_function (fn : sac_function) : unit = begin
    fn.fn_preds <- [] ; fn.fn_succs <- [] end
  in
  
  let visit_function (fn : sac_function) : unit = begin
    
    let add_edge (funvar:varinfo) =
      Actk_program.add_edge fn (Actk_program.lookup_function funvar)
    in  

    let visit_instr (instr:sac_instr) = 
      match instr with                
        | Sac_call (funvar, args, loc) -> 
            (* Add an edge to the callee *)
            (add_edge funvar)
              
        (*| Sac_call_ind (defop, funexp, exps, loc) -> ()
          | Sac_call_ord (defop, funvar, exps, loc) -> ()*)
        | _ -> ()
    in  
    let rec visit_term (term:sac_term) =
      match term with
        | Sac_if (exp, term1, term2, loc) -> 
            ( visit_term term1 ; visit_term term2 )
        | Sac_read (def, term1, loc) -> visit_term term1
        | Sac_goto _ -> ()
        | Sac_return _ -> ()
        | Sac_tailcall (funvar, args, loc) -> 
            (* Add an edge to the callee *)
            (add_edge funvar)
    in  
    (Sac_bb_set.iter 
       (fun bb -> 
          (List.iter visit_instr bb.bb_instrs) ;
          (visit_term bb.bb_term))
       fn.fn_cfg.cfg_bbs) ;   
  end
  in
  (Sac_fn_set.iter clear_function fns) ;
  (Sac_fn_set.iter visit_function fns) ;    
end

(* Add a "root function" to the call-graph such that any function that
   has no caller is "called" by the root function. i.e., the new root
   will dominate the entire the graph, which will be connected
   regardless of whether or not the original graph was.  *)
let root_the_graph (fns : Sac_fn_set.t)
    : (sac_function * Sac_fn_set.t)
    = begin
      let root = dummy_function Sac_fn_meta in
      Sac_fn_set.iter 
        (fun fn -> 
           if (List.length fn.fn_preds) = 0 
           then add_edge root fn) fns ;
      (root, Sac_fn_set.add root fns)
    end

let print (cg:sac_callgraph) =
  let dotnode_of_function (fn:sac_function) =
    List.fold_left 
      (fun str gn ->
         str^(sprintf "%s -> %s;\n" 
                (Sac_function.name fn)
                (Sac_function.name gn)))
      "" fn.fn_succs
  in
  let fns_strings = Sac_fn_set.fold 
    (fun fn fns -> (dotnode_of_function fn)::fns)
    cg.cg_fns []
  in
  let f = open_out "callgraph.dot" in
  let _ = fprintf f "digraph %s {\nsize=\"7,9\"; center=\"true\"; \n" "callgraph" in
  let _ = List.iter (fun fn_string -> fprintf f "%s\n" fn_string) fns_strings in
  let _ = fprintf f "}\n" in
  let _ = close_out f in
  ()

let create (fns:Sac_fn_set.t) =
  let _ = compute_edges fns in
  let (fn0, fns) = root_the_graph fns in
  let dom_map = Sac_fn_dom.dominators fns fn0 in
  (*let idom_map = Sac_fn_dom.immediate_dominators fns fn0 dom_map in
    let dom_tree = Sac_fn_dom.dominator_tree fn0 idom_map in
    let _ = Sac_fn_dom.print_dom_tree_graph "calltree" dom_tree in
  *)
  let cg = { cg_fn0 = fn0 ;
             cg_fns = fns ;
             cg_dom = dom_map } in
  let _ = if !actk_print_dot then print cg in
  ( cg )

let function_is_loop_head (fn:sac_function) (cg:sac_callgraph) : bool =
  (* [fn] is a loop head iff there exists a predecessor [gn] such that
     [fn] dominates [gn] *)
  (List.fold_left 
     (fun accum gn -> 
        let gn_dom = Sac_fn_dom.D.find gn cg.cg_dom in
        (Sac_fn_dom.S.mem fn gn_dom) || accum)
     false fn.fn_preds)

let edge_is_inter_context
    (fn:sac_function) 
    (gn:sac_function) 
    (cg:sac_callgraph) : bool =
  (* a call-edge ([fn], [gn]) crosses a context boundary iff 
     1. [gn] is a loop head.
     2. [gn] \notin dom([fn]).
  *)
  (function_is_loop_head gn cg) (* is [gn] a look head? *) 
  && (let fn_dom = Sac_fn_dom.D.find fn cg.cg_dom in
      not (Sac_fn_dom.S.mem gn fn_dom)) (* is [gn] not a dominator of [fn]? *)
    
