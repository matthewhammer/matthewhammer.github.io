open Cil
open Actk_util

let normalize_varinfo_attr (v:varinfo) (attr:string) =
  match unrollType v.vtype with
      TFun(rt, argst, is_vararg, fn_atts) ->
        let rt_atts  = typeAttrs rt in
        let has_rt_atts = hasAttribute attr rt_atts in
        let has_fn_atts = hasAttribute attr fn_atts in
        let has_vi_atts = hasAttribute attr v.vattr in
        
        if (has_rt_atts || has_fn_atts || has_vi_atts) &&
          not (has_fn_atts && has_vi_atts && not has_rt_atts)
        then
          let rt_atts' = dropAttribute attr rt_atts in
          let rt'      = TVoid rt_atts' in
          let vi_atts' = addAttribute (Attr (attr,[])) v.vattr in
          let fn_atts' = addAttribute (Attr (attr,[])) fn_atts in
          out "attribute `%s' found on `%s'" v.vname ;
          v.vattr <- vi_atts' ;
          v.vtype <- TFun(rt', argst, is_vararg, fn_atts') ;
    | _ -> ()

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Visitor that moves the "actk_function" attribute from the
   return-type of a function to the varinfo for the function
   itself. *)
class normalize_attributes () = object(self)
  inherit nopCilVisitor
    
  (* vvdec: Variable Declaration. *)
  method vvdec (v:varinfo) : varinfo visitAction = begin
    normalize_varinfo_attr v "actk_function" ;
    normalize_varinfo_attr v "actk_initializer" ;
    SkipChildren
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)  
(* Vistor that strips "actk" attributes out *)
class stripper () = object(self)
  inherit nopCilVisitor
  method vattr (attr : attribute) : attribute list visitAction = begin
    let Attr(attrname, attrparam) = attr in
    if( attrname = "actk" || 
        attrname = "actk_function" ||
        attrname = "actk_initializer" ||
        attrname = "actk_state" ||
        attrname = "actk_read__TEMP" ) 
    then
      ChangeTo []
    else
      DoChildren
  end
end
