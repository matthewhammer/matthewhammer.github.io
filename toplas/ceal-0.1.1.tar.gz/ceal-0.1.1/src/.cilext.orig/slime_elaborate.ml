open Printf
open Cil
open Actk_util
open Actk_api
open Actk_cfg
open Actk_program
open Actk_callgraph
open Actk_allocation

let debug = if false then out else no_out

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let preprocess_function (fn : sac_function) : unit = begin  
  let visit_instr (instr:sac_instr) = 
    match instr with                
        (* -- Allocations -- compute static information about allocation sites. *)
      | Sac_alloc (_, size_exp, initializer_varinfo, key_exps, _) ->
          ignore (allocation_of_instr size_exp initializer_varinfo key_exps)
      | Sac_modref (_, key_exps, _) ->
          let size_exp = SizeOf(api.apity_modref) in
          let initializer_varinfo = api.apifn_modref_init in
          ignore (allocation_of_instr size_exp initializer_varinfo key_exps)
            
      (* -- Nothing. *)
      | Sac_set (def, loc) -> ()
      | Sac_call_ind (defop, funexp, exps, loc) -> () 
      | Sac_call_ord (defop, funvar, exps, loc) -> ()
      | Sac_call (funvar, args, loc) -> ()
  in
  
  let rec visit_term (term:sac_term) =
    (* -- Nothing. *)
    match term with
      | Sac_if (exp, term1, term2, loc) -> 
          ( visit_term term1 ; visit_term term2 )
      | Sac_read (def, term1, loc) -> visit_term term1
      | Sac_goto (bb_ref, loc) -> ()
      | Sac_return (expop, loc) -> ()
      | Sac_tailcall (funvar, args, loc) -> ()
  in  
  (Sac_bb_set.iter 
     (fun bb -> 
        (List.iter visit_instr bb.bb_instrs) ;
        (visit_term bb.bb_term))
     fn.fn_cfg.cfg_bbs) ;
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
type proto_fieldinfo = 
    (string * typ * int option * attributes * location)

let make_fundec (v:varinfo) =
  { svar = v;
    smaxid = 0;
    slocals = [];
    sformals = [];
    sbody = mkBlock [];
    smaxstmtid = None;
    sallstmts = [];
  } 

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_block_aux_new (al : sac_allocation) : fundec = begin
  
  (* Create a [fundec] for [al.al_blockinfo.bl_aux_new] *)
  let name = (allocation_basename al) ^ "_new" in
  let init_fundec = lookup_source_fundec al.al_initsvar in
  let typ_formals = List.fold_left
    (fun formals formal -> 
       (formal.vname, formal.vtype, formal.vattr)::formals)
    [] init_fundec.sformals
  in
  let typ = TFun(al.al_blockinfo.bl_typeptr, Some typ_formals, false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in

  (* Update [bl.bl_blockinfo.bl_formals] with new formal variables for
     [bl.bl_blockinfo.cl_aux_new] *)
  let _ = 
    let visit_formalkey fk = begin
      let init_var = fk.fk_aux_init in
      fk.fk_aux_new <- 
        makeFormalVar fundec init_var.vname init_var.vtype ;
    end
    in
    (List.iter visit_formalkey al.al_blockinfo.bl_formals)
  in

  let tmp_block = makeTempVar fundec al.al_blockinfo.bl_typeptr in

  let bindblock_stmt =
    mkStmt (Instr [(Call (Some (Var tmp_block, NoOffset),
                          Lval (Var api.apifn_block_new, NoOffset),
                          [AddrOf (Var al.al_blockinfo.bl_staticinfo, NoOffset);
                           al.al_sizeexp],
                          locUnknown))])
  in
  
  let return_stmt =
    mkStmt (Return (Some (Lval (Var tmp_block, NoOffset)), locUnknown)) in

  let init_stmts =
    let handle_formalkey fk =
      Formatcil.cStmts 
        "(*block) %o:keyo = keyv;"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("block", Fv tmp_block);
          ("keyo", Fo fk.fk_offset);
          ("keyv", Fv fk.fk_aux_new); ]
    in
    List.flatten (List.map handle_formalkey al.al_blockinfo.bl_formals)
  in
  fundec.sbody <- mkBlock ([bindblock_stmt] @ init_stmts @ [return_stmt]);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_block_aux_init (al : sac_allocation) = begin
  (* Create a [fundec] for [al.al_blockinfo.bl_aux_init] *)
  let name = (allocation_basename al) ^ "_init" in
  let typ = TFun(voidType, Some [
                   ("block", al.al_blockinfo.bl_typeptr, [])
                 ], false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in
  let block_var = makeFormalVar fundec ~where:"$" "block" al.al_blockinfo.bl_typeptr in
  
  let (init_fn,_) = lookup_init_function al.al_initsvar in
  let init_fundec = init_fn.fn_fundec in
  let ptr_var = List.hd init_fundec.sformals in

  let unpack_instrs = List.map 
    (fun fk ->
       Set ((Var fk.fk_aux_init, NoOffset), 
            Lval (Mem (Lval (Var block_var, NoOffset)), fk.fk_offset),
            locUnknown)) 
    al.al_blockinfo.bl_formals
  in
  let unpack_stmt = 
    mkStmt (Instr (unpack_instrs)) in

  let bindptr_stmt =
    mkStmt (Instr [Set ((Var ptr_var, NoOffset),
                        CastE (ptr_var.vtype, 
                               Lval (Mem (Lval (Var block_var, NoOffset)),
                                     al.al_blockinfo.bl_reqspace)),
                        locUnknown)])
  in  
  (* TODO -- need to make deep copies of the varinfo's and stmts we
     use here: (probably?) *)
  fundec.slocals <- (fundec.slocals
                     @ init_fundec.sformals
                     @ init_fundec.slocals);
  fundec.sbody <- 
    mkBlock (unpack_stmt 
             :: bindptr_stmt 
             :: init_fundec.sbody.bstmts) ;
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_block_aux_size (al : sac_allocation) = begin
  (* Create a [fundec] for [al.al_blockinfo.bl_aux_equals] *)
  let name = (allocation_basename al) ^ "_size" in
  let typ = TFun(uintType, Some [
                   ("block", al.al_blockinfo.bl_typeptr, []);
                 ], false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in
  let block_var = makeFormalVar fundec ~where:"$" "block" al.al_blockinfo.bl_typeptr in
  fundec.sbody <- mkBlock 
    [mkStmt (Return (Some (SizeOf(al.al_blockinfo.bl_typedef)), 
                     locUnknown))];
  fundec    
end  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_block_aux_keyc (al : sac_allocation) = begin
  (* Create a [fundec] for [al.al_blockinfo.bl_aux_equals] *)
  let name = (allocation_basename al) ^ "_keyc" in
  let typ = TFun(intType, Some [
                   ("block", al.al_blockinfo.bl_typeptr, []);
                 ], false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in
  let block_var = makeFormalVar fundec ~where:"$" "block" al.al_blockinfo.bl_typeptr in  
  fundec.sbody <- mkBlock ([mkStmt (Return (Some (integer (List.length al.al_keytypes)), locUnknown))]);
  fundec    
end  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_block_aux_hash (al : sac_allocation) = begin
  (* Create a [fundec] for [al.al_blockinfo.bl_aux_equals] *)
  let name = (allocation_basename al) ^ "_hash" in
  let typ = TFun(intType, Some [
                   ("block", al.al_blockinfo.bl_typeptr, []);
                 ], false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in
  let block_var = makeFormalVar fundec ~where:"$" "block" al.al_blockinfo.bl_typeptr in
  
  let result = makeTempVar fundec uintType in
  
  (* Initially, assume result = 1 *)
  let result_init_stmt = let i = 
    (Set ((Var result, NoOffset), zero, locUnknown)) in (mkStmt (Instr [i])) in
  
  (* Return the result. *)
  let result_return_stmt = 
    mkStmt (Return (Some (Lval (Var result, NoOffset)), locUnknown)) in
  
  (* For each argument, test equality and set result=0 if this test fails. *)
  let hash_stmts = 
    let handle_formalkey fk = 
      Formatcil.cStmt
        "result = hashword(result, (unsigned int) (*block) %o:keyo);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("block", Fv block_var);
          ("keyo", Fo fk.fk_offset);
          ("hashword", Fv api.apifn_hashword);
          ("result", Fv result);
        ]
    in
    (List.map handle_formalkey al.al_blockinfo.bl_formals)
  in
  fundec.sbody <- mkBlock ([result_init_stmt] @ hash_stmts @ [result_return_stmt]);
  fundec    
end  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_block_aux_equals (al : sac_allocation) = begin
  (* Create a [fundec] for [al.al_blockinfo.bl_aux_equals] *)
  let name = (allocation_basename al) ^ "_equals" in
  let typ = TFun(intType, Some [
                   ("block1", al.al_blockinfo.bl_typeptr, []);
                   ("block2", al.al_blockinfo.bl_typeptr, []);
                 ], false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in
  let block_var_1 = makeFormalVar fundec ~where:"$" "block1" al.al_blockinfo.bl_typeptr in
  let block_var_2 = makeFormalVar fundec ~where:"$" "block2" al.al_blockinfo.bl_typeptr in
  
  let result = makeTempVar fundec intType in
  
  (* Initially, assume result = 1 *)
  let result_init_stmt = let i = 
    (Set ((Var result, NoOffset), one, locUnknown)) in (mkStmt (Instr [i])) in
  
  (* Return the result. *)
  let result_return_stmt = 
    mkStmt (Return (Some (Lval (Var result, NoOffset)), locUnknown)) in
  
  (* For each argument, test equality and set result=0 if this test fails. *)
  let if_stmt = 
    let handle_formalkey fk else_stmt = 
      Formatcil.cStmt
        "if( (*block_1) %o:keyo != (*block_2) %o:keyo )
           result = 0;
         else %s:else_stmt"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("block_1", Fv block_var_1);
          ("block_2", Fv block_var_2);
          ("keyo", Fo fk.fk_offset);
          ("else_stmt", Fs else_stmt);
          ("result", Fv result);
        ]
    in
    (List.fold_right handle_formalkey al.al_blockinfo.bl_formals (mkStmt (Instr [])))
  in
  fundec.sbody <- mkBlock ([result_init_stmt; if_stmt; result_return_stmt]);
  fundec    
end  


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let elaborate_blockinfo (al : sac_allocation) =
  
  let _ = debug "elaborating: %s" (allocation_basename al) in

  let basename = allocation_basename al in
  let init_fundec = lookup_source_fundec al.al_initsvar in

  let (ptr_sformal, key_sformals) = 
    match init_fundec.sformals with
      | ptr_sformal::key_sformals -> (ptr_sformal, key_sformals)
      | _ -> raise Hell
  in

  let compinfo =      
    let mkfields _ =
      let make_proto_fields (formal:varinfo) : proto_fieldinfo list =
        let basename = formal.vname in
        [ (basename^"_key", formal.vtype, None, formal.vattr, locUnknown) ]
      in
      let fields = List.flatten (List.map make_proto_fields key_sformals) in
      ("block", api.apity_block, None, [], locUnknown)
      :: ("reqspace", TArray (charType, Some al.al_sizeexp, []), None, [], locUnknown)
      :: fields
    in
    mkCompInfo true (basename^"_s") mkfields []
  in
  
  let formalkeys : sac_formalkey list =
    let rec loop fields formals = match (fields, formals) with
        (field::rest_fields, var::rest_formals) ->          
          let formalkey = 
            { fk_aux_init = var; 
              fk_aux_new = dummy_var;
              fk_offset = Field (field, NoOffset);
            }
          in formalkey :: (loop rest_fields rest_formals)
      | ([], []) ->  []
      | ([], _ ) -> raise (Bug "more variables than fields!")
      | ( _, []) -> raise (Bug "more fields than variables!")
    in 
    match compinfo.cfields with
      | block::reqspace::rest_fields -> 
          al.al_blockinfo.bl_reqspace <- Field (reqspace, NoOffset) ;
          (loop rest_fields key_sformals)
      | _ -> raise (Bug "too few fields!")
  in

  let typeinfo = {tname=basename^"_t";
                  ttype=TComp(compinfo,[]);
                  treferenced=true;} in
  let typedef = TNamed(typeinfo, []) in
  let typeptr = TPtr(typedef, []) in
  let staticinfo = makeGlobalVar (basename^"_staticinfo")
    api.apity_block_staticinfo in

  begin
    al.al_blockinfo <-
      {al.al_blockinfo with
         bl_compinfo = compinfo ;
         bl_formals  = formalkeys ;
         bl_staticinfo = staticinfo ;
         bl_typedef = typedef ;
         bl_typeptr = typeptr ;
      } ;
    al.al_blockinfo.bl_aux_new <- make_block_aux_new al;
    al.al_blockinfo.bl_aux_size <- make_block_aux_size al;
    al.al_blockinfo.bl_aux_keyc <- make_block_aux_keyc al;
    al.al_blockinfo.bl_aux_hash <- make_block_aux_hash al;
    al.al_blockinfo.bl_aux_equals <- make_block_aux_equals al;
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Make global of type block_staticinfo_t; Initialized with the given blockinfo *)
let make_block_staticinfo (al : sac_allocation) : global = begin
  
  let compinfo = match api.apity_block_staticinfo with 
      TNamed({ttype=TComp(compinfo, _)}, _) -> compinfo | _ -> raise Hell in
  
  let offset_and_init field var =
    let offset = Field(field, NoOffset) in
    let varinit = SingleInit(CastE(field.ftype, Lval(Var var, NoOffset))) in
    (offset, varinit) in
  
  let offset_and_init_from_field field = 
    let bl = al.al_blockinfo in
    match field.fname with
      | "init"    -> offset_and_init field bl.bl_aux_init.svar
      | "size"    -> offset_and_init field bl.bl_aux_size.svar
      | "keyc"    -> offset_and_init field bl.bl_aux_keyc.svar
      | "hash"    -> offset_and_init field bl.bl_aux_hash.svar
      | "equals"  -> offset_and_init field bl.bl_aux_equals.svar
      | _         -> out "what is %s?" field.fname ; raise Hell
  in

  let field_inits = List.map offset_and_init_from_field compinfo.cfields in
  
  let initinfo = 
    {init = Some (CompoundInit (api.apity_block_staticinfo, field_inits))} in
  
  GVar(al.al_blockinfo.bl_staticinfo, initinfo, locUnknown)
end


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Closure construction for the given function *)
let make_closure_aux_new (fn : sac_function) (cl : sac_closinfo) : fundec = begin
  
  (* Create a [fundec] for [cl.cl_aux_new] *)
  let name = fn.fn_fundec.svar.vname ^ "_closure_new" in
  let typ_formals = List.fold_left
    (fun formals formal -> 
       (formal.vname, formal.vtype, formal.vattr)::
         (formal.vname^"_mod", api.apity_modref, [])::formals)
    [] fn.fn_fundec.sformals
  in
  let typ = TFun(cl.cl_typeptr, Some typ_formals, false, []) in
  let var = makeGlobalVar name typ in
  let fundec = make_fundec var in
  
  (* Update [cl.cl_formals] with new formal variables for
     [cl.cl_aux_new] *)
  let _ = 
    let visit_formalarg fa = begin
      let var = fa.fa_var in
      fa.fa_valv <- makeFormalVar fundec (var.vname^"_val") (var.vtype) ;
      fa.fa_modv <- makeFormalVar fundec (var.vname^"_mod") (TPtr(api.apity_modref,[])) ;
    end
    in
    (List.map visit_formalarg cl.cl_formals)
  in
  
  (* Now, generate the actual body of the function: *)

  let tmp_closure = makeTempVar fundec cl.cl_typeptr in
  
  let bindclosure_stmt = 
    mkStmt (Instr [(Call (Some (Var tmp_closure, NoOffset), 
                          Lval (Var api.apifn_closure_new, NoOffset), 
                          [AddrOf (Var cl.cl_staticinfo, NoOffset)], 
                          locUnknown))])
  in
  
  let return_stmt = 
    mkStmt (Return (Some(Lval (Var tmp_closure, NoOffset)), locUnknown)) in
  
  let init_stmts =
    let handle_formalarg fa = 
      Formatcil.cStmts
        "(*closure) %o:valf = valv;
         (*closure) %o:modf = modv;
         (*closure) %o:hanf = (void*) 0;"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure", Fv tmp_closure);
          ("valf", Fo (Field (fa.fa_valf, NoOffset)));
          ("valv", Fv fa.fa_valv);
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("modv", Fv fa.fa_modv);
          ("hanf", Fo (Field (fa.fa_hanf, NoOffset)));
          ("modref_ptr_t", Ft (TPtr(api.apity_modref,[])));
          ("val_t", Ft fa.fa_var.vtype);
        ]
    in  
    List.flatten (List.map handle_formalarg cl.cl_formals)
  in
  fundec.sbody <- mkBlock ([bindclosure_stmt] @ init_stmts @ [return_stmt]);  
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_closure_aux_subscribe (fn : sac_function) (cl : sac_closinfo) : fundec = begin
  let name = fn.fn_fundec.svar.vname ^ "_closure_subscribe" in
  let typ = TFun(voidType, Some [("closure", cl.cl_typeptr, [])], false, []) in
  let fundec = make_fundec (makeGlobalVar name typ) in
  let clvar = makeFormalVar fundec ~where:"$" "closure" cl.cl_typeptr in
  let stmts =
    let handle_formalarg fa = 
      Formatcil.cStmts
        "if ((*closure) %o:modf)
           (*closure) %o:hanf = addread((*closure) %o:modf, (%t:closure_t) closure);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure", Fv clvar);
          ("closure_t", Ft (TPtr(api.apity_closure, [])) );
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("hanf", Fo (Field (fa.fa_hanf, NoOffset)));
          ("addread", Fv api.apifn_modref_addread);
        ]
    in  
    List.flatten (List.map handle_formalarg cl.cl_formals)
  in
  fundec.sbody <- mkBlock (stmts);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_closure_aux_unsubscribe (fn : sac_function) (cl : sac_closinfo) : fundec = begin
  let name = fn.fn_fundec.svar.vname ^ "_closure_unsubscribe" in
  let typ = TFun(voidType, Some [("closure", cl.cl_typeptr, [])], false, []) in
  let fundec = make_fundec (makeGlobalVar name typ) in
  let clvar = makeFormalVar fundec ~where:"$" "closure" cl.cl_typeptr in
  let stmts =
    let handle_formalarg fa = 
      Formatcil.cStmts
        "if ((*closure) %o:modf)
           remread((*closure) %o:modf, (*closure) %o:hanf, (%t:closure_t) closure);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure", Fv clvar);
          ("closure_t", Ft (TPtr(api.apity_closure, [])) );
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("hanf", Fo (Field (fa.fa_hanf, NoOffset)));
          ("remread", Fv api.apifn_modref_remread);
        ]
    in  
    List.flatten (List.map handle_formalarg cl.cl_formals)
  in
  fundec.sbody <- mkBlock (stmts);
  fundec    
end


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_closure_aux_refresh (fn : sac_function) (cl : sac_closinfo) = begin
  let name = fn.fn_fundec.svar.vname ^ "_closure_refresh" in
  let typ = TFun(voidType, Some [("closure", cl.cl_typeptr, [])], false, []) in
  let fundec = make_fundec (makeGlobalVar name typ) in
  let clvar = makeFormalVar fundec ~where:"$" "closure" cl.cl_typeptr in
  let stmts =
    let handle_formalarg fa = 
      Formatcil.cStmts
        "if ((*closure) %o:modf)
           (*closure) %o:valf = deref((*closure) %o:modf);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure", Fv clvar);
          ("closure_t", Ft (TPtr(api.apity_closure, [])) );
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("valf", Fo (Field (fa.fa_valf, NoOffset)));
          ("deref", Fv api.apifn_modref_deref);
        ]
    in  
    List.flatten (List.map handle_formalarg cl.cl_formals)
  in
  fundec.sbody <- mkBlock (stmts);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_closure_aux_replace (fn : sac_function) (cl : sac_closinfo) : fundec = begin
  let name = fn.fn_fundec.svar.vname ^ "_closure_replace" in
  let typ = TFun(voidType, Some 
                   [("closure_old", cl.cl_typeptr, []);
                    ("closure_new", cl.cl_typeptr, [])], 
                 false, []) in
  let fundec = make_fundec (makeGlobalVar name typ) in
  let clvar_old = makeFormalVar fundec ~where:"$" "closure_old" cl.cl_typeptr in
  let clvar_new = makeFormalVar fundec ~where:"$" "closure_new" cl.cl_typeptr in

  let unsubscribe_stmt = let i = 
    (Call (None, Lval (Var cl.cl_aux_unsubscribe.svar, NoOffset), 
           [Lval (Var clvar_old, NoOffset);], locUnknown)) in (mkStmt (Instr [i])) in

  let subscribe_stmt = let i = 
    (Call (None, Lval (Var cl.cl_aux_subscribe.svar, NoOffset), 
           [Lval (Var clvar_old, NoOffset);], locUnknown)) in (mkStmt (Instr [i])) in
  
  let stmts =
    let handle_formalarg fa = 
      Formatcil.cStmts
        "(*closure_old) %o:valf = (*closure_new) %o:valf;
         (*closure_old) %o:modf = (*closure_new) %o:modf;
         (*closure_old) %o:hanf = (void*) 0;"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure_old", Fv clvar_old);
          ("closure_new", Fv clvar_new);
          ("valf", Fo (Field (fa.fa_valf, NoOffset)));
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("hanf", Fo (Field (fa.fa_hanf, NoOffset)));
        ]
    in 
    List.flatten (List.map handle_formalarg cl.cl_formals)
  in
  fundec.sbody <- mkBlock ([unsubscribe_stmt] @ stmts @ [subscribe_stmt]);
  fundec    
end


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_closure_aux_equals (fn : sac_function) (cl : sac_closinfo) : fundec = begin
  let name = fn.fn_fundec.svar.vname ^ "_closure_equals" in
  let typ = TFun(intType, Some 
                   [("closure_1", cl.cl_typeptr, []);
                    ("closure_2", cl.cl_typeptr, [])], 
                 false, []) in
  let fundec = make_fundec (makeGlobalVar name typ) in
  let clvar_1 = makeFormalVar fundec ~where:"$" "closure_1" cl.cl_typeptr in
  let clvar_2 = makeFormalVar fundec ~where:"$" "closure_2" cl.cl_typeptr in
  let result = makeTempVar fundec intType in
  
  (* Initially, assume result = 1 *)
  let result_init_stmt = let i = 
    (Set ((Var result, NoOffset), one, locUnknown)) in (mkStmt (Instr [i])) in
  
  (* Return the result. *)
  let result_return_stmt = 
    mkStmt (Return (Some (Lval (Var result, NoOffset)), locUnknown)) in
  
  (* For each argument, test equality and set result=0 if this test fails. *)
  let if_stmt = 
    let handle_formalarg fa else_stmt = 
      Formatcil.cStmt
        "if( (*closure_1) %o:valf != (*closure_2) %o:valf )
           result = 0;
         else %s:else_stmt"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure_1", Fv clvar_1);
          ("closure_2", Fv clvar_2);
          ("valf", Fo (Field (fa.fa_valf, NoOffset)));
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("hanf", Fo (Field (fa.fa_hanf, NoOffset)));
          ("else_stmt", Fs else_stmt);
          ("result", Fv result);
        ]
    in
    (List.fold_right handle_formalarg cl.cl_formals (mkStmt (Instr [])))
  in
  fundec.sbody <- mkBlock ([result_init_stmt; if_stmt; result_return_stmt]);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_closure_aux_hash (fn : sac_function) (cl : sac_closinfo) : fundec = begin
  let name = fn.fn_fundec.svar.vname ^ "_closure_hash" in
  let typ = TFun(uintType, Some [("closure", cl.cl_typeptr, [])], false, []) in
  let fundec = make_fundec (makeGlobalVar name typ) in
  let clvar = makeFormalVar fundec ~where:"$" "closure" cl.cl_typeptr in
  let result = makeTempVar fundec uintType in
  
  (* Initially, set hash to zero. *)
  let result_init_stmt = let i = 
    (Set ((Var result, NoOffset), zero, locUnknown)) in (mkStmt (Instr [i])) in
  
  (* Return the resulting hash. *)
  let result_return_stmt = 
    mkStmt (Return (Some (Lval (Var result, NoOffset)), locUnknown)) in
  
  (* For each argument, test equality and set result=0 if this test fails. *)
  let hash_stmts = 
    let handle_formalarg fa = 
      Formatcil.cStmt
        "result = hashword(result, (unsigned int) (*closure) %o:valf);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure", Fv clvar);
          ("valf", Fo (Field (fa.fa_valf, NoOffset)));
          ("modf", Fo (Field (fa.fa_modf, NoOffset)));
          ("hanf", Fo (Field (fa.fa_hanf, NoOffset)));
          ("hashword", Fv api.apifn_hashword);
          ("result", Fv result);
        ]
    in
    (List.map handle_formalarg cl.cl_formals)
  in
  fundec.sbody <- mkBlock ([result_init_stmt] @ hash_stmts @ [result_return_stmt]);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Make global of type closure_staticinfo_t; Initialized with the given closinfo *)
let make_closure_staticinfo (fn : sac_function) (cl : sac_closinfo) : global = begin
  
  let compinfo = match api.apity_closure_staticinfo with 
      TNamed({ttype=TComp(compinfo, _)}, _) -> compinfo | _ -> raise Hell in
  
  let offset_and_init field var =
    let offset = Field(field, NoOffset) in
    let varinit = SingleInit(CastE(field.ftype, Lval(Var var, NoOffset))) in
    (offset, varinit) in
  
  let offset_and_init_from_field field = 
    match field.fname with
        "size"        -> (Field(field, NoOffset), SingleInit(SizeOf cl.cl_typedef))
      | "code"        -> offset_and_init field fn.fn_fundec.svar
      | "subscribe"   -> offset_and_init field cl.cl_aux_subscribe.svar
      | "unsubscribe" -> offset_and_init field cl.cl_aux_unsubscribe.svar
      | "refresh"     -> offset_and_init field cl.cl_aux_refresh.svar
      | "replace"     -> offset_and_init field cl.cl_aux_replace.svar
      | "equals"      -> offset_and_init field cl.cl_aux_equals.svar
      | "hash"        -> offset_and_init field cl.cl_aux_hash.svar
      | _             -> out "what is %s?" field.fname ; raise Hell
  in

  let field_inits = List.map offset_and_init_from_field compinfo.cfields in
  
  let initinfo = 
    {init = Some (CompoundInit (api.apity_closure_staticinfo, field_inits))} in
  
  (*
    c.c_staticinfo.vattr <- addAttribute (Attr("const",[])) c.c_staticinfo.vattr ;
    c.c_staticinfo.vattr <- addAttribute (Attr("static",[])) c.c_staticinfo.vattr ;
  *)
  
  GVar(cl.cl_staticinfo, initinfo, locUnknown)
end
  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Boilerplate code elaboration --- Before the code for any
   self-adjusting functions can be elaborated, we have to elaborate
   the "boilerplate" code associated with each function.  This
   consists of several new function declarations (for creating and
   manipulating closures of a given function) as well as new types for
   representing closures of a given function.  Elaborating this
   boilerplate code (done here) is necessary for later elaboration of
   function calls (since each function call will correspond to
   constructing such closures using the boilerplate code). *)
let elaborate_closinfo (fn:sac_function) (closinfo0:sac_closinfo) =
  
  let basename = fn.fn_normal.svar.vname in
  let formals = fn.fn_normal.sformals in
  
  (* The compinfo here will represent instances of closures for the
     given function *)
  let compinfo = 
    (* mkfields -- passed to [mkCompInfo] to "backpatch" the
       [compinfo] record. *)
    let mkfields _ = 
      let make_proto_fields (formal:varinfo) =
        let basename = formal.vname in
        [ (basename^"_val", formal.vtype, None, formal.vattr, locUnknown) ;
          (basename^"_mod", TPtr(api.apity_modref, []), None, [], locUnknown) ;
          (basename^"_han", voidPtrType, None, [], locUnknown) ]
      in
      let fields = List.flatten (List.map make_proto_fields formals) in
      ("closure", api.apity_closure, None, [], locUnknown) :: fields
    in  
    mkCompInfo true (basename^"_closure_s") mkfields [] 
  in
  
  (* The formals here bind closure fields to formal arguments that
     become local variables *)
  let formalargs : sac_formalarg list =
    let rec loop fields formals = match (fields, formals) with
        (valf::modf::hanf::rest_fields, formal::rest_formals) ->
          let formalarg = {fa_var = formal;
                           fa_valf = valf;
                           fa_valv = dummy_var;
                           fa_modf = modf;
                           fa_modv = dummy_var;
                           fa_hanf = hanf; }
          in formalarg :: (loop rest_fields rest_formals)
      | ([], []) -> []
      | _ -> raise Hell
    in loop (List.tl compinfo.cfields) formals
  in

  (* Make some types associated with the function's closures, make a
     global staticinfo instance associated with the function's
     cloures. *)
  let typeinfo  = {tname=basename^"_closure_t";
                   ttype=TComp(compinfo,[]);
                   treferenced=true;} in  
  let typedef    = TNamed(typeinfo, []) in
  let typeptr    = TPtr(typedef, []) in
  let staticinfo = makeGlobalVar (basename^"_closure_staticinfo") 
    api.apity_closure_staticinfo in
  (*let _ = staticinfo.vattr <- addAttribute (Attr ("static",_)) staticinfo.vattr in*)
  
  let closinfo = 
    { closinfo0 with
        cl_compinfo   = compinfo ;
        cl_formals    = formalargs ;
        cl_staticinfo = staticinfo ;
        cl_typedef    = typedef ;
        cl_typeptr    = typeptr ;
    } 
  in
  
  begin 
    fn.fn_kind <- Sac_fn_self closinfo ;
    closinfo.cl_aux_new <- make_closure_aux_new fn closinfo ;
    closinfo.cl_aux_subscribe <- make_closure_aux_subscribe fn closinfo ;
    closinfo.cl_aux_unsubscribe <- make_closure_aux_unsubscribe fn closinfo ;
    closinfo.cl_aux_refresh <- make_closure_aux_refresh fn closinfo ;
    closinfo.cl_aux_replace <- make_closure_aux_replace fn closinfo ;
    closinfo.cl_aux_equals <- make_closure_aux_equals fn closinfo ;
    closinfo.cl_aux_hash <- make_closure_aux_hash fn closinfo ;
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let elaborate_function_auxiliaries (fn:sac_function) =
  begin match fn.fn_kind with
        
    (* Self-adjusting function. *)
    | Sac_fn_self cl -> 
        (elaborate_closinfo fn cl)
          
    (* Initialization function. *)
    | Sac_fn_init als ->
        (Sac_al_set.iter elaborate_blockinfo als)
          
    (* Meta function. *)
    | Sac_fn_meta -> ()
  end  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let elaborate_function (cg:sac_callgraph) (fn:sac_function) =  
  let _ = debug "elaborating: %s" fn.fn_fundec.svar.vname in

  (* Map basic-blocks to statements -- we setup this mapping before we
     elaborate since we need all the statements in-place before we
     elaborate gotos. *)
  let bb_stmt_map = ref Sac_bb_map.empty in
  let _ = Sac_bb_set.iter 
    (fun bb -> begin       
       (* Make a dummy statement for now *)
       let stmt0 = mkStmt (Instr []) in
       
       (* Label the basic-block if it has one or more predecessors --
          we do this check to avoid warnings for any unused labels *)
       if List.length bb.bb_preds > 0 then begin
         (* Create a label for the basic block *)
         let label = Label ((sprintf "sac_basic_block_%d" bb.bb_id), 
                            locUnknown, false) in
         stmt0.labels <- [label] ;
       end ;
       (* add it to the mapping *)
       bb_stmt_map := Sac_bb_map.add bb stmt0 !bb_stmt_map 
     end) fn.fn_cfg.cfg_bbs 
  in       
  
  let null = CastE(voidPtrType,zero) in
  
  (* Make a new local temporary for the elaborated function. *)
  let make_temp_var (typ:typ) : varinfo =
    (makeTempVar fn.fn_fundec typ)    
  in

  let exp_of_var var = 
    Lval(Var var, NoOffset) in

  let exp_of_expop expop = 
    match expop with 
        Some exp -> exp 
      | None -> raise Hell
  in    

  (* Elaborate an optional definition into an optional lval *)
  let elab_defop (defop:sac_def option) : lval option =
    match defop with 
        None -> None
      | Some def -> Some def.df_lval
  in

  (* Elaborate a list of arguments -- all the readargs are elaborated
     as dereferences where the dereferenced value and modifiable being
     dereferenced are both included. *)
  let rec elab_args (args:sac_arg list) : instr list * exp list =
    match args with
        [] -> ([], [])
      | arg::args -> begin
          let (instrs, exps) = elab_args args in
          match arg with
              Sac_exp(exp) -> 
                (instrs, exp::null::exps)

            | Sac_readarg(exp) -> 
                let tmp = make_temp_var voidPtrType in
                let deref_instr = Call 
                  (Some (Var tmp, NoOffset), 
                   exp_of_var api.apifn_modref_deref, [exp], 
                   locUnknown) in
                (deref_instr::instrs, 
                 (exp_of_var tmp)::exp::exps)
        end
  in
  
  (* Generate instructions to push a context for the callee if
     necessary.  Also generate instructions to restore the callers
     context, if applicable. *)
  let rec elab_callee_context_instrs (gn:sac_function) : (instr list * instr list) =
    if not (edge_is_inter_context fn gn cg) 
    then ([], []) 
    else begin
      ignore (debug "edge requires a context-switch: %s -> %s"
                fn.fn_fundec.svar.vname
                gn.fn_fundec.svar.vname) ;
      let tmp = make_temp_var (TPtr(api.apity_context, [])) in
      let instr1 = Call(Some (Var tmp, NoOffset), exp_of_var api.apifn_context_push, [], locUnknown) in
      let instr2 = Call(None, exp_of_var api.apifn_context_restore, [exp_of_var tmp], locUnknown) in
      ([instr1], [instr2])
    end
  in
  
  (* Elaborate a list of instructions *)
  let rec elab_instrs (instrs:sac_instr list) : instr list =
    match instrs with
        [] -> []
          
      (* Set *)
      | (Sac_set(def,loc))::instrs ->
          (Set(def.df_lval, exp_of_expop def.df_exp, loc))
          ::(elab_instrs instrs)
            
      (* Self-adjusting Call *)
      | (Sac_call(funvar, args, loc))::instrs ->
          let (gn, cl) = lookup_self_function funvar in
          let closure_new = cl.cl_aux_new.svar in
          let tmp = make_temp_var cl.cl_typeptr in 
          let (arg_instrs, arg_exps) = elab_args args in
          let (cxt_instrs1, cxt_instrs2) = elab_callee_context_instrs gn in
          let instr1 = Call(Some (Var tmp, NoOffset), exp_of_var closure_new, arg_exps, loc) in
          let instr2 = Call(None, exp_of_var api.apifn_closure_call, 
                            [CastE(TPtr(api.apity_closure, []), exp_of_var tmp)], 
                            locUnknown) in
          (cxt_instrs1 @ arg_instrs @ (instr1::instr2::(cxt_instrs2 @ (elab_instrs instrs))))
            
      (* Ordinary Call *)
      | (Sac_call_ord(defop, funvar, exps, loc))::instrs ->
          (Call(elab_defop defop, exp_of_var funvar, exps, loc))
          ::(elab_instrs instrs)
            
      (* Indirect Call *)
      | (Sac_call_ind(defop, funexp, exps, loc))::instrs ->
          (Call(elab_defop defop, funexp, exps, loc))
          ::(elab_instrs instrs)
            
      (* Allocation *)
      | (Sac_alloc (def, size_exp, init_funvar, key_exps, loc))::instrs ->
          let al = allocation_of_instr size_exp init_funvar key_exps in
          let block_new = al.al_blockinfo.bl_aux_new.svar in
          let tmp = make_temp_var al.al_blockinfo.bl_typeptr in
          let instr1 = Call(Some (Var tmp, NoOffset), exp_of_var block_new, key_exps, loc) in
          let instr2 = Call(Some def.df_lval, exp_of_var api.apifn_block_alloc,
                            [CastE(TPtr(api.apity_block, []), exp_of_var tmp)],
                            locUnknown) in
          instr1::instr2::(elab_instrs instrs)
            
      (* Modifiable *)            
      | (Sac_modref (def, key_exps, loc))::instrs ->
          let size_exp = SizeOf(api.apity_modref) in
          let init_funvar = api.apifn_modref_init in
          let al = allocation_of_instr size_exp init_funvar key_exps in
          let block_new = al.al_blockinfo.bl_aux_new.svar in
          let tmp = make_temp_var al.al_blockinfo.bl_typeptr in
          let instr1 = Call(Some (Var tmp, NoOffset), exp_of_var block_new, key_exps, loc) in
          let instr2 = Call(Some def.df_lval, exp_of_var api.apifn_block_alloc,
                            [CastE(TPtr(api.apity_block, []), exp_of_var tmp)],
                            locUnknown) in          
          instr1::instr2::(elab_instrs instrs)
  in  
  
  (* Elaborate a terminal instruction *)
  let rec elab_term (term:sac_term) : stmt list =
    match term with
        (* If *)
        Sac_if (exp, term1, term2, loc) ->
          let block1 = mkBlock (elab_term term1) in
          let block2 = mkBlock (elab_term term2) in
          [mkStmt (If (exp, block1, block2, loc))]

      | Sac_read _ -> raise Hell
          
      (* Tailcall *)
      | Sac_tailcall (funvar, args, loc) ->
          let (gn, cl) = lookup_self_function funvar in
          let closure_new = cl.cl_aux_new.svar in
          let tmp = make_temp_var cl.cl_typeptr in 
          let (arg_instrs, arg_exps) = elab_args args in
          let (cxt_instrs, _) = elab_callee_context_instrs gn in
          let call = Call(Some (Var tmp, NoOffset), exp_of_var closure_new, arg_exps, loc) in
          let ret = CastE (TPtr(api.apity_closure, []), exp_of_var tmp) in
          [mkStmt (Instr (arg_instrs @ cxt_instrs @ [call])); 
           mkStmt (Return (Some ret, locUnknown))]
            
      (* Goto *)
      | Sac_goto (bb_ref, loc) ->
          let bb_stmt = Sac_bb_map.find !bb_ref !bb_stmt_map in
          [mkStmt (Goto(ref bb_stmt, loc))]
            
      (* Return *)
      | Sac_return (expop, loc) -> begin
          match (fn.fn_kind, expop) with
            | (Sac_fn_self _, None) -> [mkStmt (Return(Some null, loc))]
            | (Sac_fn_self _, _) -> raise Hell
            | (Sac_fn_init _, None) -> [mkStmt (Return(None, loc))]
            | (Sac_fn_init _, _) -> raise Hell
            | (Sac_fn_meta, expop) -> [mkStmt (Return(expop, loc))]
        end
  in
  
  (* Elaborate a basic block *)
  let elab_basic_block (bb:sac_basic_block) : stmt =
    begin
      let stmt = Sac_bb_map.find bb !bb_stmt_map in
      let instrs = elab_instrs bb.bb_instrs in
      let instrs_stmt = mkStmt (Instr instrs) in
      let term_stmts = elab_term bb.bb_term in
      let block = mkBlock (instrs_stmt::term_stmts) in
      stmt.skind <- Block block ;      
      stmt
    end 
  in
  
  (* Elaborate the formals -- this creates code to unpack the formals
     from the current closure *)
  let elab_formals _ : stmt =
    let empty_stmt = mkStmt (Instr []) in
    match fn.fn_kind with
      | Sac_fn_init _  -> empty_stmt
      | Sac_fn_meta    -> empty_stmt
      | Sac_fn_self cl -> begin
          let _ = fn.fn_fundec.sformals <- [] in
          
          (* Make a formal to hold the current-closure *)
          let closure_var = (makeFormalVar 
                               fn.fn_fundec "closure" 
                               cl.cl_typeptr) in
          
          (* Unpack the arguments from the current-closure into local vars *)
          let unpack_instrs = List.map 
            begin fun formalarg -> 
              Set ((Var formalarg.fa_var, NoOffset), 
                   Lval (Mem (Lval (Var closure_var, NoOffset)), 
                         Field (formalarg.fa_valf, NoOffset)),
                   locUnknown)
            end
            cl.cl_formals
          in
          mkStmt (Instr (unpack_instrs))
        end
  in
  
  (* Elaborate a CFG. *)
  let elab_cfg (cfg:sac_cfg) : block =
    let formal_stmt = elab_formals () in
    let bb0_stmt = (elab_basic_block cfg.cfg_bb0) in
    let bbs_stmts = Sac_bb_set.fold 
      (fun bb stmts -> (elab_basic_block bb)::stmts) 
      (Sac_bb_set.remove cfg.cfg_bb0 cfg.cfg_bbs) []
    in
    (mkBlock (formal_stmt :: bb0_stmt :: bbs_stmts))
  in  
  begin 
    match fn.fn_kind with
        
      (* Self-adjusting function. *)
      | Sac_fn_self cl -> begin          
          (* Update the return-type. *)
          fn.fn_fundec.svar.vtype <-
            (match fn.fn_fundec.svar.vtype with
                 TFun(voidType, formal_types, false, attr) ->
                   TFun(TPtr(api.apity_closure, []), formal_types, false, attr)
               | _ -> raise Hell);          
          
          (* Update the formals and locals *)
          fn.fn_fundec.slocals <- 
            (fn.fn_normal.sformals @ fn.fn_normal.slocals) ;
          
          (* Update the function body *)
          fn.fn_fundec.sbody <- elab_cfg fn.fn_cfg ;
        end
          
      | Sac_fn_init als -> 
          (* Update the function body *)
          fn.fn_fundec.sbody <- elab_cfg fn.fn_cfg ;

          (Sac_al_set.iter 
             (fun al -> al.al_blockinfo.bl_aux_init <- make_block_aux_init al)
             als)
               
      | Sac_fn_meta -> 
          (* Update the function body *)
          fn.fn_fundec.sbody <- elab_cfg fn.fn_cfg ;
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Elaborates all the self-adjusting functions currently part of the
   program -- this should only be performed once all the
   self-adjusting functions have been added to the program. *)
let elaborate_program _ = begin
  debug "elaborate_program:" ;    
  
  debug "elaborate_program: (preprocessing ...)" ;
  (Sac_fn_set.iter preprocess_function (!sac_functions)) ;

  debug "elaborate_program: (elaborating function auxiliaries ...):" ;
  (Sac_fn_set.iter elaborate_function_auxiliaries (!sac_functions)) ;
  
  debug "elaborate_program: (creating callgraph ...)" ;
  let cg = Actk_callgraph.create (!sac_functions) in
  
  debug "elaborate_program: (elaborating functions ...):" ;
  (Sac_fn_set.iter (elaborate_function cg) (!sac_functions)) ;
  
  out "elaborating program: done." ;
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Elaborate Function Prototypes *)

let elaborated_prototypes = ref Sac_fn_set.empty

let rec elaborate_prototype (fn:sac_function) (loc:location) : global list =  
  let fn_name = fn.fn_fundec.svar.vname in
  if (Sac_fn_set.mem fn !elaborated_prototypes) 
  then [GText (sprintf "/* skipping-elaboration-proto:%s */" fn_name)]
  else 
    let _ = elaborated_prototypes := 
      (Sac_fn_set.add fn !elaborated_prototypes) 
    in
    match fn.fn_kind with
        (* Self-adjusting function. *)
        (* Elaborate the declaration of a self-adjusting function --
           this produces two things for the function: (1) a typedef for
           closures of the function (2) a function prototype for
           creating these closures *)
      | Sac_fn_self closinfo -> begin
          let typeinfo = match closinfo.cl_typedef with
            | TNamed(typeinfo, _) -> typeinfo 
            | _ -> raise Hell
          in
          [ GText (sprintf "/* begin-elaborated-proto:%s (self-adjusting) */" fn_name) ;
            GType (typeinfo, loc) ;
            GVarDecl (closinfo.cl_aux_new.svar, locUnknown) ;
            GText (sprintf "/* end-elaborated-proto:%s (self-adjusting) */" fn_name) ]
        end
          
      (* Initialization function *)
      | Sac_fn_init als ->
          let als = Sac_al_set.elements als in          
          let elaborate_allocation al = 
            let typeinfo = match al.al_blockinfo.bl_typedef with
              | TNamed (typeinfo, _) -> typeinfo
              | _ -> raise Hell
            in
            [(GType (typeinfo, loc));
             (GVarDecl (al.al_blockinfo.bl_aux_new.svar, locUnknown))]
          in
          GText (sprintf "/* begin-elaborated-proto:%s (init) */" fn_name)
          :: (List.flatten (List.map elaborate_allocation als))
          @[ GText (sprintf "/* end-elaborated-proto:%s (init) */" fn_name) ]
            
      (* Meta function *)
      | Sac_fn_meta ->
          [ GText (sprintf "/* begin-elaborated-proto:%s (meta) */" fn_name) ;
            GVarDecl (fn.fn_fundec.svar, loc) ;
            GText (sprintf "/* end-elaborated-proto:%s (meta) */" fn_name) ]
            
(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Elaborate Function Definitions *)

let rec elaborate_definition (fn:sac_function) (loc:location) : global list =
  let fn_name = fn.fn_fundec.svar.vname in
  let fn_kind = (match fn.fn_kind with 
                   | Sac_fn_self _ -> "self-adjusting"
                   | Sac_fn_meta   -> "meta"
                   | Sac_fn_init _ -> "init") in
  let text_begin = GText (sprintf "/* begin-elaborated-def:%s (%s) */" fn_name fn_kind) in
  let elaborated_definition = match fn.fn_kind with
      
    (* Self-adjusting function. *)
    (* Elaborate the definition of a self-adjusting function -- this
       produces the elaborated function body as well as other
       boilerplate code we created for the function *)
    | Sac_fn_self closinfo -> begin  
        let desc_proto fn = elaborate_prototype fn locUnknown in        
        let desc_defin fn = elaborate_definition fn locUnknown in
        let descs_protos = (List.flatten (List.map desc_proto fn.fn_descs)) in
        let descs_defins = (List.flatten (List.map desc_defin fn.fn_descs)) in
        descs_protos @(
          (GCompTag (closinfo.cl_compinfo, loc))
          :: (GVarDecl (closinfo.cl_staticinfo, locUnknown))
          :: (GFun (fn.fn_fundec, loc))
          :: (GFun (closinfo.cl_aux_new, locUnknown))
          :: (GFun (closinfo.cl_aux_subscribe, locUnknown))
          :: (GFun (closinfo.cl_aux_unsubscribe, locUnknown))
          :: (GFun (closinfo.cl_aux_refresh, locUnknown))
          :: (GFun (closinfo.cl_aux_replace, locUnknown))
          :: (GFun (closinfo.cl_aux_equals, locUnknown))
          :: (GFun (closinfo.cl_aux_hash, locUnknown))
          :: (make_closure_staticinfo fn closinfo)
          :: descs_defins)
      end    
        
    (* Initialization function *)
    (* Elaborate the definitions required by each associated allocation *)
    | Sac_fn_init als ->
        let als = Sac_al_set.elements als in
        let elaborate_allocation al =
          [ GCompTag (al.al_blockinfo.bl_compinfo, loc);
            GVarDecl (al.al_blockinfo.bl_staticinfo, locUnknown);
            GFun (al.al_blockinfo.bl_aux_new, locUnknown);
            GFun (al.al_blockinfo.bl_aux_init, locUnknown);
            GFun (al.al_blockinfo.bl_aux_size, locUnknown);
            GFun (al.al_blockinfo.bl_aux_keyc, locUnknown);
            GFun (al.al_blockinfo.bl_aux_hash, locUnknown);
            GFun (al.al_blockinfo.bl_aux_equals, locUnknown);
            make_block_staticinfo al;
          ]
        in 
        (List.flatten (List.map elaborate_allocation als))        
          
    (* Meta function *)
    | Sac_fn_meta ->
        [ GFun(fn.fn_fundec, loc) ]
  in
  let text_end = GText (sprintf "/* end-elaborated-def:%s (%s) */" fn_name fn_kind) in
  
  [text_begin]
  @ (elaborate_prototype fn loc)
  @ (elaborated_definition)
  @ [text_end]
    
