(* SAC Program representations *)
open Cil
open Actk_util
open Actk_cfg
open Printf

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)  
(* [sac_closinfo] represents code and types for closures that we
   auto-generate for each self-adjusting function (aka, the
   "boilerplate" code associated with each self-adjusting
   function). *)
type sac_closinfo =
    { mutable cl_compinfo : compinfo ;
      mutable cl_formals : sac_formalarg list ;
      mutable cl_staticinfo : varinfo ;
      mutable cl_typedef : typ ;
      mutable cl_typeptr : typ ;
      
      (* Auxiliary functions that we auto-generate: *)
      mutable cl_aux_new : fundec ;
      mutable cl_aux_subscribe : fundec ;
      mutable cl_aux_unsubscribe : fundec ;
      mutable cl_aux_replace : fundec ;
      mutable cl_aux_refresh : fundec ;
      mutable cl_aux_equals : fundec ;
      mutable cl_aux_hash : fundec ;
    }
      
(* Represents formal arguments for self-adjusting functions -- these
   are the arguments that must be packed and unpacked from closures --
   therefore, a formal argument has a presence in both the source
   program (as actual formal arguments) as well as in the elaborated
   program (as closure fields packed in and later projected out to
   local variables). *)
and sac_formalarg =
    { 
      mutable fa_var  : varinfo ;   (* Local for fn.fn_fundec *)
      mutable fa_valv : varinfo ;   (* Formal for cl_aux_new *)
      mutable fa_modv : varinfo ;   (* Formal for cl_aux_new *)     
      mutable fa_valf : fieldinfo ; (* Field for cl_compinfo *)
      mutable fa_modf : fieldinfo ; (* Field for cl_compinfo *)
      mutable fa_hanf : fieldinfo ; (* Field for cl_compinfo *)
    }

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* [sac_alloc] and [sac_blockinfo] represent allocation sites and
   generated code for block allocations, respectively.  We create
   these for each representative self-adjusting block allocation.  The
   type of these is [sac_allocation].  An allocation is "equal" to
   another (in the sense that we can use the same boiler-plate code to
   support both these allocations) if the initialization function,
   requsted size, and the types of keys all match.  If two allocations
   are "equal" in this sense, then we assign them the same
   representative.

   For the time-being we insist that the requested size is a constant
   at compile-time (we don't have support yet for variable-sized
   allocation, e.g., arrays, etc.).
*)
type sac_allocation = 
    { mutable al_num : int ; (* a unique number *)
      mutable al_initsvar : varinfo ; (* the varinfo for the initialization function *)
      mutable al_sizeexp : exp ; (* the size of the allocation *)
      mutable al_keytypes : typ list ; (* types of keys used *)
      mutable al_blockinfo : sac_blockinfo ; (* auto-generated stuff *)
    }

and sac_blockinfo = 
    { mutable bl_compinfo : compinfo ;
      mutable bl_reqspace : offset ;
      mutable bl_formals : sac_formalkey list ;
      mutable bl_staticinfo : varinfo ;

      mutable bl_typedef : typ;
      mutable bl_typeptr : typ;
      
      (* Auxiliary functions that we auto-generate: *)
      mutable bl_aux_new : fundec ;
      mutable bl_aux_init : fundec ;
      mutable bl_aux_size : fundec ;
      mutable bl_aux_keyc : fundec ;
      mutable bl_aux_hash : fundec ;
      mutable bl_aux_equals : fundec ;
    }

and sac_formalkey = 
    { (* fk_aux_new: formal for [bl_aux_new] *)
      mutable fk_aux_new : varinfo ;       
      (* fk_aux_init: local for [bl_aux_init] *)
      mutable fk_aux_init : varinfo ; 
      mutable fk_offset : offset ;
    }

module Sac_allocation = struct
  type t = sac_allocation
  let compare al1 al2 =
    let compare_initsvar = compare al1.al_initsvar al2.al_initsvar in
    let compare_sizeexp = compare al1.al_sizeexp al2.al_sizeexp in
    if compare_initsvar <> 0 then compare_initsvar
    else if compare_sizeexp <> 0 then compare_sizeexp
    else
      let rec loop typs1 typs2 = 
        match (typs1, typs2) with
            ([], []) -> 0
          | ([], _) -> -1
          | (_, []) -> 1
          | (typ1::typs1, typ2::typs2) ->
              let compare_typ = compare typ1 typ2 in
              if compare_typ <> 0 then compare_typ
              else loop typs1 typs2
      in 
      (loop al1.al_keytypes al2.al_keytypes)
end

module Sac_al_set = Set.Make(Sac_allocation)
module Sac_al_map = Map.Make(Sac_allocation)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* [sac_function] represents all of the following: 
   (1) Meta functions (code that performs meta operations) 
   (2) Self-adjusting functions -- code that is traced 
   (3) Initialization functions -- code that initializes traced block allocations 
*)
type sac_function = 
    { 
      mutable fn_source : fundec option ; (* Source function *)
      mutable fn_kind : sac_function_kind ; (* Function kind *)

      (* Control-flow graph (CFG) -- initially corresponds to source
         function, but then is transformed/optimized, etc. *)
      mutable fn_cfg : sac_cfg ;   

      mutable fn_normal : fundec ; (* Normalized function *)
      mutable fn_fundec : fundec ; (* Elaborated function *)
      mutable fn_descs : sac_function list ; (* Descendents resulting from normalization *)
      mutable fn_preds : sac_function list ; (* Predecessors in static call-graph *)
      mutable fn_succs : sac_function list ; (* Successors in static call-graph *)      
    }

and sac_function_kind =     
  (* Meta functions *)
  | Sac_fn_meta      

  (* Self-adjusting functions *)
  | Sac_fn_self
      of sac_closinfo (* (static) closure information *)
        
  (* Initialization functions *)
  | Sac_fn_init 
      of Sac_al_set.t (* (static) allocation information *)

module Sac_function = struct
  type t = sac_function
  let name fn = fn.fn_fundec.svar.vname
  let compare_names fn1 fn2 = compare (name fn1) (name fn2)
  let preds fn = fn.fn_preds
  let compare fn1 fn2 = 
    let name_comparison = compare_names fn1 fn2 in
    if (not (fn1 == fn2)) && (name_comparison = 0)
    then raise (Error "functions with same name aren't physically equal")
    else name_comparison
end
  
module Sac_fn_set = Set.Make(Sac_function)
module Sac_fn_dom = Actk_dominator.Make(Sac_function)  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)

let dummy_compinfo : compinfo = 
  mkCompInfo true "@dummystruct" 
    (fun compinfo -> []) []

let dummy_var : varinfo =
  makeGlobalVar "@dummyvar" voidPtrType

let dummy_closinfo : sac_closinfo = {
  cl_compinfo = dummy_compinfo;
  cl_formals = [];
  cl_staticinfo = dummy_var;
  cl_typedef = voidPtrType;
  cl_typeptr = voidPtrType;
  cl_aux_new = dummyFunDec;
  cl_aux_subscribe = dummyFunDec;
  cl_aux_unsubscribe = dummyFunDec;
  cl_aux_replace = dummyFunDec;
  cl_aux_refresh = dummyFunDec;
  cl_aux_equals = dummyFunDec;
  cl_aux_hash = dummyFunDec;
}

let dummy_blockinfo : sac_blockinfo = {
  bl_compinfo = dummy_compinfo ;
  bl_reqspace = NoOffset;
  bl_formals = [];
  bl_staticinfo = dummy_var;
  bl_typedef = voidPtrType;
  bl_typeptr = voidPtrType;
  bl_aux_new = dummyFunDec;
  bl_aux_init = dummyFunDec;
  bl_aux_size = dummyFunDec;
  bl_aux_keyc = dummyFunDec;
  bl_aux_hash = dummyFunDec;
  bl_aux_equals = dummyFunDec;
}

let dummy_function kind : sac_function = { 
  fn_source = None ;
  fn_kind = kind;
  fn_cfg = dummy_cfg Sac_cfg_meta ;
  fn_normal = dummyFunDec;
  fn_fundec = dummyFunDec;
  fn_descs = [];
  fn_preds = [];
  fn_succs = [];
}

(* Copy a fundec so we can later side-effect the copy. *)
let fundec_shallow_copy (fundec:fundec) =
  {fundec with svar = fundec.svar}


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)

(* Stores all the functions we find and elaborate *)
let sac_functions 
    : Sac_fn_set.t ref
    = ref Sac_fn_set.empty

(* Functions keyed by their name *)
let sac_functions_by_var 
    : sac_function Varmap.t ref 
    = ref Varmap.empty

(* Maps allocations to representative allocations *)
let sac_allocations
    : sac_allocation Sac_al_map.t ref 
    = ref Sac_al_map.empty
  
(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)

(* Add a function to the program. *)
let add_function (fn:sac_function) = begin
  sac_functions := Sac_fn_set.add fn !sac_functions ;
  sac_functions_by_var := (Varmap.add fn.fn_fundec.svar fn !sac_functions_by_var);
end

(* Make call edge: "fn1 --> fn2" *)
let add_edge (fn1:sac_function) (fn2:sac_function) = 
  begin
    fn1.fn_succs <- fn2 :: fn1.fn_succs ;
    fn2.fn_preds <- fn1 :: fn2.fn_preds ;
  end

(* check if the given varinfo corresponds to a sac_function *)
let check_function (varinfo:varinfo) =
  (Varmap.mem varinfo !sac_functions_by_var)
  
(* Lookup a function by it's varinfo *)
let lookup_function (varinfo:varinfo) = 
  try (Varmap.find varinfo !sac_functions_by_var) 
  with Not_found -> 
    raise (Bug (sprintf "lookup %s" varinfo.vname))

(* Given a varinfo for an initialization function, get all the
   representative allocations that use it. *)
let lookup_init_function (initsvar:varinfo) 
    : (sac_function * Sac_al_set.t) 
    =
  let init_fn = lookup_function initsvar in
  let als = match init_fn.fn_kind with 
      Sac_fn_init als -> als | _ -> raise Hell in  
  (init_fn, als)

let lookup_self_function (selfsvar:varinfo)
    : (sac_function * sac_closinfo)
    =
  let self_fn = lookup_function selfsvar in
  let closinfo = match self_fn.fn_kind with
      Sac_fn_self closinfo -> closinfo | _ -> raise Hell in
  (self_fn, closinfo)

let lookup_source_fundec (varinfo:varinfo) =
  let fn = lookup_function varinfo in
  match fn.fn_source with 
      Some fundec -> fundec 
    | None -> raise Hell

(* Add a function we find in the source program. *)
let add_source_function (fundec:fundec) (kind:sac_function_kind) = 
  let cfg_kind = match kind with
      Sac_fn_init _ -> Sac_cfg_init
    | Sac_fn_meta   -> Sac_cfg_meta
    | Sac_fn_self _ -> Sac_cfg_self
  in
  let cfg = cfg_of_fundec fundec cfg_kind in
  let fn = { fn_source = Some fundec;
             fn_kind = kind;
             fn_cfg = cfg;
             fn_normal = fundec_shallow_copy fundec ; 
             fn_fundec = fundec_shallow_copy fundec ;
             fn_descs = [];
             fn_preds = [];
             fn_succs = [];
           }
  in (add_function fn) ; fn

(* Add a self-adjusting function from source. *)
let add_source_self_function (fundec:fundec) : sac_function =
  add_source_function (fundec) (Sac_fn_self dummy_closinfo)  

(* Add an init function from source. *)
let add_source_init_function (fundec:fundec) : sac_function =
  add_source_function (fundec) (Sac_fn_init Sac_al_set.empty)

(* Add a meta function from source. *)
let add_source_meta_function (fundec:fundec) : sac_function =
  add_source_function (fundec) (Sac_fn_meta)

(* Add a normal function we generate. *)
let add_normal_function (orig_fn:sac_function) (fundec:fundec) (cfg:sac_cfg) =
  let fn = { fn_source = None;
             fn_cfg = cfg;
             fn_kind = Sac_fn_self dummy_closinfo;
             fn_normal = fundec ;
             fn_fundec = fundec_shallow_copy fundec ;
             fn_descs = [];
             fn_preds = [];
             fn_succs = [];
           } in
  let _ = orig_fn.fn_descs <- fn::orig_fn.fn_descs in
  (add_function fn) ; fn

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
    

(* A canonical "basename" for generated code and types associated with
   the allocation/blockinfo. This name is taken from the name of the
   initialization function and made unique if necessary with an
   additional unique number.  Also, if the initialization function
   ends with "_init" (as many often do) this will be torn-off for the
   basename. *)
let allocation_basename (al : sac_allocation) =
  let init_fun_name = al.al_initsvar.vname in
  let regexp = Str.regexp "\\(.+\\)\\(_init\\)$" in
  let prefix = Str.global_replace regexp "\\1" init_fun_name in
  let suffix = 
    let default = sprintf "_%d" al.al_num in try 
      let (_, als) = lookup_init_function al.al_initsvar in
      if (Sac_al_set.cardinal als) > 1 then default else ""
    with Not_found -> default
  in
  (sprintf "%s_block%s" prefix suffix)


(* Resolve an allocation to a representative instance -- if a
   representative doesn't exist, then the given allocation becomes a
   representative.  In this case we also add this allocation to the
   various mappings and sets we track. *)
let resolve_allocation =
  let make_resolve _ =
    let next_num = ref 0 in
    (let resolve (al : sac_allocation) : sac_allocation =
       let debug = if false then out else no_out in
       if Sac_al_map.mem al !sac_allocations then begin
         let al = Sac_al_map.find al !sac_allocations in
         debug "resolved to an existing allocation: %s" (allocation_basename al) ; 
         (al)
       end else begin
         al.al_num <- !next_num ;
         incr next_num ;
         sac_allocations := (Sac_al_map.add al al !sac_allocations) ;
         let (init_fn, als) = lookup_init_function al.al_initsvar in
         init_fn.fn_kind <- Sac_fn_init (Sac_al_set.add al als) ;
         debug "resolved to a new allocation: %s" (allocation_basename al) ;
         al
       end
     in 
     resolve)
  in
  make_resolve ()

(* Resolve a [Actk_cfg.Sac_alloc] instruction to a representitive
   allocation --- this is just a convience function for [resolve]. *)
let allocation_of_instr 
    (size_exp:exp) 
    (initsvar:varinfo) 
    (key_exps:exp list) 
    : sac_allocation 
    =
  let al = {al_num = -1;
            al_initsvar = initsvar;
            al_sizeexp = size_exp;
            al_keytypes = List.map typeOf key_exps;
            al_blockinfo = dummy_blockinfo ;
           }
  in
  (resolve_allocation al)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let print_function_subgraph (out:out_channel) (fn:sac_function) =
  let name = fn.fn_fundec.svar.vname in
  let arg_strings = List.fold_left 
    (fun str argvar -> 
       if str <> "" then str^", "^argvar.vname else argvar.vname) 
    "" fn.fn_fundec.sformals
  in
  let bbs_strings = Sac_bb_set.fold 
    (fun bb bbs -> (dotnode_of_basic_block bb)::bbs)
    fn.fn_cfg.cfg_bbs [] 
  in    
  begin
    fprintf out "subgraph cluster_%s {\n" name ;
    fprintf out "labeljust=\"l\";\n" ;
    
    (* A node for the function name with an edge to the initial block. *)
    fprintf out "%s [shape=plaintext, label=\"%s(%s)\"];\n" name name arg_strings ;
    fprintf out "%s -> block_%d [weight=10];\n" name fn.fn_cfg.cfg_bb0.bb_id ;
    
    (* Print the blocks and local edges *)
    List.iter (fun bb_string -> fprintf out "%s\n" bb_string) bbs_strings ;
    fprintf out "}\n" ;
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let print_function_graph (name:string) (fns:sac_function list) = 
  begin
    let out = open_out (name ^ ".cfg.dot") in
    fprintf out "digraph %s {\nsize=\"6,8\"; center=\"true\"; compound=\"true\";\n" name ;
    List.iter (fun fn -> print_function_subgraph out fn) fns ;
    
    (* Print the tailcall edges *)
    List.iter (fun fn ->
                 let tailcall_strings = Sac_bb_set.fold
                   (fun bb strs -> (dotedges_of_tailcalls bb bb.bb_term)::strs)                   
                   fn.fn_cfg.cfg_bbs [] in
                 (List.iter (fprintf out "%s\n") tailcall_strings)) fns ;

    fprintf out "}\n" ;
    close_out out ;
  end

