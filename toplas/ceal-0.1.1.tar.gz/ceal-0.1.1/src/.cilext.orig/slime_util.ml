open Cil
open Trace
open Printf

module P = Pretty
module IH = Inthash
module H = Hashtbl
module E = Errormsg
exception Hell
exception Error of string

let actk_print_dot = ref false 
  
(* Print some debugging output. *)
let out (fmt : ('a,unit,P.doc) format) : 'a = 
  let f d = 
    ignore (P.eprintf "%t: actk: %a@!" d_thisloc P.insert d);
    P.nil
  in
  P.gprintf f fmt

(* Don't print anything. *)
let no_out (fmt : ('a,unit,P.doc) format) : 'a = 
  let f d = P.nil in
  P.gprintf f fmt

(* Keep track of the current function, provide a get/set function *)
let current_fundec = ref None
let current_fundec fundec_op = 
  begin match fundec_op with Some fundec -> (current_fundec := Some fundec) | None -> () end ;
  begin match !current_fundec with Some fundec -> fundec | None -> raise Hell end

(* Keep track of the current state-variable, provide a get/set function *)
let current_stvar = ref None
let current_stvar stvar_op = 
  begin match stvar_op with Some stvar -> (current_stvar := Some stvar) | None -> () end ;
  begin match !current_stvar with Some stvar -> stvar | None -> raise Hell end
    
(* make an expression for the current stvar, or error if none. *)
let current_stexp _ = 
  try (Lval(Var(current_stvar None), NoOffset)) with
      Hell -> error "need a current-state here." ; zero

(* Make a new local variable. *)
let maketempvar ?(name="tmpa___") (typ:typ) : varinfo = 
  (makeTempVar ~name (current_fundec None) typ)

(* Map for Cil statements *)
module Stmtmap = Map.Make
  (struct 
     type t = stmt
     let compare stmt1 stmt2 = compare stmt1 stmt2
   end)

(* Variables -- for Sets and Maps. *)
module Var = struct 
  type t = varinfo
  let compare v1 v2 = compare v1 v2
end

(* Variable Sets and Maps *)
module Varset = Set.Make(Var)
module Varmap = Map.Make(Var)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Collect all the variables that are used. *)
class collect_used_vars () = object(self)
  inherit nopCilVisitor
  val mutable vars = Varset.empty
  method get_vars () = vars
  method vvrbl (varinfo:varinfo) : varinfo visitAction = begin
    vars <- Varset.add varinfo vars ;
    DoChildren
  end
end

(* Return a set of variables that are used in the given expression *)
let exp_vars (exp:exp) = 
  let collector = (new collect_used_vars ()) in
  let _ = visitCilExpr (collector :> cilVisitor) exp in
  collector#get_vars ()

(* Same as [exp_vars] except lifted to optional expressions *)
let expop_vars (expop:exp option) =
  match expop with 
      None -> Varset.empty
    | Some exp -> exp_vars exp

(* Save as [exp_vars] except lifted to lists of expressions *)
let exps_vars (exps: exp list) =
  List.fold_left 
    (fun vars exp -> Varset.union vars (exp_vars exp)) 
    Varset.empty exps

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Map_set -- Mappings from one ordered type to sets of another
 * ordered type -- offers useful operations [find, set, add, combine,
 * to_string] that are all applicative (purely functional). *)
module Map_set (M:Map.S) (S:Set.S) = 
struct 
  module M = M
  module S = S
  type t = S.t M.t
      
  let empty = M.empty
    
  let find x m = 
    if M.mem x m then M.find x m else S.empty
      
  let set x y m = 
    M.add x (S.singleton y) m
      
  let add x y m =
    let ys = find x m in
    let ys = S.add y ys in
    M.add x ys m

  let remove x y m =
    let ys = find x m in
    let ys = S.remove y ys in
    M.add x ys m
      
  let equal m1 m2 =
    M.equal (S.equal) m1 m2

  let combine m1 m2 =
    M.fold (fun x ys1 m -> 
              let ys2 = find x m2 in
              let ys = S.union ys1 ys2 in
              (M.add x ys m)) m1 m2

  let to_string string_of_x string_of_y m =
    "{"^(M.fold       
           (fun x ys str -> 
              let string_of_ys ys = 
                (S.fold 
                   (fun y str -> 
                      let y_str = string_of_y y in
                      (if str <> "" then str^", "^y_str else y_str)) ys "")
              in
              let str' = (sprintf "%s->{%s}" (string_of_x x) (string_of_ys ys)) in
              if str <> "" then str^", "^str' else str')
           m "")^"}"
end
