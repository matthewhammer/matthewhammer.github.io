open Cil
open Trace
open Printf

module P = Pretty
module IH = Inthash
module H = Hashtbl
module E = Errormsg
exception Hell
exception Error of string

open Actk_util
open Actk_attrs
open Actk_api
open Actk_program
open Actk_normalize
open Actk_allocation
open Actk_elaborate

let debug = if false then out else no_out

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
class read_program () = object(self)
  inherit nopCilVisitor
  method vfunc (fundec:fundec) : fundec visitAction = begin
    if hasAttribute "actk_function" fundec.svar.vattr then begin
      debug "self-function: %s" fundec.svar.vname ;
      normalize (add_source_self_function fundec) ;
      SkipChildren
    end
    else if hasAttribute "actk_initializer" fundec.svar.vattr then begin
      debug "init-function: %s" fundec.svar.vname ;
      let fn = (add_source_init_function fundec) in
      check_normal fn ;
      SkipChildren
    end
    else if fundec_has_uses fundec then begin
      debug "meta-function: %s" fundec.svar.vname ;
      let fn = (add_source_meta_function fundec ) in
      check_normal fn ;
      SkipChildren
    end
    else
      SkipChildren
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
class write_program () = object(self)
  inherit nopCilVisitor
  method vglob (global:global) : global list visitAction = begin
    match global with
      | GVarDecl(varinfo, loc) ->
          if check_function varinfo then
            let fn = lookup_function varinfo in
            ChangeTo (elaborate_prototype fn loc)
          else
            SkipChildren              
      
      | GFun(fundec, loc) -> 
          if check_function fundec.svar then 
            let fn = lookup_function fundec.svar in
            ChangeTo (elaborate_definition fn loc) 
          else
            SkipChildren
            
      | _ -> DoChildren
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* The "main" function of this extension. *)
let go file = begin
  debug "actk transformation: starting:" ;
  visitCilFile (new normalize_attributes () :> cilVisitor) file ;
  visitCilFile (new api_setup () :> cilVisitor) file ;
  Cfg.computeFileCFG file ;
  visitCilFile (new read_program () :> cilVisitor) file ;
  (* TODO -- Do optimizations *)
  elaborate_program () ;
  visitCilFile (new write_program () :> cilVisitor) file ;
  visitCilFile (new stripper () :> cilVisitor) file ;
  debug "actk transformation: done." ;
  ()
end

let do_actk = ref false

let feature : featureDescr =
  {
    fd_name = "actk";
    fd_enabled = do_actk;
    fd_description = "automagic ACTK code instrumentation";
    fd_extraopt = [];
    fd_doit = (function (f:file) -> go f);
    fd_post_check = true;
  }
