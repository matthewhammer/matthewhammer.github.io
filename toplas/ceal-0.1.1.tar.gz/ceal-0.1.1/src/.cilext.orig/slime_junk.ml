
let instr_is_read instr =
  match instr with
      Call (Some (Var lvar, NoOffset), Lval(Var funvar, NoOffset), [exp], _)
        when funvar == api.apifn_read -> Some (lvar, exp)
    | _ -> None

let stmt_is_isolated_read stmt =
  match stmt.skind with
      Instr([i]) -> instr_is_read i
    | _ -> None

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* This totally ugly code finds all the READs ---initially
   instructions in instruction lists--- and isolates them in their own
   statements. *)
class isolate_reads () = object(self)
  inherit nopCilVisitor    
  method vblock (b:block) : block visitAction = begin    
    let isolate_reads (ss:stmt list) : stmt list = 
      (* Loop over statements *)
      let rec sloop (ss:stmt list) : stmt list =
        match ss with [] -> []
          | s::ss -> begin match s.skind with
                Instr is -> (iloop is []) @ (sloop ss)
              | _ -> s :: (sloop ss)
            end
              
      (* Loop over instructions *)
      and iloop (is:instr list) (prev_instrs:instr list) : stmt list =        
        let add_previous_instrs ss = 
          if prev_instrs = [] then ss else            
            (mkStmt (Instr (List.rev prev_instrs))) :: ss
        in
        match is with
            [] -> add_previous_instrs []
          | i::is -> 
              begin match instr_is_read i with
                  Some (lvar, _) ->
                    out "found read into %s" lvar.vname ;
                    add_previous_instrs ((mkStmt (Instr [i])) :: (iloop is []))
                
                | None -> iloop is (i::prev_instrs)
              end
      in
      (sloop ss)
    in
    ChangeDoChildrenPost 
      ((mkBlock (isolate_reads b.bstmts)), fun x -> x)
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Verify that isolate_reads worked correctly. *)
class verify_read_isolation () = object(self)
  inherit nopCilVisitor
  method vstmt (s:stmt) : stmt visitAction = begin
    match stmt_is_isolated_read s with
        Some (lvar, _) -> out "found isolated read into %s" lvar.vname ; SkipChildren
      | None -> DoChildren
  end    
  method vinst (i:instr) : instr list visitAction = begin
    match instr_is_read i with
        Some (lvar, _) -> error "found non-isolated read into %s" lvar.vname ; DoChildren
      | None -> DoChildren
  end
end


(*
module Var = struct 
  type t = Cil.varinfo
  let compare v1 v2 = v1.vid - v2.vid
end

module VS = Set.Make(Var)
module VM = Map.Make(Var)

type readinfo = { 
  mutable r_stmt : stmt ;
  mutable r_source : exp ;
  mutable r_vars : VS.t ;
  mutable r_isstable : bool 
}
    
class classify_reads () = object(self)
  inherit nopCilVisitor
  val mutable vars : readinfo VM.t = VM.empty
    
  method add_readinfo var ri =
    vars <- VM.add var ri vars

  method get_readinfo var =
    VM.find var vars
      
  method set_dirty var =
    let ri = get_readinfo var in
    ri.r_isstable <- false

  method examine_exp exp =
    let fv = freevars_in_exp exp in
    let inter = VS.inter fv readvars in
    VS.iter (fun var -> set_dirty var) inter

  method vinst (i:instr) : instr list visitAction = begin
    match i with
        Set ((Var v1, NoOffset), Lval(Var v2, NoOffset), _) ->
          (if VM.mem v2 vars then
             let ri = get_readinfo v2 in
             vars <- VM.add v1 ri vars) ; 
          SkipChildren

      | Set (_, exp, _) -> 
          examine_exp exp; 
          SkipChildren
      
      | Call (_, Lval(Var fvar, NoOffset), args, _) ->
          if hasAttribute "actk_function" fvar.vattrs then ()
          else List.iter examine_exp args ;
          SkipChildren
            
      | If (exp, _, _, _) ->
          examine_exp exp;
          SkipChildren            
            
  end

  method vstmt (s:stmt) : stmt visitAction = begin
    match stmt_is_isolated_read s with
        Some (lvar, source) -> 
          let ri = { r_stmt = s;
                     r_source = source; 
                     r_vars = VS.singleton lvar;
                     r_isstable = true;
                   }
          in
          self#add_readinfo lvar ri ;
          SkipChildren

      | None -> DoChildren          
  end
end
*)
