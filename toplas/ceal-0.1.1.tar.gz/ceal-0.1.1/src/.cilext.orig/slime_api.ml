open Cil
open Trace
open Printf

open Actk_util

type api = { 
  (* API -- Surface Syntax *)
  mutable apity_modref: typ;
  mutable apifn_alloc: varinfo;
  mutable apifn_modref: varinfo;  
  mutable apifn_write: varinfo;
  mutable apifn_read: varinfo;

  (* API -- Elaborated Syntax *)
  mutable apity_context: typ;
  mutable apity_closure: typ;
  mutable apity_closure_staticinfo: typ;
  mutable apity_block: typ;
  mutable apity_block_staticinfo: typ;
  
  mutable apifn_context_push: varinfo;
  mutable apifn_context_restore: varinfo;
  mutable apifn_closure_call: varinfo;
  mutable apifn_closure_new: varinfo;
  mutable apifn_block_new: varinfo;
  mutable apifn_block_alloc: varinfo;
  mutable apifn_modref_init: varinfo;
  mutable apifn_modref_write: varinfo;
  mutable apifn_modref_deref: varinfo;
  mutable apifn_modref_addread: varinfo;
  mutable apifn_modref_remread: varinfo;  
  mutable apifn_hashword: varinfo;
}

let api : api = {
  (* Surface Syntax *)
  apity_modref = voidPtrType ;
  apifn_alloc = dummyFunDec.svar ;
  apifn_modref = dummyFunDec.svar ;
  apifn_read = dummyFunDec.svar ;
  apifn_write = dummyFunDec.svar ;

  (* Elaborated Syntax *)
  apity_context = voidPtrType ;
  apity_closure = voidPtrType ;  
  apity_closure_staticinfo = voidPtrType ;
  apity_block = voidPtrType;
  apity_block_staticinfo = voidPtrType ;
  
  apifn_context_push = dummyFunDec.svar ;
  apifn_context_restore = dummyFunDec.svar ;
  apifn_closure_call = dummyFunDec.svar ;
  apifn_closure_new = dummyFunDec.svar ;    
  apifn_block_new = dummyFunDec.svar ;
  apifn_block_alloc = dummyFunDec.svar ;
  apifn_modref_init = dummyFunDec.svar ;
  apifn_modref_write = dummyFunDec.svar ;
  apifn_modref_deref = dummyFunDec.svar ;
  apifn_modref_addread = dummyFunDec.svar ;
  apifn_modref_remread = dummyFunDec.svar ;
  apifn_hashword = dummyFunDec.svar ;
}

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
class api_setup () = object(self)
  inherit nopCilVisitor        
  method vglob (g:global) : global list visitAction = begin
    match g with 
      | GVarDecl (varinfo, loc) ->
          (* -- record API prototypes for later *)
          begin match varinfo.vname with
            (* Surface syntax *)
            | "alloc" -> (api.apifn_alloc <- varinfo; SkipChildren)
            | "modref" -> (api.apifn_modref <- varinfo; SkipChildren)
            | "write" -> (api.apifn_write <- varinfo ; SkipChildren)
            | "read" -> (api.apifn_read <- varinfo; SkipChildren)
                
            (* Elaborated Syntax *)
            | "context_push" -> (api.apifn_context_push <- varinfo; SkipChildren)
            | "context_restore" -> (api.apifn_context_restore <- varinfo; SkipChildren)
            | "closure_new" -> (api.apifn_closure_new <- varinfo ; SkipChildren)
            | "closure_call" -> (api.apifn_closure_call <- varinfo ; SkipChildren)
            | "block_new" -> (api.apifn_block_new <- varinfo ; SkipChildren)
            | "block_alloc" -> (api.apifn_block_alloc <- varinfo ; SkipChildren)
            | "modref_init" -> (api.apifn_modref_init <- varinfo ; SkipChildren)
            | "modref_write" -> (api.apifn_modref_write <- varinfo ; SkipChildren)
            | "modref_deref" -> (api.apifn_modref_deref <- varinfo ; SkipChildren)
            | "modref_addread" -> (api.apifn_modref_addread <- varinfo ; SkipChildren)
            | "modref_remread" -> (api.apifn_modref_remread <- varinfo ; SkipChildren)
            | "hashword" -> (api.apifn_hashword <- varinfo; SkipChildren)
            | _ -> DoChildren
          end
            
      | GType (typeinfo, loc) ->
          (* -- record API typedefs for later *)
          let typ = TNamed(typeinfo, []) in
          begin match typeinfo.tname with
            | "context_t" -> (api.apity_context <- typ; SkipChildren)
            | "closure_t" -> (api.apity_closure <- typ; SkipChildren)
            | "modref_t" -> (api.apity_modref <- typ; SkipChildren)
            | "closure_staticinfo_t" -> (api.apity_closure_staticinfo <- typ; SkipChildren)
            | "block_t" -> (api.apity_block <- typ; SkipChildren)
            | "block_staticinfo_t" -> (api.apity_block_staticinfo <- typ; SkipChildren)
            | _ -> DoChildren
          end
      
      | _ -> DoChildren
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Detect the use of the surface API. *)
class api_detection () = object(self)
  inherit nopCilVisitor        
  val mutable result = false    
  val surface_api = [api.apifn_alloc;
                     api.apifn_modref;
                     api.apifn_write;
                     api.apifn_read;]  
  method get_result () = result
  method vvrbl (var:varinfo) : varinfo visitAction = begin
    if List.mem var surface_api then
      (result <- true; SkipChildren)
    else
      DoChildren
  end
end

(* Returns true if the given function makes any calls to the surface
   API, false otherwise. *)
let fundec_has_uses (fundec:fundec) : bool =
  let detector = (new api_detection ()) in
  let _ = visitCilBlock (detector :> cilVisitor) fundec.sbody in
  detector#get_result ()
