open Cil
open Trace
open Printf

open Actk_util
open Actk_api

(* Closure Information. *)
type closinfo = 
    { mutable c_varinfo : varinfo;
      mutable c_fundec : fundec;
      mutable c_staticinfo : varinfo;
      mutable c_compinfo : compinfo;
      mutable c_args : arginfo list;
      mutable c_typdef : typ;
      mutable c_typptr : typ;

      (* Auxiliary functions that we auto-generate: *)
      mutable c_aux_new : varinfo;
      mutable c_aux_subscribe : varinfo;
      mutable c_aux_unsubscribe : varinfo;
      mutable c_aux_replace : varinfo;
      mutable c_aux_refresh : varinfo;
      mutable c_aux_equals : varinfo;
      mutable c_aux_hash : varinfo;
    }

and arginfo = { 
  a_idx : int ;
  a_type : typ ;
  a_name : string ;
  a_valfield : fieldinfo ;
  a_modfield : fieldinfo ;
  a_hanfield : fieldinfo 
}
  

(* Construct a hashtbl for all the closinfos we need -- keys are the
   names of the original functions, e.g., (H.hash "map") *)
let closinfos : (string, closinfo) H.t = H.create 49

(* A triple used to represent the [st] formal introduced everywhere *)
let stvar_formal _ = ("st", TPtr(api.apity_state, []), [Attr("actk_state", [])])

(* Make a [st] formal parameter for a specific function *)
let make_stvar_formal (fundec:fundec) : varinfo = 
  let (name, typ, attr) = stvar_formal () in
  let vi = makeFormalVar fundec ~where:"^" name typ in
  begin vi.vattr <- attr; vi end

(* -- Get the formals out of the type *)
let formals_from_type typ = match typ with 
    TFun(_, Some formals, false, _) -> formals
  | _ -> raise Hell


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Transform a self-adjusting function's prototype:
   -- Change a self-adjusting function's prototype, specifically, remove the formals.
   -- Make some auxiliary function prototypes (e.g., [foo]_closure_new)
   -- Make some auxiliary types (e.g., [foo]_closure_t)
   -- Most of the auto-generated auxiliaries will be generated later
      when we encounter the fundec for the function.
*)
let transform_prototype (vi : varinfo) (loc : location) =    
  
  (* -- Make: struct [foo]_closure_s *)
  (* -- Make: typedef struct [foo]_closure_s [foo]_closure_t *)  

  let formals = formals_from_type vi.vtype in
  
  let compinfo = 
    let mkfields _ = 
      let fields_for_formal (name,typ,attr) =
        [(name^"_val", typ, None, attr, locUnknown);
         (name^"_mod", TPtr(api.apity_modref, []), None, attr, locUnknown);
         (name^"_han", voidPtrType, None, attr, locUnknown)]
      in    
      let fields = List.flatten (List.map fields_for_formal formals) in
      ("closure", api.apity_closure, None, [], locUnknown) :: fields
    in  
    mkCompInfo true (vi.vname^"_closure_s") mkfields [] 
  in

  let args =
    let rec loop idx fields formals = match (fields, formals) with
        (fval::fmod::fhan::rest_fields, formal::rest_formals) -> 
          let (name, typ, attr) = formal in
          let arginfo = {a_type = typ; 
                         a_name = name; 
                         a_idx = idx;
                         a_valfield = fval;
                         a_modfield = fmod;
                         a_hanfield = fhan;} in
          arginfo :: (loop (idx+1) rest_fields rest_formals)
      | ([], []) -> []
      | _ -> invalid_arg "arg info loop"
    in loop 0 (List.tl compinfo.cfields) formals
  in

  let typeinfo = {tname=vi.vname^"_closure_t";
                  ttype=TComp(compinfo,[]);
                  treferenced=true;} in  
  let typdef   = TNamed(typeinfo, []) in
  let typptr   = TPtr(typdef, []) in

  (* -- Redefine prototype [foo]: void [foo](state_t* st) -- *)
  let redefine_proto _ = match vi.vtype with
      TFun(typ, _, false, attr) -> 
        out "redefining: %s" vi.vname ;
        vi.vtype <- TFun(typ, Some [stvar_formal ()], false, attr) ;
        out "redefining: %s: done." vi.vname ;
    | _ -> raise Hell
  in
  let _ = redefine_proto () in
  
  (* -- Make auxiliary: [foo]_closure_t* [foo]_closure_new(...) -- *)
  let aux_new_name = vi.vname ^ "_closure_new" in
  let readmask_formal = ("readmask", uintType, []) in
  let aux_new_formals = Some ((stvar_formal ())::((readmask_formal))::formals) in
  let aux_new_type = TFun(typptr, aux_new_formals, false, []) in
  let aux_new = makeGlobalVar aux_new_name aux_new_type in   
  
  (* -- Make structure for static information *)
  let staticinfo = makeGlobalVar (vi.vname^"_closure_staticinfo") 
    api.apity_closure_staticinfo in
  (*let _ = staticinfo.vattr <- addAttribute (Attr ("static",_)) staticinfo.vattr in*)

  begin    
    (* -- Add new closinfos entry *)
    H.add closinfos vi.vname 
      { c_varinfo = vi ;
        c_fundec = dummyFunDec; 
        c_compinfo = compinfo;
        c_staticinfo = staticinfo;
        c_args = args;
        c_typdef = typdef;
        c_typptr = typptr;         
        c_aux_new = aux_new;
        c_aux_subscribe = dummyFunDec.svar;
        c_aux_unsubscribe = dummyFunDec.svar;
        c_aux_replace = dummyFunDec.svar;
        c_aux_refresh = dummyFunDec.svar;
        c_aux_equals = dummyFunDec.svar;
        c_aux_hash = dummyFunDec.svar;
      };
    
    (* -- Return the globals we made/modified. *)
    [ (* Change-to globals: *)
      (* GVarDecl (vi, loc) ;*)
      GType (typeinfo, locUnknown) ;
      GVarDecl (aux_new, locUnknown) ;
    ]
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_new (c : closinfo) (old_formals : varinfo list) = begin
  let fundec = make_fundec c.c_aux_new in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let readmask = makeFormalVar fundec "readmask" uintType in
  let formals = 
    let new_formal old_formal = 
      makeFormalVar fundec old_formal.vname old_formal.vtype in
    (List.map new_formal old_formals ) in
  
  let tmp_closure = maketempvar ~name:"closure" c.c_typptr in
  
  let bindclosure_stmt = let i = 
    (Call (Some (Var tmp_closure, NoOffset), 
           Lval (Var api.apifn_closure_new, NoOffset), 
           [Lval (Var stvar, NoOffset); 
            AddrOf (Var c.c_staticinfo, NoOffset); 
           ], locUnknown)) in (mkStmt (Instr [i])) in
  
  let return_stmt = 
    mkStmt (Return (Some(Lval (Var tmp_closure, NoOffset)), locUnknown)) in
    
  let init_stmts =
    let handle_arg (formal, arginfo) = 
      Formatcil.cStmts
        "if (readmask & 1<< %e:idx) {
           void* val = deref(st, (%t:modref_ptr_t) formal);
           (*closure) %o:valfield = (%t:arg_t) val;
           (*closure) %o:modfield = (%t:modref_ptr_t) formal;
           (*closure) %o:hanfield = (void*) 0;
        } else {
           (*closure) %o:valfield = formal;
           (*closure) %o:modfield = (void*) 0;
           (*closure) %o:hanfield = (void*) 0;
        }"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("st", Fv stvar);
          ("closure", Fv tmp_closure);
          ("readmask", Fv readmask);
          ("idx", Fe (integer arginfo.a_idx));
          ("valfield", Fo (Field (arginfo.a_valfield, NoOffset)));
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
          ("modref_ptr_t", Ft (TPtr(api.apity_modref,[])));
          ("arg_t", Ft arginfo.a_type);
          ("formal", Fv formal);
          ("deref", Fv api.apifn_modref_deref);
        ]
    in  
    List.flatten (List.map handle_arg (List.combine old_formals c.c_args))
  in
  fundec.sbody <- mkBlock ([bindclosure_stmt] @ init_stmts @ [return_stmt]);  
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_subscribe (c : closinfo) = begin
  let name = c.c_varinfo.vname ^ "_closure_subscribe" in
  let typ = TFun(voidType, Some [stvar_formal (); ("closure", c.c_typptr, [])], false, []) in
  let _ = c.c_aux_subscribe <- makeGlobalVar name typ in
  let fundec = make_fundec c.c_aux_subscribe in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let clvar = makeFormalVar fundec ~where:"$" "closure" c.c_typptr in
  let stmts =
    let handle_arg arginfo = 
      Formatcil.cStmts
        "if ((*closure) %o:modfield)
           (*closure) %o:hanfield = addread(st, (*closure) %o:modfield, (%t:closure_t) closure);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("st", Fv stvar);
          ("closure", Fv clvar);
          ("closure_t", Ft (TPtr(api.apity_closure, [])) );
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
          ("addread", Fv api.apifn_modref_addread);
        ]
    in  
    List.flatten (List.map handle_arg c.c_args)
  in
  fundec.sbody <- mkBlock (stmts);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_unsubscribe (c : closinfo) = begin
  let name = c.c_varinfo.vname ^ "_closure_unsubscribe" in
  let typ = TFun(voidType, Some [stvar_formal (); ("closure", c.c_typptr, [])], false, []) in
  let _ = c.c_aux_unsubscribe <- makeGlobalVar name typ in
  let fundec = make_fundec c.c_aux_unsubscribe in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let clvar = makeFormalVar fundec ~where:"$" "closure" c.c_typptr in
  let stmts =
    let handle_arg arginfo = 
      Formatcil.cStmts
        "if ((*closure) %o:modfield)
           remread(st, (*closure) %o:modfield, (*closure) %o:hanfield, closure);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("st", Fv stvar);
          ("closure", Fv clvar);
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
          ("remread", Fv api.apifn_modref_remread);
        ]
    in  
    List.flatten (List.map handle_arg c.c_args)
  in
  fundec.sbody <- mkBlock (stmts);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_refresh (c : closinfo) = begin
  let name = c.c_varinfo.vname ^ "_closure_refresh" in
  let typ = TFun(voidType, Some [stvar_formal (); ("closure", c.c_typptr, [])], false, []) in
  let _ = c.c_aux_refresh <- makeGlobalVar name typ in
  let fundec = make_fundec c.c_aux_refresh in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let clvar = makeFormalVar fundec ~where:"$" "closure" c.c_typptr in
    
  let stmts =
    let handle_arg arginfo = 
      Formatcil.cStmt
        "if ((*closure) %o:modfield) 
           (*closure) %o:valfield = deref(st, (*closure) %o:modfield);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("st", Fv stvar);
          ("closure", Fv clvar);
          ("valfield", Fo (Field (arginfo.a_valfield, NoOffset)));
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
          ("deref", Fv api.apifn_modref_deref);
        ]
    in  
    (List.map handle_arg c.c_args)
  in
  fundec.sbody <- mkBlock (stmts);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_replace (c : closinfo) = begin
  let name = c.c_varinfo.vname ^ "_closure_replace" in
  let typ = TFun(voidType, Some 
                   [stvar_formal (); 
                    ("closure_old", c.c_typptr, []);
                    ("closure_new", c.c_typptr, [])
                   ], false, []) in
  let _ = c.c_aux_replace <- makeGlobalVar name typ in
  let fundec = make_fundec c.c_aux_replace in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let clvar_old = makeFormalVar fundec ~where:"$" "closure_old" c.c_typptr in
  let clvar_new = makeFormalVar fundec ~where:"$" "closure_new" c.c_typptr in
  
  let unsubscribe_stmt = let i = 
    (Call (None, Lval (Var c.c_aux_unsubscribe, NoOffset), 
           [Lval (Var stvar, NoOffset); 
            Lval (Var clvar_old, NoOffset);], locUnknown)) in (mkStmt (Instr [i])) in

  let subscribe_stmt = let i = 
    (Call (None, Lval (Var c.c_aux_subscribe, NoOffset), 
           [Lval (Var stvar, NoOffset); 
            Lval (Var clvar_old, NoOffset);], locUnknown)) in (mkStmt (Instr [i])) in
    
  let stmts =
    let handle_arg arginfo = 
      Formatcil.cStmts
        "(*closure_old) %o:valfield = (*closure_new) %o:valfield;
         (*closure_old) %o:modfield = (*closure_new) %o:modfield;
         (*closure_old) %o:hanfield = (void*) 0;"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure_old", Fv clvar_old);
          ("closure_new", Fv clvar_new);
          ("valfield", Fo (Field (arginfo.a_valfield, NoOffset)));
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
        ]
    in 
    List.flatten (List.map handle_arg c.c_args)
  in
  fundec.sbody <- mkBlock ([unsubscribe_stmt] @ stmts @ [subscribe_stmt]);
  fundec    
end


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_equals (c : closinfo) = begin
  let name = c.c_varinfo.vname ^ "_closure_equals" in
  let typ = TFun(intType, Some 
                   [stvar_formal (); 
                    ("closure_1", c.c_typptr, []);
                    ("closure_2", c.c_typptr, [])
                   ], false, []) in
  let _ = c.c_aux_equals <- makeGlobalVar name typ in
  let fundec = make_fundec c.c_aux_equals in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let result = maketempvar ~name:"result" intType in
  let clvar_1 = makeFormalVar fundec ~where:"$" "closure_1" c.c_typptr in
  let clvar_2 = makeFormalVar fundec ~where:"$" "closure_2" c.c_typptr in
  
  (* Initially, assume result = 1 *)
  let result_init_stmt = let i = 
    (Set ((Var result, NoOffset), one, locUnknown)) in (mkStmt (Instr [i])) in
  
  (* Return the result. *)
  let result_return_stmt = 
    mkStmt (Return (Some (Lval (Var result, NoOffset)), locUnknown)) in
  
  (* For each argument, test equality and set result=0 if this test fails. *)
  let if_stmt = 
    let handle_arg arginfo else_stmt = 
      Formatcil.cStmt
        "if( (*closure_1) %o:valfield != (*closure_2) %o:valfield )
           result = 0;
         else %s:else_stmt"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure_1", Fv clvar_1);
          ("closure_2", Fv clvar_2);
          ("valfield", Fo (Field (arginfo.a_valfield, NoOffset)));
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
          ("else_stmt", Fs else_stmt);
          ("result", Fv result);
        ]
    in
    (List.fold_right handle_arg c.c_args (mkStmt (Instr [])))
  in
  fundec.sbody <- mkBlock ([result_init_stmt; if_stmt; result_return_stmt]);
  fundec    
end


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_aux_hash (c : closinfo) = begin
  let name = c.c_varinfo.vname ^ "_closure_hash" in
  let typ = TFun(uintType, Some [stvar_formal (); ("closure", c.c_typptr, []);], false, []) in
  let _ = c.c_aux_hash <- makeGlobalVar name typ in
  let fundec = make_fundec c.c_aux_hash in ignore (current_fundec (Some fundec)) ;
  let stvar = make_stvar_formal fundec in
  let result = maketempvar ~name:"result" uintType in
  let closure = makeFormalVar fundec ~where:"$" "closure" c.c_typptr in
 
  (* Initially, set hash to zero. *)
  let result_init_stmt = let i = 
    (Set ((Var result, NoOffset), zero, locUnknown)) in (mkStmt (Instr [i])) in
  
  (* Return the resulting hash. *)
  let result_return_stmt = 
    mkStmt (Return (Some (Lval (Var result, NoOffset)), locUnknown)) in
  
  (* For each argument, test equality and set result=0 if this test fails. *)
  let if_stmt = 
    let handle_arg arginfo = 
      Formatcil.cStmt
        "result = hashword(stvar, result, (unsigned int) (*closure) %o:valfield);"
        (fun n t -> maketempvar ~name:n t) locUnknown
        [ ("closure", Fv closure);
          ("valfield", Fo (Field (arginfo.a_valfield, NoOffset)));
          ("modfield", Fo (Field (arginfo.a_modfield, NoOffset)));
          ("hanfield", Fo (Field (arginfo.a_hanfield, NoOffset)));
          ("hashword", Fv api.apifn_hashword);
          ("result", Fv result);
          ("stvar", Fv stvar);
        ]
    in
    (List.map handle_arg c.c_args)
  in
  fundec.sbody <- mkBlock ([result_init_stmt] @ if_stmt @ [result_return_stmt]);
  fundec    
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Make global of type closure_staticinfo_t; Initialized with the given closinfo *)
let make_staticinfo (c : closinfo) = begin
  let var = c.c_staticinfo in 
  
  let compinfo = match api.apity_closure_staticinfo with 
      TNamed({ttype=TComp(compinfo, _)}, _) -> compinfo | _ -> raise Hell in
  
  let offset_and_init field var =
    let offset = Field(field, NoOffset) in
    let varinit = SingleInit(CastE(field.ftype ,Lval(Var var, NoOffset))) in
    (offset, varinit) in
  
  let offset_and_init_from_field field = match field.fname with
      "size"        -> (Field(field, NoOffset), SingleInit(SizeOf c.c_typdef))
    | "funptr"      -> offset_and_init field c.c_fundec.svar
    | "subscribe"   -> offset_and_init field c.c_aux_subscribe
    | "unsubscribe" -> offset_and_init field c.c_aux_unsubscribe
    | "refresh"     -> offset_and_init field c.c_aux_refresh
    | "replace"     -> offset_and_init field c.c_aux_replace
    | "equals"      -> offset_and_init field c.c_aux_equals
    | "hash"        -> offset_and_init field c.c_aux_hash
    | _             -> out "what is %s?" field.fname ; raise Hell
  in

  let field_inits = List.map offset_and_init_from_field compinfo.cfields in
  
  let initinfo = 
    {init = Some (CompoundInit (api.apity_closure_staticinfo, field_inits))} in
  
  (*
  c.c_staticinfo.vattr <- addAttribute (Attr("const",[])) c.c_staticinfo.vattr ;
  c.c_staticinfo.vattr <- addAttribute (Attr("static",[])) c.c_staticinfo.vattr ;
  *)
  
  GVar(c.c_staticinfo, initinfo, locUnknown)
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let transform_fundec (fundec : fundec) (loc : location) = begin    
  (*let _ = Liveness.computeLiveness fundec in*)
  let c = H.find closinfos fundec.svar.vname in  
  let aux_new_fundec = make_aux_new c fundec.sformals in
  let aux_subscribe_fundec = make_aux_subscribe c in
  let aux_unsubscribe_fundec = make_aux_unsubscribe c in
  let aux_refresh_fundec = make_aux_refresh c in
  let aux_replace_fundec = make_aux_replace c in
  let aux_equals_fundec = make_aux_equals c in
  let aux_hash_fundec = make_aux_hash c in
  let staticinfo = make_staticinfo c in
  ignore (current_fundec (Some fundec)) ;

  (* -- set the formals for [foo] to just [st] *)
  let old_formals = fundec.sformals in
  let _ = setFormals fundec [] in
  let stvar_formal = make_stvar_formal fundec in  
  
  (* -- Add an argument-unpacking preamble to [foo] *)  
  (* -- do: tmp_closure = current_closure(st); *)
  let tmp_closure = maketempvar ~name:"closure" c.c_typptr in  
  let instr_bindclosure = 
    Call (Some (Var tmp_closure, NoOffset), 
          Lval (Var api.apifn_current_closure, NoOffset), 
          [Lval (Var (stvar_formal), NoOffset)], locUnknown) 
  in
  
  (* -- do: formal_i = tmp_closure->field_i; *)
  let instrs_bindargs = 
    let instr_bindarg (formal, arginfo) = 
      Set( (Var formal, NoOffset),
           Lval (Mem (Lval(Var tmp_closure, NoOffset)), 
                 Field(arginfo.a_valfield, NoOffset)),
           locUnknown )
    in  
    List.map instr_bindarg 
      (List.combine old_formals c.c_args)
  in
  (* -- old formals are now locals *)
  fundec.slocals <- old_formals @ fundec.slocals ;
  (* -- put the new instructions at the top of the body *)
  fundec.sbody <- 
    mkBlock [ 
      mkStmt (Instr (instr_bindclosure :: instrs_bindargs)) ;
      mkStmt (Block fundec.sbody) ] 
  ;
  
  (* -- Return the globals we made. *)
  [ (* Change-to globals: *)
    GCompTag (c.c_compinfo, locUnknown) ;
    GFun (aux_subscribe_fundec, locUnknown) ;
    GFun (aux_unsubscribe_fundec, locUnknown) ;
    GFun (aux_refresh_fundec, locUnknown) ;
    GFun (aux_replace_fundec, locUnknown) ;
    GFun (aux_equals_fundec, locUnknown) ;
    GFun (aux_hash_fundec, locUnknown) ;
    GVarDecl (fundec.svar, loc) ;
    staticinfo;
    GFun (aux_new_fundec, locUnknown) ;
  ]
 end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* The meatiest visitor -- it does the actual transformation *)
class transform () = object(self)
  inherit nopCilVisitor    
        
  (* Process globals:
     x -- find actk_function prototypes and process them:
     x -- -- introduce new closure types, 
     x -- -- introduce aux prototypes
     
     -- find actk_function definitions and process them:
     x -- -- if no corresponding prototype, do the prototype steps above.
     x -- -- modify the original functions, specifically to unpack closures.
     x -- -- define associated aux functions
  *)
  method vglob (g:global) : global list visitAction = begin
    match g with 
      | GVarDecl (varinfo, loc) ->
          if hasAttribute "actk_function" varinfo.vattr
            && not (H.mem closinfos varinfo.vname) then
              (* -- process the prototypes for self-adjusting functions *)    
              let _ = out "** prototype for %s" varinfo.vname in
              let globs = transform_prototype varinfo loc in
              ChangeTo globs
          else
            DoChildren
                            
      | GFun(fundec, loc) ->
          if hasAttribute "actk_function" fundec.svar.vattr then
            let _ = out "** fundec for %s" fundec.svar.vname in
            (* -- if no prototype has been seen yet, handle that now *)
            let globs1   = (if H.mem closinfos fundec.svar.vname then [] 
                            else transform_prototype fundec.svar loc) in
            let closinfo = H.find closinfos fundec.svar.vname in
            let _        = closinfo.c_fundec <- fundec in
            let globs2   = transform_fundec fundec loc in
            (* -- transform the body of the function *)
            let fundec   = visitCilFunction (new transform () :> cilVisitor) fundec in
            ChangeTo (globs1 @ globs2 @ [GFun(fundec, loc)])
          else
            DoChildren
              
      | _ -> DoChildren
  end
    
  method vfunc(fundec) = begin
    (* -- Track the current function. *)
    ignore (current_fundec (Some fundec)) ;
    Cfg.printCfgFilename (fundec.svar.vname ^ ".dot") fundec ;
    DoChildren
  end
    
  method vvdec (varinfo) : varinfo visitAction = begin
    (* -- Track the current state variable. *)
    if hasAttribute "actk_state" varinfo.vattr then begin
      out "current_stvar: %s" varinfo.vname ;
      ignore (current_stvar (Some varinfo))
    end ;
    DoChildren
  end

  method vinst (i:instr) : instr list visitAction = begin
    match i with
        (* Transform call-sites of self-adjusting functions:
           -- construct closures for the function-call.
           -- call the closure using the API.
        *)
        Call (lhs, Lval(Var v, NoOffset), args, l) -> begin
          if hasAttribute "actk_function" v.vattr then begin
            out "* call-site for %s" v.vname ;
            let closinfo = H.find closinfos v.vname in
            let tmp_closure = maketempvar ~name:"closure" closinfo.c_typptr in
            let stexp = current_stexp () in
            (* -- Compute the args and the readmask -- the args are
               unchanged except that "read-casts" are removed and instead
               recorded in the read mask *)
            let (args, mask) = 
              let rec strip_arg arg i : (exp * int) = 
                match arg with
                    CastE(typ, e) -> 
                      if hasAttribute "actk_read" (typeAttrs typ) 
                      then (e, 1 lsl i)
                      else let (e, m) = strip_arg e i in (CastE(typ, e), m)
                  | _ -> (arg, 0)
              in
              let rec loop (args : exp list) (i : int) : (exp list * int) = 
                match args with
                    [] -> ([], 0)
                  | a::args -> 
                      let (a, m) = strip_arg a i in
                      let (args, mask) = loop args (i + 1) in
                      (a :: args, m lor mask)
              in
              (loop args 0)
            in
            let _ = match lhs with None -> () | _ -> raise Hell in
            let instrs = [
              Call(Some (Var tmp_closure, NoOffset), 
                   Lval(Var(closinfo.c_aux_new), NoOffset), 
                   stexp :: (integer mask) :: args,
                   locUnknown) ;
              
              Call(None, 
                   Lval(Var(api.apifn_call), NoOffset), 
                   [stexp;
                    mkCast 
                      ~e:(Lval(Var(tmp_closure), NoOffset)) 
                      ~newt:(TPtr(api.apity_closure, [])) ],
                   locUnknown) 
            ] in
            ChangeTo instrs
          end
            
          (* -- handle: modref_write. *)
          else if v == api.apifn_write then
            let stexp = current_stexp () in
            let _ = match lhs with None -> () | _ -> raise Hell in
            ChangeTo [Call(None, Lval(Var api.apifn_modref_write, NoOffset), stexp :: args, l)]
              
          (* -- handle: modref_new *)
          else if v == api.apifn_modref then
            let stexp = current_stexp () in
            ChangeTo [Call(lhs, Lval(Var api.apifn_modref_new, NoOffset), stexp :: args, l)]

          else if v == api.apifn_read then
            let var = match lhs with 
                Some (Var var, NoOffset) -> var
              | _ -> raise Hell in
            out "read into %s" var.vname ;
            DoChildren

          else
            DoChildren              
        end

      | _ -> DoChildren
  end
end
