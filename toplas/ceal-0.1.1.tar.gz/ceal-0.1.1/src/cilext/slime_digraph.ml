open Slime_util
open Printf

module type Node = sig
  type t
  val compare : t -> t -> int
  val succs : t -> t list
  val preds : t -> t list
  val name : t -> string
  val compare_names : t -> t -> int
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)  
module Make (N:Node) = 
struct   
  
  (* Sets of nodes *)
  module S = Set.Make(N)
    
  (* Map nodes to other things *)
  module M = Map.Make(N)
    
  (* Paritition of nodes -- maps nodes to equiv class (a set of nodes)
     to which the node belongs *)
  module P = Map_set(M)(S)

    (* Depth-First Search -- returns discover and finish times for each
       node, as well as a mapping that maps each node to its
       depth-first-tree (represented as a set of nodes) -- successor
       function is an argument to allow DFS on transpose graphs. *)
  let dfs 
      (nodes : N.t list) 
      (succs : N.t -> N.t list)         
      (* discover-times * finish-times * dfs-trees *)
      : (int M.t * int M.t * P.t) 
      =
    
    let next_time = ref 0 in
    let discover  = ref (M.empty : int M.t) in
    let finish    = ref (M.empty : int M.t) in
    let dfstrees  = ref (M.empty : P.t) in
    
    let advance_time _ =
      (let time = !next_time in
       next_time := !next_time + 1 ;
      time)
    in

    (* Given a node to visit and the set of nodes in the current
    DFS-tree, return an updated set of nodes in the DFS-tree.  Also
    updates [discover] and [finish] for each new node *)
    let rec dfs_visit  (node : N.t) (dfstree : S.t) : S.t = begin
      let dfstree = S.add node dfstree in
      discover := M.add node (advance_time ()) !discover ;
      let dfstree = (List.fold_left
                       (fun dfstree node -> 
                          if (M.mem node !discover) then dfstree
                          else dfs_visit node dfstree)
                       dfstree (succs node)) 
      in
      finish := M.add node (advance_time()) !finish ;
      dfstree
    end
    in
    
    (* Does DFS over the nodes in the order given. *)
    let rec dfs (nodes : N.t list) =
      match nodes with
        | [] -> ()
        | node::nodes -> begin
            (if not (M.mem node !discover) then begin
               let dfstree = S.empty in
               let dfstree = dfs_visit node dfstree in               
               (S.iter 
                  (fun node -> dfstrees := M.add node dfstree !dfstrees) 
                  dfstree)
             end) ;
            dfs nodes
          end
    in begin
      dfs nodes ;
      (!discover, !finish, !dfstrees)
    end
         
  (* Strongly-connected Components (SCCs) *)
  let sccs (nodes : N.t list) 
      : (P.t) (* Output: Maps each node to its SCC, represented as a set. *)
      =
    let (_, finish, _) = dfs nodes N.succs in
    let nodes_by_greatest_finish : N.t list = 
      List.sort 
        (fun node_1 node_2 -> 
           let f_node_1 : int = M.find node_1 finish in
           let f_node_2 : int = M.find node_2 finish in
           (f_node_2 - f_node_1) (* smaller finish times are "greater" in this ordering *))
        nodes
    in
    let (_, _, dfstrees) = dfs nodes_by_greatest_finish N.preds in
    (dfstrees)

  (* Given a SCC, determine if the component can give rise to infinite
     paths --- If the SCC has more than 1 element, then its not finite
     (at least one cycle exists).  If it has a single element [n] and
     [n] contains an edge to itself then the SCC is not finite.
     Otherwise, the SCC is finite (it contains a single node which
     cannot loop to itself). *)
  let scc_is_finite (scc:S.t) =
    if (S.cardinal scc) > 1 then false
    else let rep = S.choose scc in
    not (List.mem rep (N.succs rep))

end
