open Printf
open Cil
open Slime_util
open Slime_api
open Slime_program

type keyinfo = { mutable key_name : string ;
                 mutable key_typ : typ ;
                 mutable key_off : offset ;
               }  

let pointer_typ (al:sac_allocation) : typ =
  (* Get the type of the pointer from the type of the first argument
     of the initialization function *)
  let inittyp = al.al_initsvar.vtype in
  match inittyp with
    | TFun(_, Some((_, ptrtyp, _)::_), _, _) -> ptrtyp
    | _ -> raise Hell

let rec mkstruct (al:sac_allocation) (ob:traceobj)
    : typ * keyinfo list
    =
  let basename = allocation_basename al in  
  let compinfo =
    let make_fields (compinfo:compinfo) =
      
      let rec loop (num:int) (typs:typ list) =
        match typs with
            [] -> []
          | typ::typs -> 
              let proto_field = ((sprintf "key_%d" num), typ, 
                                 None, [], locUnknown) in
              proto_field::(loop (num + 1) typs)
      in      
      let proto_fields = loop 0 al.al_keytypes in
      ("block", api_typ "block_t", None, [], locUnknown)
      :: ("reqspace", TArray (charType, Some al.al_sizeexp, []), None, [], locUnknown)
      :: proto_fields 
    in
    mkCompInfo true (basename^"_s") make_fields []
  in  
  let keyinfos = mkkeyinfos compinfo in
  let typeinfo = {tname=basename^"_t";
                  ttype=TComp(compinfo,[]);
                  treferenced=true;} in
  let typedef = TNamed (typeinfo, []) in
  begin
    extend_proto ob (GCompTagDecl (compinfo, locUnknown)) ;
    extend_proto ob (GType (typeinfo, locUnknown)) ;
    extend_def ob (GCompTag (compinfo, locUnknown)) ;
    (typedef, keyinfos)
  end
    
and mkkeyinfos (compinfo:compinfo)
    : keyinfo list
    = 
  let rec loop fields =
    match fields with
      | [] -> []
      | field::fields when (field.fname="block") -> loop fields
      | field::fields when (field.fname="reqspace") -> loop fields
      | field::fields -> 
          begin
            let keyinfo = { key_name = field.fname ;
                            key_typ = field.ftype ;
                            key_off = Field(field, NoOffset) ;
                          }
            in
            (keyinfo :: loop fields)
          end
  in
  (loop compinfo.cfields)    
    
let block_elaborate al =
  let ob = al.al_traceobj in
  let basename = allocation_basename al in
  let (inst_typ, keyinfos) = mkstruct al ob in
  let inst_ptr = TPtr(inst_typ, []) in
  let buffer_typ = TPtr(TInt(IUChar, []), []) in
  let vtbl_var = (makeGlobalVar
                    (basename^"_vtbl")
                    (api_typ "block_vtbl_t"))    
  in
  let _ = vtbl_var.vstorage <- Static in
  let name_typ = TFun(charConstPtrType,
                      Some [("closure", inst_ptr, [])], 
                      false, [])
  in  
  let size_typ = TFun(api_typ "uintptr_t", 
                      Some [("block", inst_ptr, [])], 
                      false, []) 
  in  
  let buff_typ = TFun(api_typ "uintptr_t",
                      Some [("block", inst_ptr, []);
                            ("buffer", buffer_typ, [])],
                      false, [])
  in
  let hash_typ = TFun(api_typ "uintptr_t",
                      Some [("block", inst_ptr, []);
                            ("hashin", (api_typ "uintptr_t"), [])],
                      false, [])
  in
  let eqiv_typ = TFun(api_typ "uintptr_t",
                      Some [("block_1", inst_ptr, []);
                            ("block_2", inst_ptr, [])], 
                      false, []) 
  in
  let init_typ = TFun(voidType,
                      Some [("block", inst_ptr, [])], 
                      false, []) 
  in
  let comb_typ = TFun(voidType,
                      Some [("block_1", inst_ptr, []);
                            ("block_2", inst_ptr, [])], 
                      false, []) 
  in  
  let current_fundec = 
    ref dummyFunDec
  in  
  let make_fundec (opname:string) (optyp:typ) (storage:storage) =
    let varinfo = makeGlobalVar (basename^"_"^opname) optyp in
    let _ = varinfo.vstorage <- storage in
    let fundec = make_fundec varinfo in
    let _ = current_fundec := fundec in
    extend_def ob (GFun (fundec, locUnknown)) ; fundec
  in
  let make_temp_var ?(name="tmpa___") (typ:typ) : varinfo =
    if(!current_fundec == dummyFunDec) 
    then raise (Heck "current_fundec is dummyFunDec!")
    else (makeTempVar ~name !current_fundec typ)
  in

  (* An (integer) expression that evaluates to the size of buffer
     required for "buff" operation *)
  let rec buff_size_exp keyinfos =
    match keyinfos with 
      | [] -> zero
      | keyinfo::keyinfos -> 
          BinOp ( PlusA,
                  SizeOf (keyinfo.key_typ), 
                  buff_size_exp keyinfos,
                  api_typ "uintptr_t"
                )
  in
  
  (* Operation: INST -- instantiate *)
  let make_inst _ =
    let inst_typ = 
      let typ_formals =
        (List.map (fun keyinfo -> 
                     (keyinfo.key_name, 
                      keyinfo.key_typ, [])) 
           keyinfos)
      in      
      TFun(inst_ptr, Some typ_formals, false, [])
    in
    let fundec = make_fundec "inst" inst_typ Static in
    let tmp_block = makeTempVar fundec inst_ptr in
    let inst_stmt = 
      mkStmt (Instr [(Call (Some (Var tmp_block, NoOffset), 
                            Lval (Var (api_varinfo "block_inst"), NoOffset), 
                            [AddrOf (Var vtbl_var, NoOffset)],
                            locUnknown))])       
    in    
    let keys : (varinfo * keyinfo) list = List.map 
      (fun keyinfo -> 
         (makeFormalVar fundec keyinfo.key_name keyinfo.key_typ, keyinfo))
      keyinfos
    in
    let init_stmts =
      let handle_key (key_arg, keyinfo) =
        Formatcil.cStmt
          "(*block) %o:key_off = key_arg;"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("block",  Fv tmp_block);
            ("key_arg",  Fv key_arg);
            ("key_off",  Fo keyinfo.key_off); ]
      in
      (List.map handle_key keys)
    in
    let return_stmt = 
      mkStmt (Return (Some(Lval (Var tmp_block, NoOffset)), locUnknown)) in    
    fundec.sbody <- mkBlock (inst_stmt :: init_stmts @ [return_stmt]) ;
    fundec.svar
  in

  (* Operation: NAME *)
  let make_name _ =
    let fundec = make_fundec "name" name_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "block" inst_ptr in
    fundec.sbody <- mkBlock [mkStmt (Return(Some (Const (CStr basename)), locUnknown))] ;
    fundec.svar
  in

  (* Operation: SIZE *)
  let make_size _ =
    let fundec = make_fundec "size" size_typ Static in
    let tmp_block = makeFormalVar fundec ~where:"$" "block" inst_ptr in
    fundec.sbody <- mkBlock [mkStmt (Return(Some (SizeOf inst_typ), locUnknown))] ;
    fundec.svar
  in
  
  (* Operation: BUFF *)
  let make_buff _ =
    let fundec = make_fundec "buff" buff_typ Static in
    let tmp_block   = makeFormalVar fundec ~where:"$" "block" inst_ptr in
    let tmp_buffer  = makeFormalVar fundec ~where:"$" "buff" buffer_typ  in
    let fill_stmts =
      let handle_keyinfo keyinfo =
        Formatcil.cStmts
          "*((%t:key_t *) buffer) = (*block) %o:key_off;
           buffer = (unsigned char*) (((%t:key_t *) buffer) + 1);"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("block",    Fv tmp_block);
            ("buffer",   Fv tmp_buffer);
            ("key_t",    Ft keyinfo.key_typ);
            ("key_off",  Fo keyinfo.key_off);
          ]
      in
      List.flatten (List.map handle_keyinfo keyinfos)
    in    
    let check_and_fill = 
      mkStmt (If ((Lval (Var tmp_buffer, NoOffset)), 
                  mkBlock (fill_stmts), mkBlock [], locUnknown))
    in
    let return_size = 
      mkStmt (Return (Some (buff_size_exp keyinfos), locUnknown))
    in
    fundec.sbody <- mkBlock [check_and_fill; return_size] ;
    fundec.svar
  in

  (* Operation: HASH *)
  let make_hash buff_svar =
    let fundec = make_fundec "hash" hash_typ Static in
    let tmp_block = makeFormalVar fundec ~where:"$" "block" inst_ptr in
    let tmp_hashin  = makeFormalVar fundec ~where:"$" "hashin" (api_typ "uintptr_t") in
    let tmp_result  = makeTempVar fundec (api_typ "uintptr_t") in
    let tmp_buffer  = 
      makeTempVar fundec 
        (TArray (TInt (IUChar, []), Some (buff_size_exp keyinfos), [])) 
    in
    let hash_buff_stmts = 
      Formatcil.cStmts
        "buff(block, buffer);
           result = hashfn(buffer, %e:size, hashin);
           return result;"
        (fun n t -> make_temp_var ~name:n t) locUnknown
        [ ("block",    Fv tmp_block);
          ("hashin",   Fv tmp_hashin);
          ("buffer",   Fv tmp_buffer);
          ("result",   Fv tmp_result);
          ("buff",     Fv buff_svar);
          ("size",     Fe (buff_size_exp keyinfos));
          ("hashfn",   Fv (api_varinfo "hash_buffer"));
        ]
    in
    let stmts = 
      match keyinfos with
        | keyinfo::[] -> begin
            Formatcil.cStmts
              "if(sizeof(%t:key_t) == sizeof(%t:uintptr_t)) {
                  result = hashwordfn((%t:uintptr_t) ((*block) %o:key_off));
                  return result;
                } 
                else { 
                  %S:elsecase
                }"
              (fun n t -> make_temp_var ~name:n t) locUnknown
              [ ("block",       Fv tmp_block);
                ("result",      Fv tmp_result);
                ("key_t",       Ft keyinfo.key_typ);
                ("key_off",     Fo keyinfo.key_off);
                ("uintptr_t",   Ft (api_typ "uintptr_t"));
                ("hashwordfn",  Fv (api_varinfo "hash_oneword"));
                ("elsecase",    FS hash_buff_stmts);
              ]
          end
        | _ -> (hash_buff_stmts)
    in
    fundec.sbody <- mkBlock stmts;
    fundec.svar
  in
  
  (* Operation: EQIV -- Equivalent? *)
  let make_eqiv _ =
    let fundec = make_fundec "eqiv" eqiv_typ Static in
    let tmp_block1 = makeFormalVar fundec ~where:"$" "block_1" inst_ptr in
    let tmp_block2 = makeFormalVar fundec ~where:"$" "block_2" inst_ptr in
    let test_stmts = 
      let handle_keyinfo keyinfo =
        Formatcil.cStmts "if ((*block1) %o:key_off != (*block2) %o:key_off)
                            return 0;"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("block1", Fv tmp_block1);
            ("block2", Fv tmp_block2);
            ("key_off", Fo keyinfo.key_off);]
      in
      (List.flatten (List.map handle_keyinfo keyinfos))
    in
    let return_one = 
      mkStmt (Return (Some one, locUnknown))
    in
    fundec.sbody <- mkBlock (test_stmts @ [return_one]);
    fundec.svar
  in

  (* Operation: INIT -- Initialize *)
  let make_init _ =
    let fundec = make_fundec "init" init_typ Static in
    let tmp_block = makeFormalVar fundec ~where:"$" "block" inst_ptr in
    let keys : (varinfo * keyinfo) list = List.map 
      (fun keyinfo -> 
         (makeTempVar fundec keyinfo.key_typ, keyinfo))
      keyinfos
    in
    let unpack_stmts =
      let handle_key (key_arg, keyinfo) =
        Formatcil.cStmt
          "key_arg = (*block) %o:key_off;"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("block", Fv tmp_block);
            ("key_arg", Fv key_arg);
            ("key_off", Fo keyinfo.key_off) ]
      in
      (List.map handle_key keys)
    in
    let init_args = 
      (* The first argument is a pointer the requested space *)
      (CastE (pointer_typ al, Lval (Mem (Lval (Var tmp_block, NoOffset)),
                                    proj inst_typ ["reqspace"] )))
        
      (* The remaining arguments are the keys *)
      :: (List.map (fun (varinfo, _) -> 
                   Lval(Var varinfo, NoOffset)) keys)
    in    
    
    (* BUG-FIX: There may be more keys than initialization arguments,
       so drop the extra keys *)
    let init_args = 
      first_n_of_list (init_args) 
        (count_formals al.al_initsvar) 
    in

    let init_stmt =
      mkStmt (Instr [Call (None, Lval (Var al.al_initsvar, NoOffset),
                           init_args, locUnknown)])
    in
    fundec.sbody <- mkBlock (unpack_stmts @ [init_stmt]) ;
    fundec.svar
  in
  (* Create initializer for field named [fname] for vtbl of type [typ]
     using variable [varinfo] *)
  let vtbl_init (typ:typ) (fname:string) (varinfo:varinfo)
      : (offset * init) 
      = 
    let offset = proj typ [fname] in
    let field = proj_field offset in
    (offset, SingleInit(CastE(field.ftype, Lval(Var varinfo, NoOffset))))
  in  
  begin  
    extend_def ob (GVarDecl (vtbl_var, locUnknown));
    ob.ob_inst_fun <- make_inst () ;
    ob.ob_inst_typ <- inst_typ ;
    extend_proto ob (GVarDecl (ob.ob_inst_fun, locUnknown));

    let name = make_name () in
    let size = make_size () in
    let buff = make_buff () in
    let hash = make_hash buff in
    let eqiv = make_eqiv () in
    let init = make_init () in
    let sing =  (if List.length keyinfos > 0 
                 then (api_varinfo "traceobj_sing_false")
                 else (api_varinfo "traceobj_sing_true")) 
    in
    let traceobj_vtbl_init : init =
      let typ = (api_typ "traceobj_vtbl_t") in
      let inits : (offset * init) list = 
        [ vtbl_init typ "name" name;
          vtbl_init typ "size" size;
          vtbl_init typ "sing" sing;
          vtbl_init typ "buff" buff;
          vtbl_init typ "hash" hash;
          vtbl_init typ "eqiv" eqiv;
          vtbl_init typ "time" (api_varinfo "block_time");
          vtbl_init typ "init" init;
          vtbl_init typ "comb" (api_varinfo "block_comb"); ]
      in
      CompoundInit (typ, inits)
    in  
    extend_def ob (GVar (vtbl_var, {init=Some traceobj_vtbl_init}, locUnknown))
  end

let block_prototype al = 
  List.rev al.al_traceobj.ob_prototype

let block_definition al =
  List.rev al.al_traceobj.ob_definition
