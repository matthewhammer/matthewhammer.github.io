(* SAC Program representations *)
open Cil
open Slime_util
open Slime_cfg
open Printf

exception Lookup_error of string

type traceobj =
    { mutable ob_inst_typ : typ ; (* Instance type *)     
      mutable ob_inst_fun : varinfo ; (* Instantiation function *)
      mutable ob_prototype : global list ;  (* Prototype globals *)
      mutable ob_definition : global list ; (* Definition globals *)
    }

type sac_allocation = 
    { mutable al_num : int ; (* a unique number *)
      mutable al_initsvar : varinfo ; (* the varinfo for the initialization function *)
      mutable al_sizeexp : exp ; (* the size of the allocation *)
      mutable al_keytypes : typ list ; (* types of keys used *)
      mutable al_traceobj : traceobj ; (* corresponding trace object *)
    }

let extend_def (ob:traceobj) (global:global) =
  ob.ob_definition <- global :: ob.ob_definition

let extend_proto (ob:traceobj) (global:global) =
  ob.ob_prototype <- global :: ob.ob_prototype

module Sac_allocation = struct
  type t = sac_allocation
  let compare al1 al2 =
    let compare_initsvar = compare al1.al_initsvar al2.al_initsvar in
    let compare_sizeexp = compare al1.al_sizeexp al2.al_sizeexp in
    if compare_initsvar <> 0 then compare_initsvar
    else if compare_sizeexp <> 0 then compare_sizeexp
    else
      let rec loop typs1 typs2 = 
        match (typs1, typs2) with
            ([], []) -> 0
          | ([], _) -> -1
          | (_, []) -> 1
          | (typ1::typs1, typ2::typs2) ->
              let compare_typ = compare typ1 typ2 in
              if compare_typ <> 0 then compare_typ
              else loop typs1 typs2
      in 
      (loop al1.al_keytypes al2.al_keytypes)
end

module Sac_al_set = Set.Make(Sac_allocation)
module Sac_al_map = Map.Make(Sac_allocation)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* [sac_function] represents all of the following: 
   (1) Meta functions (code that performs meta operations) 
   (2) Self-adjusting functions -- code that is traced 
   (3) Initialization functions -- code that initializes traced block allocations 
*)
type sac_function_kind =
  (* Meta functions *)
  | Sac_fn_meta      

  (* Self-adjusting functions *)
  | Sac_fn_self 
      of traceobj  (* (static) closure/call information *)
        
  (* Initialization functions *)
  | Sac_fn_init 
      of Sac_al_set.t (* (static) block/alloc information *)

type sac_function = 
    { 
      mutable fn_varinfo : varinfo ; (* Used as a key to match prototypes to defs *)
      
      mutable fn_source : fundec option ; (* Source function -- absent
                                             for functions we create
                                             via normalization, and
                                             for functions for which
                                             we only have a
                                             prototype. *)

      mutable fn_kind : sac_function_kind ; (* Function kind *)
      
      mutable fn_globs : global list ; (* static code-locations; 
                                          see also: slime_codeloc.ml *)

      (* Control-flow graph (CFG) -- initially corresponds to source
         function, but then is transformed/optimized, etc. *)
      mutable fn_cfg : sac_cfg ;

      (* Normalization *)
      mutable fn_normal : fundec ; (* Normalized function *)
      mutable fn_fundec : fundec ; (* Elaborated function *)
      mutable fn_descs  : sac_function list ; (* Descendents resulting from normalization *)
      
      (* Static callgraph *)
      mutable fn_preds : sac_function list ; (* Predecessors in static call-graph *)
      mutable fn_succs : sac_function list ; (* Successors in static call-graph *)

      (* Verifier Code *)
      mutable fn_verif : (varinfo * ((sac_cfg * fundec) option)) option
    }

module Sac_function = struct
  type t = sac_function
  let name fn = fn.fn_varinfo.vname
  let compare_names fn1 fn2 = compare (name fn1) (name fn2)
  let preds fn = fn.fn_preds
  let succs fn = fn.fn_succs
  let compare fn1 fn2 = 
    let name_comparison = compare_names fn1 fn2 in
    if (not (fn1 == fn2)) && (name_comparison = 0)
    then raise (Error (sprintf "functions with same name, `%s', aren't physically equal" (name fn1)))
    else name_comparison
end
  
module Sac_fn_set = Set.Make(Sac_function)
module Sac_fn_dom = Slime_dominator.Make(Sac_function)  
module Sac_fn_dig = Slime_digraph.Make(Sac_function)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)

let dummy_compinfo : compinfo = 
  mkCompInfo true "@dummystruct" 
    (fun compinfo -> []) []

let dummy_var : varinfo =
  makeGlobalVar "@dummyvar" voidPtrType

let dummy_traceobj _ : traceobj = {
  ob_inst_typ = voidType ;
  ob_inst_fun = dummy_var ;
  ob_prototype = [] ;
  ob_definition = [] ;
}

let dummy_function kind : sac_function = { 
  fn_varinfo = dummy_var;
  fn_source = None;
  fn_kind = kind;
  fn_globs = [];
  fn_cfg = dummy_cfg Sac_cfg_meta ;
  fn_normal = dummyFunDec;
  fn_fundec = dummyFunDec;
  fn_descs = [];
  fn_preds = [];
  fn_succs = [];
  fn_verif = None;
}

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)

(* Stores all the functions we find and elaborate *)
let sac_functions 
    : Sac_fn_set.t ref
    = ref Sac_fn_set.empty

(* Functions keyed by their name *)
let sac_functions_by_var 
    : sac_function Varmap.t ref 
    = ref Varmap.empty

(* Maps allocations to representative allocations *)
let sac_allocations
    : sac_allocation Sac_al_map.t ref 
    = ref Sac_al_map.empty
  
(* Set of all verifier functions -- used to elaborate ISVERIF macro *)
let verif_functions_by_var
    : Varset.t ref
    = ref Varset.empty

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)

(* Add a function to the program. *)
let add_function (fn:sac_function) = 
  let add_it _ = 
    (* pre: assumes the varinfo is fresh *) 
    sac_functions := Sac_fn_set.add fn !sac_functions ;
    sac_functions_by_var := (Varmap.add fn.fn_varinfo fn !sac_functions_by_var);    
  in
  if Varmap.mem fn.fn_varinfo !sac_functions_by_var then    
    let fn0 = Varmap.find fn.fn_varinfo !sac_functions_by_var in
    match (fn0.fn_source, fn.fn_source) with
      | (Some _, Some _) -> raise (Error (sprintf "multiple defs for `%s'" fn0.fn_varinfo.vname))
      | (None, Some _) -> sac_functions := Sac_fn_set.remove fn0 !sac_functions ; add_it ();
      | (_, _) -> ()
  else
    add_it ()

(* Make call edge: "fn1 --> fn2" *)
let add_edge (fn1:sac_function) (fn2:sac_function) = 
  begin
    fn1.fn_succs <- fn2 :: fn1.fn_succs ;
    fn2.fn_preds <- fn1 :: fn2.fn_preds ;
  end

(* check if the given varinfo corresponds to a sac_function *)
let check_function (varinfo:varinfo) =
  (Varmap.mem varinfo !sac_functions_by_var)
  
(* Lookup a function by it's varinfo *)
let lookup_function (varinfo:varinfo) = 
  try (Varmap.find varinfo !sac_functions_by_var) 
  with Not_found -> 
    raise (Bug (sprintf "lookup %s" varinfo.vname))

(* Given a varinfo for an initialization function, get all the
   representative allocations that use it. *)
let lookup_init_function (initsvar:varinfo) 
    : (sac_function * Sac_al_set.t) 
    =
  let init_fn = lookup_function initsvar in
  let als = match init_fn.fn_kind with 
    | Sac_fn_init als -> als 
    | _ -> raise (Lookup_error initsvar.vname) in  
  (init_fn, als)

let lookup_self_function (selfsvar:varinfo)
    : (sac_function * traceobj)
    =
  let self_fn = lookup_function selfsvar in
  let traceobj = match self_fn.fn_kind with
    |  Sac_fn_self traceobj -> traceobj 
    | _ -> raise (Lookup_error selfsvar.vname) in
  (self_fn, traceobj)

let lookup_source_fundec (varinfo:varinfo) =
  let fn = lookup_function varinfo in
  match fn.fn_source with 
    | Some fundec -> fundec 
    | None -> raise (Lookup_error varinfo.vname)

let add_verifier (fundec:fundec) : unit =
  verif_functions_by_var := 
    (Varset.add fundec.svar !verif_functions_by_var)

(*
let add_extern_function (varinfo:varnfo) (kind:sac_function_kind) =
  let fn = dummy_function with { fn_kind = kind } in
*)  

(* Add a function we find in the source program. *)
let add_source_function 
    (varinfo:varinfo)
    (fundec:fundec option) 
    (kind:sac_function_kind) 
    = 
  let verif_varinfo = 
    {varinfo with 
       vname = (varinfo.vname ^ "_verif")}
  in
  let cfg_kind = match kind with
      Sac_fn_init _ -> Sac_cfg_init
    | Sac_fn_meta   -> Sac_cfg_meta
    | Sac_fn_self _ -> Sac_cfg_self
  in
  no_out "add_source_function: %s" varinfo.vname ;
  
  let fn = match fundec with
    | None ->
        { fn_varinfo  = varinfo;
          fn_source   = None;
          fn_kind     = kind;
          fn_globs    = [];
          fn_cfg      = dummy_cfg cfg_kind;
          fn_normal   = dummyFunDec; 
          fn_fundec   = dummyFunDec;
          fn_descs    = [];
          fn_preds    = [];
          fn_succs    = [];
          fn_verif    = Some (verif_varinfo, None);
        }
    | Some fundec ->        
        let cfg      = cfg_of_fundec fundec cfg_kind in
        let v_cfg    = cfg_of_fundec fundec Sac_cfg_verf in
        let v_fundec = {fundec with svar = verif_varinfo} in
        let _        = add_verifier v_fundec in
        { fn_varinfo  = varinfo;
          fn_source   = Some fundec;
          fn_kind     = kind;
          fn_globs    = [];
          fn_cfg      = cfg;
          fn_normal   = {fundec with svar = varinfo}; 
          fn_fundec   = {fundec with svar = varinfo};
          fn_descs    = [];
          fn_preds    = [];
          fn_succs    = [];
          fn_verif    = Some (verif_varinfo, Some (v_cfg, v_fundec));
        }
  in (add_function fn ; fn)

(* Add a self-adjusting function from source. *)
let add_source_self_function 
    (varinfo:varinfo) 
    (fundec:fundec option) 
    : sac_function 
    = add_source_function varinfo fundec (Sac_fn_self (dummy_traceobj ()))

(* Add an init function from source. *)
let add_source_init_function 
    (varinfo:varinfo) 
    (fundec:fundec option) 
    : sac_function 
    = add_source_function varinfo fundec (Sac_fn_init Sac_al_set.empty)

(* Add a meta function from source. *)
let add_source_meta_function 
    (varinfo:varinfo) 
    (fundec:fundec option) 
    : sac_function 
    = add_source_function varinfo fundec Sac_fn_meta

(* Add a normal function we generate. *)
let add_normal_function 
    (orig_fn:sac_function) 
    (fundec:fundec) 
    (cfg:sac_cfg) 
    =
  let fn = { fn_varinfo = fundec.svar;
             fn_source = None;
             fn_cfg = cfg;
             fn_kind = Sac_fn_self (dummy_traceobj ());
             fn_globs = [];
             fn_normal = fundec ;
             fn_fundec = {fundec with svar = fundec.svar} ;
             fn_descs = [];
             fn_preds = [];
             fn_succs = [];
             fn_verif = None;
           } in
  let _ = orig_fn.fn_descs <- fn::orig_fn.fn_descs in
  (add_function fn) ; fn

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
    

(* A canonical "basename" for generated code and types associated with
   the allocation site. This name is taken from the name of the
   initialization function and made unique if necessary with an
   additional unique number.  Also, if the initialization function
   ends with "_init" (as many often do) this will be torn-off for the
   basename. *)
let allocation_basename (al : sac_allocation) =
  let init_fun_name = al.al_initsvar.vname in
  let regexp = Str.regexp "\\(.+\\)\\(_init\\)$" in
  let prefix = Str.global_replace regexp "\\1" init_fun_name in
  let suffix = 
    let default = sprintf "_%d" al.al_num in try 
      let (_, als) = lookup_init_function al.al_initsvar in
      if (Sac_al_set.cardinal als) > 1 then default else ""
    with Not_found -> default
  in
  (sprintf "%s_block%s" prefix suffix)


(* Resolve an allocation to a representative instance -- if a
   representative doesn't exist, then the given allocation becomes a
   representative.  In this case we also add this allocation to the
   various mappings and sets we track. *)
let resolve_allocation =
  let make_resolve _ =
    let next_num = ref 0 in
    (let resolve (al : sac_allocation) : sac_allocation =
       let debug = if false then out else no_out in
       if Sac_al_map.mem al !sac_allocations then begin
         let al = Sac_al_map.find al !sac_allocations in
         debug "resolved to an existing allocation: %s" (allocation_basename al) ; 
         (al)
       end else begin
         al.al_num <- !next_num ;
         incr next_num ;
         sac_allocations := (Sac_al_map.add al al !sac_allocations) ;
         let (init_fn, als) = lookup_init_function al.al_initsvar in
         init_fn.fn_kind <- Sac_fn_init (Sac_al_set.add al als) ;
         debug "resolved to a new allocation: %s" (allocation_basename al) ;
         al
       end
     in 
     resolve)
  in
  make_resolve ()

(* Resolve a [Slime_cfg.Sac_alloc] instruction to a representitive
   allocation --- this is just a convience function for [resolve]. *)
let allocation_of_instr 
    (size_exp:exp) 
    (initsvar:varinfo) 
    (key_exps:exp list) 
    : sac_allocation 
    =
  let al = {al_num = -1;
            al_initsvar = initsvar;
            al_sizeexp = size_exp;
            al_keytypes = List.map typeOf key_exps;
            al_traceobj = dummy_traceobj ();
           }
  in
  (resolve_allocation al)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let print_function_subgraph (out:out_channel) (fn:sac_function) =
  let name = fn.fn_varinfo.vname in
  let arg_strings = List.fold_left 
    (fun str argvar -> 
       if str <> "" then str^", "^argvar.vname else argvar.vname) 
    "" fn.fn_fundec.sformals
  in
  let bbs_strings = Sac_bb_set.fold 
    (fun bb bbs -> (dotnode_of_basic_block bb)::bbs)
    fn.fn_cfg.cfg_bbs [] 
  in    
  begin
    fprintf out "subgraph cluster_%s {\n" name ;
    fprintf out "labeljust=\"l\";\n" ;
    
    (* A node for the function name with an edge to the initial block. *)
    fprintf out "%s [shape=plaintext, label=\"%s(%s)\"];\n" name name arg_strings ;
    fprintf out "%s -> block_%d [weight=10];\n" name fn.fn_cfg.cfg_bb0.bb_id ;
    
    (* Print the blocks and local edges *)
    List.iter (fun bb_string -> fprintf out "%s\n" bb_string) bbs_strings ;
    fprintf out "}\n" ;
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let print_function_graph (name:string) (fns:sac_function list) = 
  begin
    let out = open_out (name ^ ".cfg.dot") in
    fprintf out "digraph %s {\nsize=\"6,8\"; center=\"true\"; compound=\"true\";\n" name ;
    List.iter (fun fn -> print_function_subgraph out fn) fns ;
    
    (* Print the tailcall edges *)
    List.iter (fun fn ->
                 let tailcall_strings = Sac_bb_set.fold
                   (fun bb strs -> (dotedges_of_tailcalls bb bb.bb_term)::strs)                   
                   fn.fn_cfg.cfg_bbs [] in
                 (List.iter (fprintf out "%s\n") tailcall_strings)) fns ;

    fprintf out "}\n" ;
    close_out out ;
  end

