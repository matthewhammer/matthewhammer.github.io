open Slime_util
open Printf

module type Node = sig
  type t
  val compare : t -> t -> int
  val preds : t -> t list
  val name : t -> string
end
  
(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)  
module Make (N:Node) = 
struct   
  
  (* Sets of nodes *)
  module S = Set.Make(N)
    
  (* Map nodes to other things *)
  module M = Map.Make(N)

  (* Dominator Mapping -- maps nodes to sets of dominating nodes. *)
  module D = Map_set(M)(S)
    
  (* Immediate dominator map -- mapes nodes to nodes *)
  type idom_map = N.t M.t
      
  (* Dominator trees *)
  type dom_tree = Dom_tree of N.t * (dom_tree list) ref

  (* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)     
  (* Compute Dom(.) function for a graph
     -- where Dom(.) has type D.t
     -- uses quadratic algorithm, (Fig 7.14 from Muchnick 1997) *)
  let dominators (nodes:S.t) (root:N.t) : (D.t) =
    let debug = if false then out else no_out in  
    let nonroot_nodes = S.remove root nodes in
    
    (* Initialize dom:
       1, dom(root) = {root}. 
       2. For all non-root nodes $n$, $dom(n)$ = nodes.
    *)  
    let dom = ref D.empty in
    let _ = dom := (D.set root root !dom) in
    let _ = S.iter (fun node -> dom := (D.M.add node nodes !dom))
      nonroot_nodes 
    in                                                
    let change = ref false in

    (* Visit a node and estimate its dominators based on the
       dominators of its predecessors *)
    let visit_node node =
      let dom0 = !dom in
      let node_dom = (D.find node !dom) in
      let node_dom' = (List.fold_left 
                         (fun node_dom' pred -> 
                            let pred_dom = D.find pred !dom in
                            (S.inter node_dom' pred_dom))
                         node_dom (N.preds node))
      in
      let node_dom' = S.add node node_dom' in
      if not (S.equal node_dom' node_dom) then begin
        change := true ; 
        dom := D.M.add node node_dom' !dom ;
      end
    in
    (* Loop until no change *)
    let rec loop _ =  
      begin
        change := false ;
        (S.iter visit_node nonroot_nodes) ;
        if !change then loop () else ()
      end
    in 
    (loop () ; !dom)

  (* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
  (* Compute immediate dominators 
     -- uses quadratic algorithm, (Fig 7.15 from Muchnick 1997) *)
  let immediate_dominators (nodes:S.t) (root:N.t) (dom:D.t) : idom_map =
    let debug = if false then no_out else no_out in  
    let nonroot_nodes = S.remove root nodes in
    
    (*
      let string_of_node1 node = sprintf "\n  %d" node.node_id in
      let string_of_node2 node = sprintf "%d" node.node_id in
    *)
    
    (* Initially: tmp_dom(node) = (dom(node) - {node}). *)
    let tmp_dom = ref D.empty in
    let _ = (S.iter 
               (fun node -> 
                  let node_dom = D.find node dom in
                  let node_dom' = S.remove node node_dom in
                  tmp_dom := (D.M.add node node_dom' !tmp_dom))
               nodes)
    in
    (* Visit a node and two of its distict dominators *)
    let visit_node node node_dom1 node_dom2 =
      if S.mem node_dom2 (D.find node_dom1 !tmp_dom) then
        tmp_dom := (D.remove node node_dom2 !tmp_dom)
    in  
    begin 
      (*
        debug "dominators: %s" (D.to_string string_of_node1 string_of_node2 dom) ;
        debug "idom, init: %s" (D.to_string string_of_node1 string_of_node2 !tmp_dom) ;
      *)
      let iter nodes fn = S.iter fn nodes in
      (* Consider all basic nodes and all choices of two distict
         dominators *)
      (iter nonroot_nodes 
         (fun node -> iter (D.find node !tmp_dom)
            (fun node_dom1 -> iter (D.find node !tmp_dom)
               (fun node_dom2 -> if not (node_dom1 == node_dom2) then
                  (visit_node node node_dom1 node_dom2))))) ;    
      (*
        debug "idom, done: %s" (D.to_string string_of_node1 string_of_node2 !tmp_dom) ;
      *)
      (* Assert that all nodes now have a unique immediate dominator
         and create and return such a mapping for the nodes *)
      (S.fold 
         (fun node (idoms : idom_map) -> 
            let node_idoms = D.find node !tmp_dom in
            let node_idom1 = S.min_elt node_idoms in
            let node_idom2 = S.max_elt node_idoms in
            if node_idom1 == node_idom2 then 
              (M.add node node_idom1 idoms) 
            else 
              raise Hell)
         nonroot_nodes M.empty)
    end

  (* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
  (* Compuate a dominator tree given a root node and a immediate
     dominator mapping *)
  let dominator_tree (root:N.t) (idom:idom_map) : dom_tree =
    let tree_root = (Dom_tree(root, ref [])) in
    let tree_map = ref (M.add root tree_root M.empty) in  
    (* Find or create a tree for [node] *)
    let find_tree node =
      if M.mem node !tree_map 
      then M.find node !tree_map 
      else 
        let tree = Dom_tree(node, ref []) in 
        tree_map := M.add node tree !tree_map ; 
        tree    
    in
    (* Visit a mapping, which we make into an edge in the tree *)
    let visit_map_instance node node_dom =
      (* Find the list to insert node into *)
      let Dom_tree(_, subtrees) = find_tree node_dom in
      let node_tree = find_tree node in
      subtrees := node_tree :: (!subtrees)
    in
    let _ = M.iter visit_map_instance idom in
    tree_root

  (* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
  (* Given a dominator tree, return a list of subsets describing the
     corresponding partition of the nodes (the subsets are pair-wise
     disjoint, the subsets cover the nodes, excluding the root).  The
     partition is such for every two nodes $n_1$ and $n_2$ from
     distinct subsets, $n_1 \notin \dom(n_2)$ (and vice versa).  *)
  let dom_tree_subtrees (dom_tree:dom_tree) : ((N.t * S.t) list) =
    let rec collect_dominated (nodes:S.t) (dom_tree:dom_tree) : S.t =
      let Dom_tree(node0, subtrees) = dom_tree in
      let nodes = S.add node0 nodes in
      (List.fold_left collect_dominated nodes !subtrees)
    in
    let Dom_tree(_, subtrees) = dom_tree in
    (List.map (fun (Dom_tree(node0, _) as dom_tree) -> 
                 (node0, collect_dominated S.empty dom_tree)) !subtrees)

  (* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
  (* Print a dominator tree *)
  let print_dom_tree_graph (name:string) (dom_tree:dom_tree) =
    let f = open_out (name ^ ".domtree.dot") in
    let _ = fprintf f "digraph %s {\nsize=\"6,8\";\n" name in
    let rec crawl dom_tree =
      let Dom_tree(node, subtrees) = dom_tree in
      fprintf f "node_%s [label=\"%s\"];\n" (N.name node) (N.name node) ;
      List.iter 
        begin fun dom_tree' -> 
          let Dom_tree(node', _)  = dom_tree' in
          crawl dom_tree' ;
          fprintf f "node_%s -> node_%s\n" (N.name node) (N.name node') ;
        end
        !subtrees 
    in
    let _ = crawl dom_tree in
    let _ = fprintf f "}\n" in
    let _ = close_out f in
    ()
      
end
