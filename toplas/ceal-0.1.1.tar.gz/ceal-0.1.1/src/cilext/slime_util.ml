open Cil
open Trace
open Printf

module P = Pretty
module IH = Inthash
module H = Hashtbl
module E = Errormsg
exception Hell
exception Heck of string
exception Error of string

(* SLIME flags *)
let slime_print_dot = ref 0
let slime_elab_closure_elim = ref 1
let slime_elab_hash_buffer = ref 1
  

(* Print some debugging output. *)
let out (fmt : ('a,unit,P.doc) format) : 'a = 
  let f d = 
    ignore (P.eprintf "%t: slime: %a@!" d_thisloc P.insert d);
    P.nil
  in
  P.gprintf f fmt

(* Don't print anything. *)
let no_out (fmt : ('a,unit,P.doc) format) : 'a = 
  let f d = P.nil in
  P.gprintf f fmt

(* Map for Cil statements *)
module Stmtmap = Map.Make
  (struct 
     type t = stmt
     let compare stmt1 stmt2 = compare stmt1 stmt2
   end)

(* Variables -- for Sets and Maps. *)
module Var = struct 
  type t = varinfo
  let compare v1 v2 = compare v1 v2
end

(* Variable Sets and Maps *)
module Varset = Set.Make(Var)
module Varmap = Map.Make(Var)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Collect all the variables that are used. *)
class collect_used_vars () = object(self)
  inherit nopCilVisitor
  val mutable vars = Varset.empty
  method get_vars () = vars
  method vvrbl (varinfo:varinfo) : varinfo visitAction = begin
    vars <- Varset.add varinfo vars ;
    DoChildren
  end
end

(* Return a set of variables that are used in the given expression *)
let exp_vars (exp:exp) = 
  let collector = (new collect_used_vars ()) in
  let _ = visitCilExpr (collector :> cilVisitor) exp in
  collector#get_vars ()

(* Same as [exp_vars] except lifted to optional expressions *)
let expop_vars (expop:exp option) =
  match expop with 
      None -> Varset.empty
    | Some exp -> exp_vars exp

(* Save as [exp_vars] except lifted to lists of expressions *)
let exps_vars (exps: exp list) =
  List.fold_left 
    (fun vars exp -> Varset.union vars (exp_vars exp)) 
    Varset.empty exps

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Map_set -- Mappings from one ordered type to sets of another
 * ordered type -- offers useful operations [find, set, add, combine,
 * to_string] that are all applicative (purely functional). *)
module Map_set (M:Map.S) (S:Set.S) = 
struct 
  module M = M
  module S = S
  type t = S.t M.t
      
  let empty = M.empty
    
  let find x m = 
    if M.mem x m then M.find x m else S.empty
      
  let set x y m = 
    M.add x (S.singleton y) m
      
  let add x y m =
    let ys = find x m in
    let ys = S.add y ys in
    M.add x ys m

  let remove x y m =
    let ys = find x m in
    let ys = S.remove y ys in
    M.add x ys m
      
  let equal m1 m2 =
    M.equal (S.equal) m1 m2

  let combine m1 m2 =
    M.fold (fun x ys1 m -> 
              let ys2 = find x m2 in
              let ys = S.union ys1 ys2 in
              (M.add x ys m)) m1 m2

  let to_string string_of_x string_of_y m =
    "{"^(M.fold       
           (fun x ys str -> 
              let string_of_ys ys = 
                (S.fold 
                   (fun y str -> 
                      let y_str = string_of_y y in
                      (if str <> "" then str^", "^y_str else y_str)) ys "")
              in
              let str' = (sprintf "%s->{%s}" (string_of_x x) (string_of_ys ys)) in
              if str <> "" then str^", "^str' else str')
           m "")^"}"
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let make_fundec (v:varinfo) =
  { svar = v;
    smaxid = 0;
    slocals = [];
    sformals = [];
    sbody = mkBlock [];
    smaxstmtid = None;
    sallstmts = [];
  } 

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Get the offset of projecting into a type by a series of field names *)
let rec proj (typ:typ) (fnames:string list) : offset =
  
  let cantproject fnames =
    let fnames = List.fold_left 
      (fun fnames fname ->
         if fnames <> "" then fnames^"; "^fname else fname) "" fnames
    in
    raise (Heck ("can't project ["^fnames^"] from given type"))
  in

  let rec walk (compinfo:compinfo) (fnames:string list) : offset =
    match fnames with
        [] -> NoOffset
      | fname::fnames ->
          let field = 
            try
              (List.find (fun field -> field.fname = fname) 
                 compinfo.cfields)
            with Not_found -> 
              raise (Heck ("couldn't find field "^fname^
                             " in "^compinfo.cname))
          in 
          match (field.ftype, fnames) with
            | (_, []) -> 
                Field(field, NoOffset)
                  
            | (TComp(compinfo, _),  _) ->
                let offset = walk compinfo fnames in
                Field(field, offset)
                  
            | (TNamed({ttype=typ}, _), _) ->
                let offset = proj typ fnames in
                Field(field, offset)
                  
            | _ -> cantproject (fname::fnames)
  in
  match typ with
    | TComp(compinfo, _) -> walk compinfo fnames
    | TNamed({ttype=typ}, _) -> proj typ fnames
    | _ -> cantproject fnames

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Get the last fieldinfo of a given offset *)
let rec proj_field (offset:offset) : fieldinfo =
  match offset with 
    | Field(field, NoOffset) -> field
    | Field(field, offset) -> proj_field offset
    | _ -> raise (Heck "offset contains non-field")

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let count_formals (init_funvar:varinfo) =
  let argtyps = match init_funvar.vtype with 
    | TFun(_, argtyps, _,_)  -> argtyps 
    | _ -> raise Hell in
  match argtyps with 
    | None -> 0
    | Some xs -> List.length xs

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let rec first_n_of_list (xs:'a list) (n:int) =
  if n < 0 
  then raise Hell 
  else
    match (n, xs) with 
      | (0, _) -> []
      | (n, x::xs) -> x :: (first_n_of_list xs (n-1))

