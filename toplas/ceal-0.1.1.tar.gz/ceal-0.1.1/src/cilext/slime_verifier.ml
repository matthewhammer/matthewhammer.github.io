open Printf
open Cil
open Slime_util
open Slime_api
open Slime_cfg
open Slime_program
open Slime_callgraph
open Slime_block
open Slime_closure
open Slime_codeloc

let debug = if false then out else no_out

exception No_verifier of string
exception No_verifier_fundec of string

let get_verifier_fundec (fn:sac_function) : fundec =
  match fn.fn_verif with
    | Some (_, Some(_, fundec)) -> fundec
    | _ -> raise (No_verifier_fundec fn.fn_varinfo.vname)

let get_verifier_cfg (fn:sac_function) : sac_cfg =
  match fn.fn_verif with
    | Some (_, Some(cfg, _)) -> cfg
    | _ -> raise (No_verifier_fundec fn.fn_varinfo.vname)

let get_verifier_varinfo (fn:sac_function) : varinfo =
  match fn.fn_verif with
    | Some (varinfo, _) -> varinfo
    | _ -> raise (No_verifier fn.fn_varinfo.vname)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let elaborate_verifier (fn:sac_function) =  
  let _ = debug "elaborating verifier: %s" fn.fn_varinfo.vname in
  
  let null = CastE(voidPtrType,zero) in
  
  (* Make a new local temporary for the elaborated function. *)
  let make_temp_var (typ:typ) : varinfo =
    let fundec = get_verifier_fundec fn in
    (makeTempVar fundec typ)
  in

  let exp_of_var var = 
    Lval(Var var, NoOffset) in

  let exp_of_expop expop = 
    match expop with 
        Some exp -> exp 
      | None -> raise Hell
  in    

  (* Elaborate an optional definition into an optional lval *)
  let elab_defop (defop:sac_def option) : lval option =
    match defop with 
        None -> None
      | Some def -> Some def.df_lval
  in

  (* Elaborate a list of arguments -- all the readargs are elaborated
     as dereferences where the dereferenced value and modifiable being
     dereferenced are both included. *)
  let rec elab_args (args:sac_arg list) : exp list =
    match args with
      | [] -> []
      | arg::args -> begin
          match arg with
              Sac_exp(exp) -> exp :: (elab_args args)
            | Sac_readarg(exp) -> raise Hell
        end
  in
  
  (* Elaborate a list of instructions *)
  let rec elab_instrs (instrs:sac_instr list) : instr list =
    match instrs with
        [] -> []
          
      (* Set *)
      | (Sac_set(def,loc))::instrs ->
          (Set(def.df_lval, exp_of_expop def.df_exp, loc))
          ::(elab_instrs instrs)
            
      (* Self-adjusting Call *)
      | (Sac_call(funvar, args, loc))::instrs ->
          let (gn, _) = lookup_self_function funvar in
          let gn_varinfo = get_verifier_varinfo gn in
          (Call(None, exp_of_var gn_varinfo, elab_args args, locUnknown))
          ::(elab_instrs instrs)
            
      (* Write *)
      | (Sac_call_ord(defop, funvar, exps, loc))::instrs 
          when funvar == (api_varinfo "write") ->
          (Call(elab_defop defop, exp_of_var (api_varinfo "verif_modref_write"), exps, loc))
          ::(elab_instrs instrs)
            
      (* Ordinary Call *)
      | (Sac_call_ord(defop, funvar, exps, loc))::instrs ->
          if (check_function funvar) then
            let gn = (lookup_function funvar) in
            let gn_varinfo = get_verifier_varinfo gn in
            (Call(elab_defop defop, exp_of_var gn_varinfo, exps, loc))
            ::(elab_instrs instrs)
          else
            (Call(elab_defop defop, exp_of_var funvar, exps, loc))
            ::(elab_instrs instrs)

      (* Indirect Call *)
      | (Sac_call_ind(defop, funexp, exps, loc))::instrs ->
          (Call(elab_defop defop, funexp, exps, loc))
          ::(elab_instrs instrs)
            
      (* Allocation *)
      | (Sac_alloc (def, size_exp, init_funvar, key_exps, loc))::instrs ->
          let (gn, _) = lookup_init_function init_funvar in
          let gn_varinfo = get_verifier_varinfo gn in
          let instr1 = Call(Some def.df_lval, 
                            exp_of_var(api_varinfo "verif_block_alloc"),
                            [size_exp], locUnknown) 
          in
          let inst_args = first_n_of_list (key_exps) 
            ((count_formals gn_varinfo) - 1) 
          in 
          let instr2 = Call(None, exp_of_var gn_varinfo, 
                            (Lval def.df_lval) :: inst_args, 
                            locUnknown)
          in
          instr1::instr2::(elab_instrs instrs)
            
      (* Modifiable *)            
      | (Sac_modref (def, key_exps, loc))::instrs ->
          let size_exp = SizeOf(api_typ "modref_t") in          
          let init_funvar = api_varinfo "verif_modref_init" in
          let instr1 = Call(Some def.df_lval, 
                            exp_of_var(api_varinfo "verif_block_alloc"),
                            [size_exp], locUnknown) 
          in
          let instr2 = Call(None, exp_of_var init_funvar, 
                            (Lval def.df_lval) :: key_exps, 
                            locUnknown)
          in
          instr1::instr2::(elab_instrs instrs)
  in
  
  (* Given formals and actuals for a tailcall, make instructions to do
     the "substitution" required to turn the call into a goto *)
  let make_tailcall_assignments 
      (varinfos:varinfo list) 
      (exps: exp list) 
      : (instr list * exp list)
      =
    let rec loop 
        (varinfos:varinfo list) 
        (exps:exp list)         
        : (instr list * instr list * exp list)
        = 
      match (varinfos, exps) with
        | ([], []) -> ([], [], [])
        | ([], _) -> invalid_arg (sprintf "make_tailcall_assignments: %s" fn.fn_varinfo.vname)
        | (_, []) -> invalid_arg (sprintf "make_tailcall_assignments: %s" fn.fn_varinfo.vname)
        | (varinfo::varinfos, exp::exps) ->
            let (instrs1_rest, instrs2_rest, exps_rest) = loop varinfos exps in
            let typ = typeOf exp in
            let tmp = make_temp_var typ in
            let instr1 = (Set ((Var tmp, NoOffset), exp, locUnknown)) in
            let instr2 = (Set ((Var varinfo, NoOffset), Lval(Var tmp, NoOffset), locUnknown)) in
            ( instr1::instrs1_rest,
              instr2::instrs2_rest,
              (Lval (Var tmp, NoOffset))::exps_rest)
    in
    let (instrs1, instrs2, exps) = (loop varinfos exps) in
    (instrs1 @ instrs2, exps)
  in

  (* Elaborate a terminal instruction *)
  let rec elab_term 
      (bb_stmt_map:stmt Sac_bb_map.t) 
      (term:sac_term) 
      : stmt list 
      =
    match term with
        (* If *)
        Sac_if (exp, term1, term2, loc) ->
          let block1 = mkBlock (elab_term bb_stmt_map term1) in
          let block2 = mkBlock (elab_term bb_stmt_map term2) in
          [mkStmt (If (exp, block1, block2, loc))]

      (* Read *)
      | Sac_read (def,term1,loc) -> 
          let modref_exp = match def.df_exp with 
            | Some x -> x 
            | None -> raise Hell 
          in
          let stmt = mkStmt 
            (Instr [Call(Some def.df_lval, 
                         exp_of_var (api_varinfo "verif_modref_read"), 
                         [modref_exp], locUnknown)])
          in
          stmt :: (elab_term bb_stmt_map term1)

      (* Tailcall *)
      | Sac_tailcall (funvar, args, loc) ->
          let (gn, _) = lookup_self_function funvar in
          let (fn_cfg, fn_fundec) = 
            ((get_verifier_cfg fn), 
             (get_verifier_fundec fn)) 
          in
          begin match gn.fn_verif with
            | Some (gn_varinfo, Some(gn_cfg, gn_fundec)) when fn_fundec == gn_fundec ->
                (* If fn == gn then we turn the call into a local goto *)
                let formals = gn_fundec.sformals in
                let (instrs, args) = make_tailcall_assignments formals (elab_args args) in
                let stmt0 = Sac_bb_map.find gn_cfg.cfg_bb0 bb_stmt_map in
                [mkStmt (Instr instrs);
                 mkStmt (Goto ((ref stmt0), locUnknown))]
            
            | Some (gn_varinfo, _) ->
                (* Otherwise, do a regular call *)
                [mkStmt (Instr [Call(None, exp_of_var gn_varinfo, elab_args args, locUnknown)]);
                 mkStmt (Return (None, locUnknown))]
            
            | _ -> raise (No_verifier gn.fn_varinfo.vname)
          end
            
      (* Goto *)
      | Sac_goto (bb_ref, loc) ->
          let bb_stmt = Sac_bb_map.find !bb_ref bb_stmt_map in
          [mkStmt (Goto(ref bb_stmt, loc))]
            
      (* Return *)
      | Sac_return (expop, loc) -> 
          [mkStmt (Return(expop, loc))]
  in

  (* Elaborate a basic block *)
  let elab_basic_block 
      (bb_stmt_map:stmt Sac_bb_map.t) 
      (bb:sac_basic_block) 
      : stmt 
      =
    begin
      let stmt = Sac_bb_map.find bb bb_stmt_map in
      let instrs = elab_instrs bb.bb_instrs in
      let instrs_stmt = mkStmt (Instr instrs) in
      let term_stmts = elab_term bb_stmt_map bb.bb_term in
      let block = mkBlock (instrs_stmt::term_stmts) in
      stmt.skind <- Block block ;      
      stmt
    end 
  in
  
  (* Elaborate a CFG. *)
  let elab_cfg (cfg:sac_cfg) : block =

    let bb_stmt_map = Slime_cfg.bb_stmt_map cfg in
    
    let bbs_stmts = Sac_bb_set.fold 
      (fun bb stmts -> (elab_basic_block bb_stmt_map bb)::stmts) 
      cfg.cfg_bbs []
    in
    
    let entry_stmt = 
      let bb0_stmt = Sac_bb_map.find cfg.cfg_bb0 bb_stmt_map in
      mkStmt (Goto (ref (bb0_stmt), locUnknown))
    in

    (mkBlock (entry_stmt :: bbs_stmts))
  in  
  begin
    match fn.fn_verif with
      | Some(_, Some (cfg, fundec)) -> (fundec.sbody <- elab_cfg cfg)
      | _ -> ()
  end

let verifier_prototype (fn:sac_function) : global =
  match fn.fn_verif with 
    | Some (varinfo, _) -> GVarDecl (varinfo, locUnknown)
    | _ -> GText ("/* No verifier (prototype). */")

let verifier_definition (fn:sac_function) : global =
  match fn.fn_verif with 
    | Some (_, Some(_, fundec)) -> GFun (fundec, locUnknown)
    | _ -> GText ("/* No verifier (definition). */")

class expand_verif_macro () = object(self)
  inherit nopCilVisitor
  method vexpr (exp:exp) : exp visitAction = begin
    match exp with 
      | CastE(typ, AddrOf(Var funvar, NoOffset)) -> 
          let typ = unrollType typ in
          let attrs = (typeAttrs typ) in
          if hasAttribute "slime_verif" attrs then
            let _ = debug "expand: found: %s" funvar.vname in
            let fn = lookup_function funvar in
            let fn_varinfo = get_verifier_varinfo fn in
            ChangeTo (Lval (Var fn_varinfo, NoOffset))
          else
            DoChildren
      | _ -> 
          DoChildren
  end
end
    
class expand_isverif_macro () = object(self)
  inherit nopCilVisitor    
    
  (* Keep track of the "current" function during traversal. *)
  val mutable current_fundec = None      
  method vfunc (fundec:fundec) = 
    (current_fundec <- Some fundec ; DoChildren)

  (* If the current function is a verifier, replace with 1, else
     replace with 0 *)
  method vexpr (exp:exp) = begin
    match exp with
      | Lval(Var var, NoOffset) when 
          var == (api_varinfo "__ISVERIF__") ->
          let fundec = match current_fundec with 
              None -> raise Hell
            | Some fundec -> fundec in
          if Varset.mem fundec.svar !verif_functions_by_var then
            ChangeTo one
          else
            ChangeTo zero
      | _ -> DoChildren
  end
end
