(* SAC Control-Flow Graphs *)
open Cil
open Slime_api
open Slime_util
open Printf

exception Hell
exception Not_implemented of string
exception Bug of string
exception Missing_proto of varinfo
  
(* Instructions *)
type sac_instr = 
    Sac_set of sac_def * location
  | Sac_call of varinfo * sac_arg list * location
  | Sac_call_ord of sac_def option * varinfo * exp list * location
  | Sac_call_ind of sac_def option * exp * exp list * location
  | Sac_alloc of sac_def * exp * varinfo * exp list * location
  | Sac_modref of sac_def * exp list * location

(* Arguments *)
and sac_arg =
    Sac_exp of exp
  | Sac_readarg of exp
      
(* Terminal Instructions *)
and sac_term =
  | Sac_if of exp * sac_term * sac_term * location
  | Sac_read of sac_def * sac_term * location
  | Sac_tailcall of varinfo * sac_arg list * location
  | Sac_goto of sac_basic_block ref * location
  | Sac_return of exp option * location

(* Defs -- generalize def-like aspects of Sac_read, Sac_set,
   Sac_call*. We use these to do reaching-def analysis for moving
   read-defs into argument-position of Sac_call and Sac_tailcall. *)
and sac_def =
    { mutable df_bb : sac_basic_block ;
      mutable df_id : int ;
      mutable df_lval : lval ;
      mutable df_exp : exp option ;
      mutable df_is_used : bool ;
      mutable df_is_read : bool ;
    }

(* Basic blocks *)
and sac_basic_block = 
    { mutable bb_id : int ;
      mutable bb_instrs : sac_instr list ;
      mutable bb_term : sac_term ;
      mutable bb_preds : sac_basic_block list ;
      mutable bb_succs : sac_basic_block list ;
      mutable bb_max_def_id : int ;
    }

(* Basic blocks -- for Maps and Sets *)
module Sac_basic_block = 
struct 
  exception Comparison_error of int * int
  type t = sac_basic_block
  let compare bb1 bb2 = 
    if bb1.bb_id <> bb2.bb_id then
      bb2.bb_id - bb1.bb_id
    else
      if bb1 == bb2 then 0
      else raise (Comparison_error (bb1.bb_id, bb2.bb_id))
  let preds bb = bb.bb_preds
  let name bb = sprintf "%d" bb.bb_id
end

(* Defs -- for Maps and Sets *)
module Sac_def =
struct 
  type t = sac_def
  let compare def1 def2 = compare def1 def2
end

(* Sets and Maps *)
module Sac_bb_set = Set.Make(Sac_basic_block)
module Sac_bb_map = Map.Make(Sac_basic_block)
module Sac_def_set = Set.Make(Sac_def)

(* Dominators *)
module Sac_bb_dom = Slime_dominator.Make(Sac_basic_block)

(* CFGs *)
type sac_cfg = 
    { mutable cfg_kind : sac_cfg_kind ;
      mutable cfg_bb0 : sac_basic_block ;
      mutable cfg_bbs : Sac_bb_set.t ;
      mutable cfg_max_bb_id : int ;
    }

and sac_cfg_kind = 
  | Sac_cfg_self
  | Sac_cfg_meta
  | Sac_cfg_init
  | Sac_cfg_verf

(* Used to build a CFG -- the term context keeps track of which terms
   to use where. *)
type term_context = { 
  tcxt_term : sac_term option ;
  tcxt_continue : sac_term option ;
  tcxt_break : sac_term option
}

let make_basic_block id = 
  { bb_id = id;
    bb_instrs = [];
    bb_term = Sac_return (None, locUnknown);
    bb_preds = [];
    bb_succs = []; 
    bb_max_def_id = 0;
  } 

let make_def ?(is_read=false) ?(expop=None) bb lval =
  let id = bb.bb_max_def_id in 
  let _  = bb.bb_max_def_id <- bb.bb_max_def_id + 1 in
  { df_bb = bb; 
    df_id = id; 
    df_lval = lval;
    df_exp = expop;
    df_is_used = false;
    df_is_read = is_read;
  }

let dummy_cfg (kind:sac_cfg_kind) : sac_cfg = 
  let bb0 = make_basic_block (-1) in 
  {
    cfg_kind = kind ;
    cfg_bb0 = bb0 ;
    cfg_bbs = Sac_bb_set.singleton bb0 ;
    cfg_max_bb_id = 0;
  }

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Compute the edges of a CFG.  Modifies the CFG in-place. *)
let compute_edges (cfg:sac_cfg) : unit =
  
  (* Clear all succ/pred info *)
  let clear_basic_block (bb:sac_basic_block) =
    bb.bb_succs <- [] ;
    bb.bb_preds <- [];
  in  
  let _ = Sac_bb_set.iter 
    (fun bb -> clear_basic_block bb) cfg.cfg_bbs in

  (* Compute succ/pred info corresponding to a term *)
  let touch_basic_block (bb1:sac_basic_block) = 
    let rec handle_term (term:sac_term) =
      match term with
          Sac_if(_, term1, term2, _) -> begin 
            handle_term term1; 
            handle_term term2 
          end
        | Sac_read(_, term1, _) -> begin
            handle_term term1
          end
        | Sac_tailcall _ -> ()
        | Sac_return _ -> ()
        | Sac_goto (bb2, _) -> begin
            let bb2 = !bb2 in
            bb1.bb_succs <- bb2 :: bb1.bb_succs ;
            bb2.bb_preds <- bb1 :: bb2.bb_preds ;
          end
    in
    (handle_term bb1.bb_term)
  in
  (Sac_bb_set.iter 
     (fun bb -> touch_basic_block bb) cfg.cfg_bbs)  

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Maps variables to sets of definitions -- provides some useful
   operations on these mappings.  All the operations are applicative
   (purely-functional). *)
module Var_defs_map = struct  
  module VDM = Map_set (Varmap) (Sac_def_set)    
    
  type t = VDM.t
      
  let empty = VDM.empty
  let find = VDM.find 
  let equal = VDM.equal
  let combine = VDM.combine
    
  let set def vdm = 
    match def.df_lval with
        (Var var, NoOffset) -> VDM.set var def vdm
      | _ -> vdm
  
  let add def vdm = 
    match def.df_lval with
        (Var var, NoOffset) -> VDM.add var def vdm
      | _ -> vdm
    
  let to_string vdm =
    let string_of_var var = var.vname in
    let string_of_def def = sprintf "%d" def.df_bb.bb_id in
    (VDM.to_string string_of_var string_of_def vdm)
      
  (* Transfer Function *)
  (* Given defs at [bb1], compute the defs that flow to [bb2] *)
  let transfer (vdm : t) (bb1:sac_basic_block) (bb2:sac_basic_block) : t = begin

    (* Get an (optional) definition from an instruction *)
    let def_of_instr (instr:sac_instr) 
        : (sac_def option) =
      match instr with
          Sac_set (def, _) -> Some def
        | Sac_call _ -> None
        | Sac_call_ord (defop, _, _, _) -> defop
        | Sac_call_ind (defop, _, _, _) -> defop
        | Sac_alloc (def, _, _, _, _) -> Some def
        | Sac_modref (def, _, _) -> Some def
    in    
    
    (* Process all the instructions *)
    let vdm = List.fold_left 
      (fun vdm instr -> 
         let defop = def_of_instr instr in
         match defop with 
             Some def -> 
               set def vdm
           | None -> vdm)
      vdm (bb1.bb_instrs)
    in
    
    (* Walk over the term of bb1 and find out which defs reach bb2. *)
    let rec walk_term (vdm : t) (term:sac_term) : t =
      match term with
          Sac_if (_, term1, term2, _) -> 
            let vdm1 = walk_term vdm term1 in
            let vdm2 = walk_term vdm term2 in
            (combine vdm1 vdm2)
              
        | Sac_read (def, term1, _) -> 
            let vdm = set def vdm in
            (walk_term vdm term1)              

        | Sac_goto (target_bb, _) -> 
            if !target_bb == bb2 then vdm 
            else empty       
       
        | Sac_tailcall _ -> empty              
        | Sac_return _ -> empty
    in
    (* Walk over the term *)
    (walk_term vdm bb1.bb_term)
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Store and update the reaching-defs for a CFG.         *)
module Cfg_defs = struct
  
  (* t =~= Blocks --> VDMs *)
  (* Where VDM =~= Set-of-reaching-definitions *)
  type t = (Var_defs_map.t Sac_bb_map.t) ref
      
  let create () = 
    ref Sac_bb_map.empty
  
  (* Lookup the reaching-defs for the given basic-block *)
  let find cfg_defs bb =
    if Sac_bb_map.mem bb !cfg_defs then 
      Sac_bb_map.find bb !cfg_defs
    else 
      Var_defs_map.empty

  (* Add one reaching-def for the given BB. *)
  let add_one cfg_defs bb def =
    let vdm = find cfg_defs bb in
    let vdm = Var_defs_map.add def vdm in
    (cfg_defs := Sac_bb_map.add bb vdm !cfg_defs)

  (* Add a bunch of reaching-defs for the given BB. *)
  let add_all cfg_defs bb vdm' =
    let vdm = find cfg_defs bb in
    let vdm = Var_defs_map.combine vdm vdm' in
    (cfg_defs := Sac_bb_map.add bb vdm !cfg_defs)
end

  
(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Compute reaching definitions for a CFG -- we use these to copy read
   definitions used as arguments to function calls into [Sac_readarg]
   arguments. *)
let compute_reaching_defs (cfg:sac_cfg) =

  let debug = if false then out else no_out in  
  let cfg_defs = Cfg_defs.create () in

  (* the work queue -- initially it contains all basic-blocks except
     the intial block. *)
  let work_queue = Queue.create () in
  let _ = Sac_bb_set.iter 
    (fun bb -> if not (bb == cfg.cfg_bb0) then Queue.add bb work_queue) 
    cfg.cfg_bbs 
  in

  (* Loop until the queue is empty *)
  let rec loop _ =
    begin if not (Queue.is_empty work_queue) then
      let bb = Queue.pop work_queue in
      let vdm_old = Cfg_defs.find cfg_defs bb in
      let _ = debug "%d: popped." bb.bb_id in
      
      (* Visit each predecessor of [bb] *)
      let visit_pred pred = 
        let _ = debug "  visiting pred: %d" pred.bb_id in
        let vdm = Cfg_defs.find cfg_defs pred in
        let vdm = Var_defs_map.transfer vdm pred bb in
        (Cfg_defs.add_all cfg_defs bb vdm)
      in      
      List.iter visit_pred bb.bb_preds ;
      
      (* Has the varmap for [bb] changed? *)
      let vdm_new = Cfg_defs.find cfg_defs bb in

      debug "  old : %s" (Var_defs_map.to_string vdm_old) ;
      debug "  new : %s" (Var_defs_map.to_string vdm_new) ;
      
      if not (Var_defs_map.equal vdm_old vdm_new) then begin
        List.iter (fun succ -> 
                     debug "  adding succ: %d" succ.bb_id ;
                     Queue.push succ work_queue) bb.bb_succs
      end ;
      loop ()
    end
  in
  (loop (); cfg_defs)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Return a set of variables that are free in the given set of basic
   blocks *)
let compute_free_vars (bbs:Sac_bb_set.t) =
  let vars = ref Varset.empty in    
  let add var = vars := Varset.add var !vars in  
  let add_all vars' = vars := Varset.union vars' !vars in
  
  let visit_arg arg = 
    match arg with
        Sac_exp exp -> add_all (exp_vars exp)
      | Sac_readarg exp -> add_all (exp_vars exp)
  in
  
  let visit_def def =
    add_all (expop_vars def.df_exp) ;
    match def.df_lval with
        (Var var, NoOffset) -> add var
      | _ -> ()
  in
  
  let visit_defop defop = 
    match defop with 
        Some def -> visit_def def
      | None -> ()
  in

  let visit_instr (instr:sac_instr) = 
    match instr with
        Sac_set (def, _) -> 
          visit_def def
      
      | Sac_call (funvar, args, _) -> 
          add funvar; 
          List.iter visit_arg args

      | Sac_call_ord (defop, funvar, exps, _) -> 
          visit_defop defop;
          add funvar;
          add_all (exps_vars exps)

      | Sac_call_ind (defop, funexp, exps, _) -> 
          visit_defop defop;          
          add_all (exp_vars funexp) ; 
          add_all (exps_vars exps)

      | Sac_alloc (def, size_exp, initvar, keys, _) ->
          visit_def def;
          add_all (exp_vars size_exp);
          add_all (exps_vars keys) ;

      | Sac_modref (def, keys, _) ->
          visit_def def;
          add_all (exps_vars keys)
  in
  let rec visit_term (term:sac_term) =
    match term with
        Sac_if(exp, term1, term2, _) ->
          add_all (exp_vars exp) ;
          visit_term term1 ;
          visit_term term2 ;
      
      | Sac_read (def, term1, _) ->
          add_all (expop_vars def.df_exp) ;
          visit_term term1 
      
      | Sac_tailcall (funvar, args, _) ->
          List.iter visit_arg args
      
      | Sac_goto _ -> ()
      
      | Sac_return (expop, _) ->
          add_all (expop_vars expop)
  in
  let visit_basic_block (bb:sac_basic_block) =
    List.iter visit_instr bb.bb_instrs ;
    visit_term bb.bb_term
  in  
  (Sac_bb_set.iter visit_basic_block bbs) ;
  !vars

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Compute the live variables at each basic-block of the given CFG. *)
let compute_live_vars (cfg:sac_cfg) : Varset.t Sac_bb_map.t =
  let debug = if false then out else no_out in
    
  let cfg_live = ref Sac_bb_map.empty in  
  
  (* Get the live variables for a basic-block *)
  let get_live bb = Sac_bb_map.find bb !cfg_live in

  (* Set the live variables for a basic-block -- returns [true] if the
     live variables for the given basic block have changed; returns
     [false] otherwise. *)
  let set_live bb (vars:Varset.t) = 
    let vars0 = get_live bb in
    if not (Varset.equal vars vars0) then
      (cfg_live := Sac_bb_map.add bb vars !cfg_live ; true )
    else false
  in
  
  (* Live variables for expressions *)
  let exp_live exp = exp_vars exp in
  let exps_live exps = exps_vars exps in
  let expop_live expop = expop_vars expop in

  (* Live variables for arguments *)
  let arg_live (arg:sac_arg) = match arg with 
      Sac_exp exp -> exp_vars exp
    | Sac_readarg exp -> exp_vars exp
  in  
  let args_live (args:sac_arg list) = 
    List.fold_left
      (fun vars arg -> Varset.union vars (arg_live arg))
      Varset.empty args
  in
  
  (* Compute the set of live variables at the basic-block terminal
     instruction -- based on (1) reads performed, (2) variables used
     in expressions, and (3) live variables at the targets of
     gotos. *)
  let rec term_live (term:sac_term) : Varset.t = 
    match term with
        Sac_if (exp, term1, term2, _) -> 
          Varset.union (exp_vars exp)
            (Varset.union (term_live term1) (term_live term2))

      | Sac_read (def, term1, _) -> 
          let def_var = match def.df_lval with
              (Var var, NoOffset) -> var
            | _ -> raise Hell
          in
          Varset.union (expop_vars def.df_exp)
            (Varset.remove def_var (term_live term1))

      | Sac_goto (bb1, _) -> (get_live !bb1)
      | Sac_tailcall (_, args, _) -> (args_live args)
      | Sac_return (expop, _) -> expop_live expop
  in  

  (* Given a set of live variables at the end of the instructions,
     compute the live variables at the start of the instructions *)
  let instrs_live 
      (instrs:sac_instr list) 
      (live_vars:Varset.t) : Varset.t 
      =    
    (* Given live variables after a given definition, compute the live
       variables before the definition *)
    let live_def (def:sac_def) (live_vars:Varset.t) =
      Varset.union (expop_vars def.df_exp) 
        (match def.df_lval with
             (Var var, NoOffset) -> (Varset.remove var live_vars)
           | _ -> live_vars)
    in
    
    (* Same as [live_def] except lifted to optional definitions *)
    let live_defop (defop:sac_def option) (live_vars:Varset.t) =
     match defop with 
         Some def -> live_def def live_vars
       | None -> live_vars
    in
    
    (* Loop over the instructions (assuming the instruction list is
       reversed from the order given by the basic block) and track
       liveness *)
    let rec loop (instrs:sac_instr list) (live_vars:Varset.t) =
      match instrs with
          [] -> live_vars
        | instr::instrs -> 
            let live_vars = match instr with
                Sac_set (def, _) -> live_def def live_vars
              
              | Sac_call (_, args, _) -> 
                  Varset.union (args_live args) live_vars
                    
              | Sac_call_ord (defop, _, exps, _) -> 
                  Varset.union (exps_live exps) (live_defop defop live_vars)
                    
              | Sac_call_ind (defop, exp, exps, _) ->
                  Varset.union (exp_live exp)
                    (Varset.union (exps_live exps) (live_defop defop live_vars))
              
              | Sac_alloc (def, size_exp, _, keys, _) -> 
                  Varset.union (exp_live size_exp)
                    (Varset.union (exps_live keys) (live_def def live_vars))

              | Sac_modref (def, keys, _) -> 
                  Varset.union (exps_live keys) (live_def def live_vars)
            in
            (loop instrs live_vars )
    in 
    (loop (List.rev instrs) (live_vars))  
  in
  
  let work_queue = Queue.create () in
  let rec loop _ =
    begin if not (Queue.is_empty work_queue) then
      let bb = Queue.pop work_queue in
      let bb_live = instrs_live bb.bb_instrs (term_live bb.bb_term) in
      let changed = set_live bb bb_live in
      let _ = if changed then List.iter 
        (fun bb1 -> Queue.push bb1 work_queue) bb.bb_preds in
      loop ()
    end
  in 
  begin
    (* Initialize workqueue and live variables for each basic-block *)
    Sac_bb_set.iter
      (fun bb -> begin
         cfg_live := Sac_bb_map.add bb Varset.empty !cfg_live ;
         Queue.add bb work_queue 
       end) cfg.cfg_bbs ;
    (* Loop until the queue is empty *)
    loop () ;
    !cfg_live
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*)
(* Update the uses of a CFG given a Cfg_defs.t *)

(* This has two actions that happen together for each basic-block [bb]:

   1.  All the read-definitions used as arguments to self-adjusting
   function calls are replaced by readarg's, when possible.  This is
   possible if the definition in question is the only reaching-
   -definition for the corresponding variable appearing as an
   argument.

   2.  All other definitions used by [bb] are marked as being used.
*)

let update_uses (cfg:sac_cfg) (cfg_defs:Cfg_defs.t)
    : unit = 
  begin
    let debug = if false then out else no_out in
    let _ = debug "running update_uses ..." in
    
    (* Set all the definitions in the basic block to "not used" *)
    let reset_basic_block (bb:sac_basic_block) =
      let reset_def (def:sac_def) = 
        def.df_is_used <- false 
      in
      let reset_defop (defop:sac_def option) = 
        match defop with 
            Some def -> reset_def def 
          | None -> ()
      in
      let reset_instr (instr:sac_instr) =
        match instr with
            Sac_set (def, _) -> reset_def def
          | Sac_call (_, _, _) -> ()
          | Sac_call_ord (defop, _, _, _) -> reset_defop defop
          | Sac_call_ind (defop, _, _, _) -> reset_defop defop
          | Sac_alloc (def, _, _, _, _) -> reset_def def
          | Sac_modref (def, _, _) -> reset_def def
      in
      let rec reset_term (term:sac_term) =
        match term with
            Sac_if(_,term1,term2,_) -> reset_term term1; reset_term term2
          | Sac_read(def, term1, _) -> reset_def def; reset_term term1
          | Sac_tailcall _ -> ()
          | Sac_return _ -> ()
          | Sac_goto _ -> ()
      in
      begin 
        List.iter reset_instr bb.bb_instrs ; 
        reset_term bb.bb_term
      end
    in
    
    (* Update the uses (and corresponding defs) found in the given basic blocks *)
    let update_basic_block (bb:sac_basic_block) =
      (* Get the reaching-defs *)
      let vdm = Cfg_defs.find cfg_defs bb in

      (* Visit an expression and update use info for all the used
         variables' definitions *)
      let visit_exp vdm exp = 
        let used_vars : Varset.t = exp_vars exp in
        let _ = debug "visiting exp" in
        (Varset.iter 
           (fun var -> 
              Sac_def_set.iter 
                (fun (def:sac_def) -> 
                   let vname = match def.df_lval with
                       (Var var, NoOffset) -> var.vname 
                     | _ -> "?"
                   in
                   let _ = debug "def {%d:%s} is used." def.df_bb.bb_id vname in
                   def.df_is_used <- true;
                ) 
                (Var_defs_map.find var vdm))
           used_vars)
      in
      
      (* Visit an optional expression *)
      let visit_expop vdm expop = 
        match expop with 
            Some exp -> visit_exp vdm exp
          | None -> ()
      in
      
      (* Visit a definition *)
      let visit_def vdm def = begin
        visit_expop vdm def.df_exp ;
        Var_defs_map.set def vdm
      end
      in

      (* Visit an optional definition *)
      let visit_defop vdm defop =
        match defop with 
            Some def -> visit_def vdm def
          | None -> vdm
      in
      
      (* Return a readvar or None if the expression is "too complicated" *)
      let rec var_of_exp (exp:exp) =
        match exp with
            Lval(Var var, NoOffset) -> Some var
          | CastE(_, exp) -> var_of_exp exp
          | _  -> None
      in

      (* Update an argument and visit expressions. *)
      let update_arg vdm arg = match arg with
          Sac_exp e -> 
            let var = var_of_exp e in
            begin match var with
                Some var -> 
                  (* Argument is a variable use. *)
                  (* If the only reaching def for the variable is a
                     read, then return a readarg -- Otherwise, leave
                     the arg alone. *)
                  let defs = Var_defs_map.find var vdm in
                  let num = Sac_def_set.cardinal defs in
                  if num = 1 then
                    let def = Sac_def_set.min_elt defs in
                    if def.df_is_read then
                      let def_exp = match def.df_exp with 
                          Some e -> e | None -> raise Hell
                      in
                      (* Only def is a read; make a readarg. *)
                      (Sac_readarg def_exp)
                        
                    else (* def isn't a read. *)
                      (visit_exp vdm e; Sac_exp e)
                        
                  else (* more than one def (or no defs if it's an argument) *)
                    (visit_exp vdm e; Sac_exp e)
              
              | None -> 
                  (* Argument is some other expression *)
                  (visit_exp vdm e ; Sac_exp e)
            end
        | Sac_readarg e -> 
            (visit_exp vdm e; Sac_readarg e)
      in
                
      (* Process an instruction, updating arguments and updating used
         defs with use info. *)
      let update_instr ((vdm, instrs) : Var_defs_map.t * (sac_instr list)) 
          (instr:sac_instr) = 
        begin          
          (* Compute a new VDM and instruction for the given instruction. *)
          let (vdm, instr) = match instr with
              (* Set. *)
              Sac_set (def, loc) -> 
                (* Update the VDM -- instr doesn't change. *)
                let vdm = visit_def vdm def in
                (vdm, Sac_set(def, loc))
                  
            (* Self-adjusting Call. *)
            | Sac_call (funvar, args, loc) -> 
                (* Update all the arguments and update the vdm. *)
                let args = List.map (update_arg vdm) args in
                (vdm, Sac_call(funvar, args, loc))

            (* Ordinary Call *)
            | Sac_call_ord (defop, funvar, exps, loc) ->
                let _ = List.iter (visit_exp vdm) exps in
                let vdm = visit_defop vdm defop in
                (vdm, Sac_call_ord (defop, funvar, exps, loc))
                  
            (* Indirect Call. *)
            | Sac_call_ind (defop, exp, exps, loc) ->
                (* Visit all the arguments and update the vdm. *)
                let _ = visit_exp vdm exp in
                let _ = List.iter (visit_exp vdm) exps in
                let vdm = visit_defop vdm defop in
                (vdm, Sac_call_ind (defop, exp, exps, loc))
                  
            (* Allocation *)
            | Sac_alloc (def, size_exp, initfun, keys, loc) ->
                let _ = visit_exp vdm size_exp in
                let _ = List.iter (visit_exp vdm) keys in
                let vdm = visit_def vdm def in
                (vdm, Sac_alloc (def, size_exp, initfun, keys, loc))
                  
            (* Modref *)                  
            | Sac_modref (def, keys, loc) ->
                let _ = List.iter (visit_exp vdm) keys in
                let vdm = visit_def vdm def in
                (vdm, Sac_modref (def, keys, loc))

          in (vdm, instr::instrs)
        end
      in
      
      (* Process a term, updating arguments and updating defs with use info. *)
      let rec update_term (vdm : Var_defs_map.t) (term : sac_term) = 
        match term with
            Sac_if (exp, term1, term2, loc) ->
              let _ = visit_exp vdm exp in
              let term1 = update_term vdm term1 in
              let term2 = update_term vdm term2 in
              Sac_if (exp, term1, term2, loc)
                
          | Sac_read (def, term1, loc) ->
              let vdm = visit_def vdm def in
              let term1 = update_term vdm term1 in
              Sac_read (def, term1, loc)
                
          | Sac_tailcall (funvar, args, loc) ->
              let args = List.map (update_arg vdm) args in
              Sac_tailcall (funvar, args, loc)
                
          | Sac_goto (target_bb, loc) -> Sac_goto (target_bb, loc)              
          | Sac_return (expop, loc) -> 
              let _ = visit_expop vdm expop in
              Sac_return (expop, loc)
      in
      let (vdm, instrs) = List.fold_left update_instr (vdm, []) bb.bb_instrs in
      let instrs = List.rev instrs in
      let _ = bb.bb_instrs <- instrs in
      let term = update_term vdm bb.bb_term in
      let _ = bb.bb_term <- term in
      ()
    in
    (Sac_bb_set.iter reset_basic_block cfg.cfg_bbs) ;
    (Sac_bb_set.iter update_basic_block cfg.cfg_bbs)
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Remove any unused reads from the CFG -- Make sure that the use-info
   of the read definitions is up-to-date first.  Otherwise this may
   remove reads hastily.*)
let remove_unused_reads (cfg:sac_cfg) =
  let rec update_term (term:sac_term) =
    match term with
        Sac_if (exp, term1, term2, loc) ->
          let term1 = update_term term1 in
          let term2 = update_term term2 in
          Sac_if(exp, term1, term2, loc)
            
      | Sac_read (def, term1, loc) ->
          let term1 = update_term term1 in
          if def.df_is_used then           
            Sac_read (def, term1, loc)
          else 
            term1
              
      | Sac_tailcall (funvar, args, loc) -> Sac_tailcall (funvar, args, loc)                
      | Sac_goto (target_bb, loc) -> Sac_goto (target_bb, loc)
      | Sac_return (expop, loc) -> Sac_return (expop, loc)
  in
  (Sac_bb_set.iter 
     (fun bb -> (bb.bb_term <- update_term bb.bb_term))
     cfg.cfg_bbs)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Remove "extra edges" from the CFG.  An edge between bb1 and bb2 is
   _extra_ if both of the following properties hold:
     1. term(bb1) = "goto bb2" 
     2. preds(bb2) = {bb1}. 

   These extra edges are introduced when unused reads are removed
   between bb1 and bb2.  Removing them simplifies the CFG slightly.
*)
let remove_extra_edges (cfg:sac_cfg) =
  
  (* Create a work queue with all the basic blocks *)
  let work_queue = Queue.create () in
  let _ = Sac_bb_set.iter (fun bb -> Queue.add bb work_queue) cfg.cfg_bbs in
  
  (* Combine two basic blocks connected by an extra edge. *)
  let combine_basic_blocks (bb1:sac_basic_block) (bb2:sac_basic_block) = 
    begin
      (* Fixup a successor of bb2 so that it's predecessor list is
         updated to include bb1 instead of bb2 *)
      let fixup_bb2_succ bb2_succ = 
        let subst_bb2_with_bb1 bb3 = if bb3 == bb2 then bb1 else bb3 in
        let preds' = List.map subst_bb2_with_bb1 bb2_succ.bb_preds in
        bb2_succ.bb_preds <- preds'
      in
      List.iter fixup_bb2_succ bb2.bb_succs ;
      bb1.bb_instrs <- bb1.bb_instrs @ bb2.bb_instrs ;
      bb1.bb_succs <- bb2.bb_succs ;
      bb1.bb_term <- bb2.bb_term ;
      Queue.add bb1 work_queue ;
      cfg.cfg_bbs <- Sac_bb_set.remove bb2 cfg.cfg_bbs 
    end
  in
  
  (* Process a basic block, decide if it ends with an extra edge *)
  let process_basic_block (bb1:sac_basic_block) =
    match bb1.bb_term with
        Sac_goto (bb2, _) -> 
          let bb2_preds = (!bb2).bb_preds in
          if List.length bb2_preds = 1 && (List.hd bb2_preds) == bb1 then
            combine_basic_blocks bb1 !bb2
      | _ -> ()
  in
  
  (* Loop until the work-queue is empty *)
  let rec loop _ = 
    if not (Queue.is_empty work_queue) then
      let bb = Queue.pop work_queue in
      (if Sac_bb_set.mem bb cfg.cfg_bbs then
         (process_basic_block bb)) ; loop ()
  in
  loop ()

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Copy return terminal instructions from otherwise empty basic blocks
   to predecessor basic-blocks -- when possible -- this allows
   normalization to avoid creating empty functions that only
   return. *)
let remove_return_blocks (cfg:sac_cfg) 
    =  
  (* A "return block" is a basic block that does nothing but return. *)
  let is_return_block (bb:sac_basic_block) =
    (List.length (bb.bb_instrs) = 0 &&
        (match bb.bb_term with Sac_return (None, _) -> true | _ -> false)) in
  
  (* Create a set of all return blocks in the CFG (but always exclude
     the initial basic block-- we don't want to remove it). *)
  let return_blocks = 
    (Sac_bb_set.remove cfg.cfg_bb0 
       (Sac_bb_set.filter is_return_block cfg.cfg_bbs)) in

  (* Visit a basic block and change gotos to return blocks into
     returns -- once all terms are simplified this way the return
     blocks will have no more predecessors and can safely be removed
     from the CFG. *)
  let rec simplify_term (term:sac_term) =
    match term with
        Sac_if (exp, term1, term2, loc) ->
          Sac_if(exp, simplify_term term1, simplify_term term2, loc)
      | Sac_read (def, term1, loc) ->
          Sac_read (def, simplify_term term1, loc)
      | Sac_tailcall (funvar, args, loc) ->
          Sac_tailcall (funvar, args, loc)
      | Sac_return (expop, loc) -> Sac_return (expop, loc)
      | Sac_goto (bb1, loc) -> 
          if Sac_bb_set.mem !bb1 return_blocks 
          then Sac_return (None, loc)
          else Sac_goto (bb1, loc)
  in
  (* Simplify the term, filter out return basic blocks from the list
     of successors *)
  let simplify_basic_block (bb:sac_basic_block) = 
    begin
      bb.bb_term <- simplify_term bb.bb_term ;
      bb.bb_succs <- List.filter 
        (fun bb1 -> not (Sac_bb_set.mem bb1 return_blocks)) bb.bb_succs ;
    end
  in
  begin
    (* Visit every non-return basic-block in the CFG. *)
    cfg.cfg_bbs <- Sac_bb_set.diff cfg.cfg_bbs return_blocks ;
    Sac_bb_set.iter simplify_basic_block cfg.cfg_bbs ;
    (* Now all return-basic blocks have been removed from the CFG. *)
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* When we find a call in a tail position, change the call into a
   tailcall -- one should use [remove_return_blocks] first for the
   best results. *)
(* -- TODO: we shouldn't turn recursive calls into tailcalls if the
   function is multiply-recursive (e.g., quicksort) -- the reason
   being that this will mess up reusing the tailcall in the
   non-tailcall position. *)
let calls_to_tailcalls (cfg:sac_cfg) =  
  let visit_basic_block (bb:sac_basic_block) =
    match bb.bb_term  with
      | Sac_return (None, _)
          when 
            cfg.cfg_kind = Sac_cfg_self ||
            cfg.cfg_kind = Sac_cfg_verf
            ->
          begin
            let rev_instrs = List.rev bb.bb_instrs in
            match rev_instrs with
                (Sac_call (funvar, args, loc))::rev_rest -> begin
                  bb.bb_term <- Sac_tailcall(funvar, args, loc) ;
                  bb.bb_instrs <- List.rev rev_rest ;
                end
              | _ -> ()
          end
      | _ -> ()
  in
  (Sac_bb_set.iter visit_basic_block cfg.cfg_bbs)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let string_of_vars (vars:Varset.t) : string =
  (Varset.fold (fun var str -> if str <> "" then str^", "^var.vname 
                else var.vname) vars "")

let string_of_lval (lval:lval) : string = 
  (Pretty.sprint ~width:80 (printLval defaultCilPrinter () lval))

let string_of_exp (exp:exp) : string = 
  (Pretty.sprint ~width:80 (printExp defaultCilPrinter () exp))

let string_of_expop (expop:exp option) : string =
  match expop with Some exp -> string_of_exp exp
    | None -> raise Hell

let string_of_exps (exps:exp list) : string =
  (List.fold_left 
     (fun str exp -> 
        let exp_string = string_of_exp exp in
        if str <> "" then str^", "^exp_string else exp_string) 
     "" exps)
    
let string_of_arg (arg:sac_arg) : string =
  match arg with 
      Sac_readarg exp -> sprintf "readarg(%s)" (string_of_exp exp)
    | Sac_exp exp -> string_of_exp exp

let string_of_args (args:sac_arg list) : string =
  (List.fold_left
     (fun str arg ->
        let arg_string = string_of_arg arg in
        if str <> "" then str^", "^arg_string else arg_string)
     "" args)

let rec string_of_def def =
  let is_used = if def.df_is_used then "" else "(unused)" in
  (sprintf "%s %s := " (string_of_lval def.df_lval) is_used)

and string_of_defop defop =
  match defop with
      Some def -> string_of_def def
    | None -> ""
        
and string_of_instr i = 
  match i with
      Sac_set(def, loc) -> 
        (string_of_def def) ^
          (string_of_expop def.df_exp)
    
    | Sac_call(funvar, args, loc) -> 
        sprintf "%s(%s)" 
          funvar.vname
          (string_of_args args)
    
    | Sac_call_ord (defop, funvar, args, loc) -> 
        sprintf "%s%s(%s)" 
          (string_of_defop defop) 
          funvar.vname
          (string_of_exps args)
          
    | Sac_call_ind (defop, funexp, args, loc) ->
        sprintf "%s%s(%s)" 
          (string_of_defop defop) 
          (string_of_exp funexp) 
          (string_of_exps args)
          
    | Sac_alloc (def, size_exp, initfun, keys, loc) ->
        sprintf "%salloc (%s, %s)[%s]"
          (string_of_def def)
          (string_of_exp size_exp)
          (initfun.vname)
          (string_of_exps keys)
    
    | Sac_modref (def, keys, loc) ->
        sprintf "%smodref()[%s]"
          (string_of_def def)
          (string_of_exps keys)

and string_of_instrs is = match is with
    [] -> ""
  | [i] -> sprintf " %s;" (string_of_instr i)
  | i::is -> sprintf " %s;\n%s" (string_of_instr i) (string_of_instrs is)
      
and string_of_term t = match t with
    Sac_if(exp, t1, t2, _) -> 
      sprintf "if (%s) then (%s)\n  else (%s)" 
        (string_of_exp exp)
        (string_of_term t1) 
        (string_of_term t2)

  | Sac_read(def, t, _) ->
      sprintf "%sread(%s); %s" 
        (string_of_def def) 
        (string_of_expop def.df_exp)
        (string_of_term t)

  | Sac_tailcall (funvar, args, _) -> 
      sprintf "tailcall %s(%s)"
        (funvar.vname)
        (string_of_args args)        
        
  | Sac_goto (bb, _) -> sprintf "goto %d" (!bb).bb_id
  | Sac_return (expop, _) -> 
      sprintf "return %s" 
        (match expop with 
           | Some exp -> string_of_exp exp 
           | None -> "")
      
(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Print a given basic-block to a string *)
let string_of_basic_block (bb:sac_basic_block) (vdm:Var_defs_map.t) (live:Varset.t) =
  sprintf "%d: {\nrdefs=%s\n\n%s\n%s\n}\n" bb.bb_id 
    (Var_defs_map.to_string vdm)
    (string_of_instrs bb.bb_instrs) 
    (string_of_term bb.bb_term)   

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let print_cfg (name:string) ?(cfg_defs=None) ?(cfg_live=None) (cfg:sac_cfg) =
  let bbs_strings = Sac_bb_set.fold 
    (fun bb bbs -> 
       let vdm = match cfg_defs with 
           Some cfg_defs -> Cfg_defs.find cfg_defs bb 
         | None -> Var_defs_map.empty
       in
       let live = match cfg_live with
           Some cfg_live -> Sac_bb_map.find bb cfg_live 
         | None -> Varset.empty
       in
       (string_of_basic_block bb vdm live)::bbs)
    cfg.cfg_bbs [] 
  in
  let f = open_out (name ^ ".cfg") in
  let _ = fprintf f "---BEGIN: %s\n" name in
  let _ = List.iter (fun bb_string -> fprintf f "%s\n" bb_string) bbs_strings in
  let _ = fprintf f "---END: %s\n" name in
  let _ = close_out f in
  ()

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let dotnode_of_basic_block ?(live=None) (bb:sac_basic_block) =
  let escape_angbrack str =
    let match_angbrack = Str.regexp "[<>\"]" in
    (Str.global_replace match_angbrack "\\\\1" str) 
  in
  let instrs_label = string_of_instrs bb.bb_instrs in
  let term_label = string_of_term bb.bb_term in  
  let live_label = match live with
      None -> "" 
    | Some live -> sprintf "LV=\\{%s\\}|" (string_of_vars live)
  in
  let node = sprintf "block_%d [shape=Mrecord,label=\"<head>%d:|{%s%s|<term>%s}\"];\n"
    bb.bb_id bb.bb_id 
    (live_label)
    (escape_angbrack (String.escaped instrs_label))
    (escape_angbrack (String.escaped term_label))
  in

  let edges = List.map 
    (fun bb2 -> sprintf "block_%d -> block_%d;\n" 
       bb.bb_id bb2.bb_id)
    bb.bb_succs in
  
  let forward_edges = List.map 
    (fun bb2 -> sprintf "block_%d -> block_%d [label=\"succ %d\"];\n" 
       bb.bb_id bb2.bb_id bb2.bb_id)
    bb.bb_succs in
  
  let backward_edges = List.map 
    (fun bb2 -> sprintf "block_%d -> block_%d [dir=back,label=\"pred %d\"];\n" 
       bb2.bb_id bb.bb_id bb2.bb_id)
    bb.bb_preds in
  
  let verbose_edges = false in

  (node
   ^ if verbose_edges then 
     (List.fold_right (^) forward_edges "")
   ^ (List.fold_right (^) backward_edges "")
   else
     (List.fold_right (^) edges ""))

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Create edges for each tailcall we see *)
let rec dotedges_of_tailcalls (bb:sac_basic_block) (term:sac_term) = 
  match term with 
      Sac_if(_,term1,term2,_) -> 
        (dotedges_of_tailcalls bb term1)^
          (dotedges_of_tailcalls bb term2)
    | Sac_read(_,term1,_) -> dotedges_of_tailcalls bb term1
    | Sac_goto _ -> ""
    | Sac_return _ -> ""
    | Sac_tailcall (funvar, _, _) -> 
        (sprintf "block_%d -> %s [lhead=cluster_%s,weight=0];\n"
           bb.bb_id funvar.vname funvar.vname)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let print_graph (name:string) ?(cfg_live=None) (cfg:sac_cfg) =
  let bbs_strings = Sac_bb_set.fold 
    (fun bb bbs -> 
       let live = match cfg_live with
           Some cfg_live -> Some (Sac_bb_map.find bb cfg_live)
         | None -> None
       in
       (dotnode_of_basic_block bb ~live:live)::bbs)
    cfg.cfg_bbs [] 
  in
  let f = open_out (name ^ ".cfg.dot") in
  let _ = fprintf f "digraph %s {\nsize=\"7,9\"; center=\"true\"; \n" name in
  let _ = List.iter (fun bb_string -> fprintf f "%s\n" bb_string) bbs_strings in
  let _ = fprintf f "}\n" in
  let _ = close_out f in
  ()

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Create a CFG for the given Cil fundec.  Returns the CFG. *)
let cfg_of_fundec (fundec:fundec) (kind:sac_cfg_kind) : sac_cfg =
  
  let debug = if false then out else no_out in

  (* Keep track of stmt-to-basic-block mapping: *)
  let stmt_map = ref Stmtmap.empty in

  (* Keep track of each basic-block we create: *)
  let bbs = ref Sac_bb_set.empty in
  
  (* basic block id counter *)
  let id_counter = ref 0 in  
  let next_id _ = let id = !id_counter in incr id_counter ; id in
    
  (* Create a basic-block for the given statement -- this is memoized,
     so it's safe to call multiple times for a given stmt. *)
  let block_for_stmt stmt = 
    begin
      if Stmtmap.mem stmt !stmt_map then 
        Stmtmap.find stmt !stmt_map 
      else
        let bb = make_basic_block (next_id ()) in
        let _ = debug "made basic block %d" bb.bb_id in
        let _ = stmt_map := (Stmtmap.add stmt bb !stmt_map) in
        let _ = bbs := (Sac_bb_set.add bb !bbs) in
        bb
    end
  in
  
  (* Set the term for the given basic block *)
  let terminate_bb (bb : sac_basic_block) (term : sac_term) = begin
    debug "block %d: terminated." (bb.bb_id) ;
    bb.bb_term <- term ;
  end in

  (* Convert a series of Cil statements to a Sac basic block *)
  let rec bb_of_stmts 
      (tcxt : term_context) (stmts : stmt list) 
      : (sac_basic_block) = 
    
    let bb = (if stmts <> [] 
              then block_for_stmt (List.hd stmts) 
              else make_basic_block (next_id ()))
    in
    begin
      bbs := (Sac_bb_set.add bb !bbs) ;
      debug "block %d: bb_of_stmts" (bb.bb_id) ;
      bb.bb_instrs <- instrs_of_stmts bb tcxt stmts ;
      debug "done with basic block %d" (bb.bb_id) ;
      bb
    end        

  (* Convert a series of Cil statements to Sac instructions. *)
  and instrs_of_stmts 
      (bb : sac_basic_block) (tcxt : term_context) (stmts: stmt list) 
      : (sac_instr list) =
    
    let _ = debug "block %d: instrs_of_stmts" (bb.bb_id) in

    match stmts with
        (* No more statements.  Terminate the block. *)
        [] -> begin 
          let _ = debug "block %d: instrs_of_stmts: statements done." (bb.bb_id) in
          let term = term_of_stmts bb tcxt [] Varset.empty in
          terminate_bb bb term;
          [] 
        end
      
      | s::stmts -> begin match s.skind with
            (* Handle instructions *)
            Instr instrs -> 
              instrs_of_instrs bb tcxt instrs stmts 
              
          (* Create a new basic block for statements, make default term a goto to it. *)
          | Block block -> 
              let bb' = bb_of_stmts tcxt stmts in
              let term = Sac_goto (ref bb', locUnknown) in
              let tcxt = { tcxt with tcxt_term = Some term } in
              instrs_of_stmts bb tcxt block.bstmts
                
          (* Other statements start termination of the block. *)
          | _ -> 
              begin 
                let _ = debug "block %d: instrs_of_stmts: statements term." (bb.bb_id) in
                let stmts = s::stmts in
                let term = term_of_stmts bb tcxt stmts Varset.empty in
                  terminate_bb bb term ;
                  [] 
              end
        end
          
  (* Convert a series of Cil instructions to Sac instructions. *)
  and instrs_of_instrs       
      (bb : sac_basic_block) (tcxt:term_context) (instrs:instr list) (stmts:stmt list) 
      : (sac_instr list) =

    let _ = debug "block %d: instrs_of_instrs" (bb.bb_id) in

    match instrs with
        [] -> 
          let _ = debug "block %d: instructions done." (bb.bb_id) in
          instrs_of_stmts bb tcxt stmts

      | i::instrs ->  begin match i with
            (* Assignment *)
            Set (lval, exp, loc) ->               
              let _ = debug "block %d: instrs_of_instrs: set" (bb.bb_id) in
              (Sac_set (make_def bb lval ~expop:(Some exp), loc)) :: 
                (instrs_of_instrs bb tcxt instrs stmts)
                
          (* Unsupported assignments *)
          (*| Set _ -> raise (Not_implemented "this assignment form isn't supported")*)
                                
          (* Read *)
          |  Call (Some ((Var var, NoOffset) as lval), Lval(Var funvar, NoOffset), [exp], loc)
              when funvar == (api_varinfo "read") -> begin
                let _ = debug "block %d: instrs_of_instrs: read" (bb.bb_id) in
                let readvars = Varset.singleton var in
                let term = term_of_instrs bb tcxt instrs stmts readvars in
                let def = make_def bb lval ~expop:(Some exp) ~is_read:true in
                let term' = Sac_read (def, term, loc) in
                terminate_bb bb term' ;
                []
              end
                
          (* Allocation *)
          | Call(Some lval, 
                 Lval(Var alloc_funvar, NoOffset), 
                 size_exp::init_funexp::keys, loc)
              when alloc_funvar == (api_varinfo "alloc") -> begin
                let init_funvar = match init_funexp with
                    (AddrOf(Var init_funvar, NoOffset)) -> init_funvar
                  | _ -> raise (Not_implemented "you must give an initialization function")
                in
                let def = make_def bb lval in
                let alloc_instr = Sac_alloc(def, size_exp, init_funvar, keys, loc) in
                alloc_instr :: (instrs_of_instrs bb tcxt instrs stmts)
              end

          (* Modref *)
          | Call(Some lval, Lval(Var funvar, NoOffset), [], loc)
              when funvar == (api_varinfo "modref") -> begin
                let def = make_def bb lval in
                let modref_instr = Sac_modref(def, [], loc) in
                 modref_instr :: (instrs_of_instrs bb tcxt instrs stmts)
              end
                
          (* Scope *)
          | Call(None, Lval(Var funvar, NoOffset), keys, loc)
              when funvar == (api_varinfo "scope") -> begin
                let context_typ = TPtr ((api_typ "context_t"), []) in
                let context_var = makeTempVar fundec context_typ in
                let context_lval = (Var context_var, NoOffset) in
                let def = make_def bb context_lval in
                let size_exp = SizeOf (api_typ "context_t") in
                let context_init = (api_varinfo "context_init") in
                let alloc_instr = Sac_alloc(def, size_exp, context_init, keys, loc) in
                let scope_instr = Sac_call_ord(None, api_varinfo "context_set", [Lval context_lval], loc) in
                alloc_instr :: scope_instr :: (instrs_of_instrs bb tcxt instrs stmts)
              end

          (* Call *)
          | Call (lvalop, funexp, exps, loc) -> 
              let _ = debug "block %d: instrs_of_instrs: call" (bb.bb_id) in
              let defop = match lvalop with 
                  Some lval -> Some (make_def bb lval)
                | None -> None
              in              
              begin match funexp with
                  Lval(Var funvar, NoOffset) ->
                    (* IMPORTANT: we must know whether the target of
                       each call is a core function (i.e., one whose
                       return-value we as the callee should
                       trampoline) or a non-core function (i.e., an
                       'ordinary' call where we can treat the return
                       value in the usual manner).
                       
                       If we don't issue an error here then this
                       ambiguity can lead to problems that are ignored
                       until run-time and cause otherwise
                       unexplainable behavior: a core function may
                       return a closure that is effectively ignored by
                       its caller rather than being trampolined by the
                       caller.  *)
                    let _ = 
                      if hasAttribute "missingproto" (typeAttrs funvar.vtype)
                      then raise (Missing_proto funvar)
                      else ()
                    in
                    let call = 
                      if hasAttribute "slime_function" funvar.vattr && defop = None then
                        (* Self-adjusting call *)
                        let args = List.map (fun e -> Sac_exp e) exps in
                        (Sac_call (funvar, args, loc))
                      else
                        (* Ordinary call *)
                        (Sac_call_ord (defop, funvar, exps, loc))
                    in
                    (call :: (instrs_of_instrs bb tcxt instrs stmts))
                
                | funexp ->
                    (Sac_call_ind (defop, funexp, exps, loc)) 
                    :: (instrs_of_instrs bb tcxt instrs stmts)
              end

          (* Other Sets and Calls are not yet supported *)
          | _ -> raise (Not_implemented "this instruction is not supported")              
        end
          
  (* Convert a series of Cil stmts to Sac terms. *)
  and term_of_stmts 
      (bb : sac_basic_block) (tcxt:term_context) 
      (stmts: stmt list) (readvars:Varset.t)
      : (sac_term) =
    
    let _ = debug "block %d: term_of_stmts" (bb.bb_id) in

    match stmts with
        [] -> 
          begin match tcxt.tcxt_term with 
              Some t -> t 
            | None -> raise Hell
          end

      | s::stmts -> 
          
          (* In the base cases, we will use this: *)
          let bb_of_rest _ = 
            if stmts <> [] then ignore 
              (bb_of_stmts tcxt stmts)
          in
          
          if ( List.length s.preds < 2 || Stmtmap.mem s !stmt_map)
          then
            (* The statement falls-through from previous statement *)
            match s.skind with                
                
                (* Instructions *)
                Instr instrs -> 
                  term_of_instrs bb tcxt instrs stmts readvars
              
              (* Returns *)
              | Return (expop, loc) -> 
                  let _ = bb_of_rest () in begin
                  match (kind, expop) with
                    | (Sac_cfg_meta, expop) -> Sac_return (expop, loc)
                    | (Sac_cfg_verf, expop) -> Sac_return (expop, loc)
                    | (_, None) -> Sac_return (None, loc)
                    | (Sac_cfg_self, Some _) -> 
                        let msg = "self-adjusting functions can't return values" in
                        raise (Not_implemented msg)
                    | (Sac_cfg_init, Some _) -> 
                        let msg = "init functions can't return values" in
                        raise (Not_implemented msg)
                  end

              (* Nested blocks *)
              | Block block -> 
                  let bb' = bb_of_stmts tcxt stmts in
                  let term = Sac_goto(ref bb', locUnknown) in
                  let tcxt = {tcxt with tcxt_term = Some term } in
                  term_of_stmts bb tcxt block.bstmts readvars
                  
              (* If *)
              | If (exp, block1, block2, loc) ->
                  (* Does exp contain read variables? *)
                  if not (Varset.is_empty (Varset.inter (exp_vars exp) readvars))
                  then
                    (* One or more read-variables appear in the
                       conditional expression, so we need to postpone
                       this IF to a fresh basic-block. *)
                    let bb' = bb_of_stmts tcxt (s::stmts) in
                    Sac_goto(ref bb', locUnknown)
                      
                  else
                    (* No read-variables in exp, so we're Ok. *)
                    let _ = debug "block %d: term_of_stmts: IF" (bb.bb_id) in
                    (* Pick a term.  If there are more statements
                       after the IF, then introduce a block bb' for
                       them with the current term_context and use a
                       [goto bb'] as the term for the branches'
                       term_context. Otherwise, keep the current
                       term_context. *)
                    let tcxt  = 
                      if stmts <> [] then 
                        let bb'  = bb_of_stmts tcxt stmts in
                        let goto = Sac_goto(ref bb', locUnknown) in
                        {tcxt with tcxt_term = Some goto}
                      else
                        tcxt
                    in
                    (* THEN branch. *)
                    let _ = debug "block %d: doing THEN branch:" (bb.bb_id) in
                    let term1 = term_of_stmts bb tcxt block1.bstmts readvars in
                    
                    (* ELSE branch. *)  
                    let _ = debug "block %d: doing ELSE branch:" (bb.bb_id) in
                    let term2 = term_of_stmts bb tcxt block2.bstmts readvars in
                    
                    (* The If term. *)
                    Sac_if (exp, term1, term2, loc)                                      

              (* Loops *)
              | Loop (block, loc, _, _) ->
                  (* We assume here that stmts <> [] *)
                  (* bb1 : the body of the loop. *)
                  (* bb2 : the statements after the loop. *)
                  let bb1 = block_for_stmt (List.hd block.bstmts) in
                  let bb2 = bb_of_stmts tcxt stmts in
                  let goto_bb1 = Sac_goto (ref bb1, locUnknown) in
                  let goto_bb2 = Sac_goto (ref bb2, locUnknown) in
                  let tcxt = {tcxt with 
                                tcxt_term = Some goto_bb1 ;
                                tcxt_continue = Some goto_bb1 ;
                                tcxt_break = Some goto_bb2 ; } 
                  in
                  let bb1 = bb_of_stmts tcxt block.bstmts in
                  Sac_goto (ref bb1, loc)
                    
              (* Gotos *)
              | Goto (stmt, loc) -> 
                  let _ = bb_of_rest () in
                  Sac_goto (ref (block_for_stmt !stmt), loc)
                    
              (* Breaks *)
              | Break _ ->
                  let _ = bb_of_rest () in
                  begin match tcxt.tcxt_break with 
                      Some t -> t 
                    | None -> raise Hell (* We aren't in a loop! *)
                  end
                    
              (* Continues *)
              | Continue _ -> 
                  let _ = bb_of_rest () in
                  begin match tcxt.tcxt_continue with 
                      Some t -> t 
                    | None -> raise Hell (* We aren't in a loop! *)
                  end

              | _ -> raise (Not_implemented "switches, trys, etc. not supported")
          else
            (* The statement has multiple predecessors, so make a new
               basic block and yield a goto to it. *)
            let bb' = bb_of_stmts tcxt (s::stmts) in
            Sac_goto (ref (bb'), locUnknown)
              
  (* Convert a series of Cil instructions to Sac terms. *)
  and term_of_instrs 
      (bb : sac_basic_block) (tcxt:term_context) 
      (instrs: instr list) (stmts: stmt list) (readvars:Varset.t)
      : (sac_term) =

    let _ = debug "block %d: term_of_instrs" (bb.bb_id) in

    match instrs with
        [] -> term_of_stmts bb tcxt stmts readvars

      | i::instrs -> begin 
          match i with
              (* Read *)
              Call (Some ((Var var, NoOffset) as lval), Lval(Var funvar, NoOffset), [exp], loc)
                when funvar == (api_varinfo "read") -> 
                  let readvars = Varset.add var readvars in
                  let term = term_of_instrs bb tcxt instrs stmts readvars in
                  let def = make_def bb lval ~expop:(Some exp) ~is_read:true in
                  Sac_read (def, term, loc)
                    
            (* Other instructions -- they go into a new basic block *)
            | _ -> 
                let rest = (mkStmt (Instr(i::instrs))) :: stmts in
                let bb' = bb_of_stmts tcxt rest in
                Sac_goto (ref bb', locUnknown)
        end
  in
  begin
    (* Create a CFG and return it. *)
    let tcxt = { tcxt_term = None; tcxt_continue = None; tcxt_break = None } in
    let bb0 = bb_of_stmts tcxt fundec.sbody.bstmts in  
    let cfg =
      { cfg_kind = kind;
        cfg_bb0 = bb0;
        cfg_bbs = !bbs;
        cfg_max_bb_id = !id_counter;
      } in
    compute_edges cfg ;  
    
    (* If we are creating a CFG for a verifier function, then we needn't
       worry about moving Sac_read's around.  Otherwise, we try to
       relocate them into call-sites. *)
    ( match kind with 
        | Sac_cfg_verf -> begin
            ()
          end
        | _ -> begin
            let cfg_defs = compute_reaching_defs cfg in
            update_uses cfg cfg_defs ;
            remove_unused_reads cfg ;
            remove_extra_edges cfg ;
          end
    ) ;
    remove_return_blocks cfg ;
    calls_to_tailcalls cfg ;
    (cfg)
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Map basic-blocks to statements -- we setup this mapping before we
   elaborate since we need all the statements in-place before we
   elaborate gotos. *)
let bb_stmt_map (cfg:sac_cfg) 
    : stmt Sac_bb_map.t 
    = 
  begin
    let bb_stmt_map = ref Sac_bb_map.empty in
    Sac_bb_set.iter 
      (fun bb -> begin       
         (* Make a dummy statement for now *)
         let stmt0 = mkStmt (Instr []) in
         
         (* Label the basic-block if it has one or more predecessors --
            we do this check to avoid warnings for any unused labels *)         
         (* TEMP: right now we always add a label: *)
         if true || List.length bb.bb_preds > 0 then begin 
           (* Create a label for the basic block *)
           let label = Label ((sprintf "sac_basic_block_%d" bb.bb_id), 
                              locUnknown, false) in
           stmt0.labels <- [label] ;           
         end;

         (* add it to the mapping *)
         bb_stmt_map := Sac_bb_map.add bb stmt0 !bb_stmt_map 
       end) cfg.cfg_bbs ;
    (!bb_stmt_map)
  end
