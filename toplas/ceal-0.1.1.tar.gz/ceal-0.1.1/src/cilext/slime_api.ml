open Cil
open Trace
open Printf

open Slime_util

type symbol = 
  | Symb_fun of string
  | Symb_typ of string

module Symb = struct
  type t = symbol
  let compare s1 s2 = compare s1 s2
end

module Symb_set = Set.Make(Symb)
module Symb_map = Map.Make(Symb)

type element =
  | Fun of varinfo
  | Typ of typ

let ceal_symbols = [
  (* See: "ceal.h", "langcore.h" and "langmeta.h".  These symbols
     represent the subset of the ceal language primitives that require
     some code transformation to realize. *)
  Symb_typ "modref_t" ;
  Symb_fun "alloc" ;
  Symb_fun "modref" ;
  Symb_fun "write" ;
  Symb_fun "read" ;
  Symb_fun "verif" ;
  Symb_fun "scope" ;
]

let runtime_symbols = [  
  (* <inttypes.h> *)
  Symb_typ "uintptr_t" ;
  
  (* "codeloc.h" *)
  Symb_typ "codeloc_t" ;
  Symb_fun "codeloc_curr" ;

  (* "traceobj.h" *)
  Symb_typ "traceobj_t" ;
  Symb_typ "traceobj_vtbl_t" ;
  Symb_fun "traceobj_sing_false" ;
  Symb_fun "traceobj_sing_true" ;
  
  (* "totalorder.h" *)
  Symb_typ "to_node_t" ;

  (* "hash.h" *)
  Symb_fun "hash_buffer" ;
  Symb_fun "hash_oneword" ;

  (* "block.h" *)
  Symb_typ "block_t" ;
  Symb_typ "block_vtbl_t" ;
  Symb_fun "block_inst" ;
  Symb_fun "block_alloc" ;
  Symb_fun "block_time" ;
  Symb_fun "block_comb" ;

  (* "modref.h" *)
  Symb_fun "modref_init" ;

  Symb_fun "modref_write" ;
  Symb_fun "modref_deref" ;
  
  Symb_typ "read_t" ;
  Symb_fun "modref_tmpread" ;
  Symb_fun "modref_addread" ;
  Symb_fun "modref_remread" ;

  (* "context.h" *)
  Symb_typ "context_t" ;
  Symb_fun "context_init" ;
  Symb_fun "context_set" ;
  
  (*
  Symb_fun "context_push" ;
  Symb_fun "context_restore" ;
  *)

  (* "closure.h" *)
  Symb_typ "closure_t" ;
  Symb_typ "closure_vtbl_t" ;
  Symb_fun "closure_inst" ;
  Symb_fun "closure_call" ;
  Symb_fun "closure_time_start" ;

  (* "verif.h" *)
  Symb_fun "__ISVERIF__";
  Symb_fun "verif_block_alloc" ;
  Symb_fun "verif_modref_init" ;
  Symb_fun "verif_modref_read" ;
  Symb_fun "verif_modref_write" ;
]

let all_symbols = (ceal_symbols @ runtime_symbols)

(* Set of all symbols we want to resolve *)
let symb_set = 
  (List.fold_left 
     (fun symb_set symb -> Symb_set.add symb symb_set) 
     Symb_set.empty all_symbols)

(* Current mapping from symbols to elements *)
let symb_map 
    : element Symb_map.t ref
    = ref Symb_map.empty

exception Missing_symb of string

let symbol_name symbol =
  match symbol with 
    | Symb_fun name -> name
    | Symb_typ name -> name

(* Get the varinfo for an API function by name *)
let api_varinfo funname =
  try 
    let Fun varinfo = Symb_map.find (Symb_fun funname) !symb_map 
    in varinfo
  with Not_found -> raise (Missing_symb funname)

(* Get the typ for an API type by name *)
let api_typ typname =
  try
    let Typ typ = Symb_map.find (Symb_typ typname) !symb_map
    in typ
  with Not_found -> raise (Missing_symb typname)

(* If the symbol is one we want to resolve, add it to our mapping *)
let add_mapping symbol element =
  if Symb_set.mem symbol symb_set then begin
    no_out "found API symbol: %s" (symbol_name symbol) ;
    symb_map := Symb_map.add symbol element !symb_map    
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
class api_setup () = object(self)
  inherit nopCilVisitor        

  method vglob (g:global) : global list visitAction = begin
    match g with 
      | GVarDecl (varinfo, loc) ->
          let symbol = Symb_fun varinfo.vname in
          add_mapping symbol (Fun varinfo) ; 
          SkipChildren

      | GType (typeinfo, loc) ->
          let typ = TNamed(typeinfo, []) in
          let symbol = Symb_typ typeinfo.tname in
          add_mapping symbol (Typ typ) ;
          SkipChildren

      | _ -> 
          DoChildren
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Detect the use of the ceal API. *)
class ceal_api_detection () = object(self)
  inherit nopCilVisitor        
  val mutable result = false    
  method get_result () = result
  method vvrbl (var:varinfo) : varinfo visitAction = begin
    if List.mem (Symb_fun var.vname) ceal_symbols then
      (result <- true; SkipChildren)
    else
      DoChildren
  end
  method vinstr (instr:instr) : instr list visitAction = begin
    match instr with
      | Call(_, Lval(Var funvar, NoOffset), _, _)
          when hasAttribute "slime_function" funvar.vattr
            || hasAttribute "slime_initializer" funvar.vattr 
            -> (result <- true; SkipChildren)
      | _ -> DoChildren
  end
end

(* Returns true if the given function makes any calls to the ceal
   API, false otherwise. *)
let fundec_uses_ceal_api (fundec:fundec) : bool =
  let detector = (new ceal_api_detection ()) in
  let _ = visitCilBlock (detector :> cilVisitor) fundec.sbody in
  detector#get_result ()
