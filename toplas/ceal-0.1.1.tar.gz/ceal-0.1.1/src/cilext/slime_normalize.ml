open Printf
open Cil
open Slime_util
open Slime_cfg
open Slime_program

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Add a new phantom basic block as a "root" that's connected to each
   basic block that may follow a read -- this altered CFG is then used
   to compute a dominator tree, etc. *)
let add_read_edge_root (cfg:sac_cfg) : (sac_basic_block) =
  let root_id = cfg.cfg_max_bb_id in
  let _ = cfg.cfg_max_bb_id <- cfg.cfg_max_bb_id + 1 in
  let root = make_basic_block root_id in
  
  (* Initially, the only head is the initial block *)
  let heads = ref (Sac_bb_set.singleton cfg.cfg_bb0) in

  (* Visit a term and for each [goto bb] under a read, add [bb] to
     [heads] *)
  let rec visit_term term seen_read =
    match term with
        Sac_if (_, term1, term2, _) -> begin 
          visit_term term1 seen_read ; 
          visit_term term2 seen_read
        end
      | Sac_read (_, term1, _) -> 
          (visit_term term1 true)
      | Sac_goto (bb, _) -> 
          if seen_read then (heads := Sac_bb_set.add !bb !heads)
      | Sac_tailcall _ -> ()
      | Sac_return _ -> ()
  in
  
  (* Visit a basic block by visiting it's term *)
  let visit_basic_block bb =
    (visit_term bb.bb_term false)
  in
  (* When visiting a head [bb], create an edge from [root] to [bb] *)
  let visit_head bb = begin
    bb.bb_preds <- root :: bb.bb_preds ;
    root.bb_succs <- bb :: root.bb_succs ;
  end
  in
  begin
    (* Visit each basic block *)
    Sac_bb_set.iter visit_basic_block cfg.cfg_bbs ;    
    (* Visit each resulting head *)
    Sac_bb_set.iter visit_head !heads ;
    (* Add the root *)
    cfg.cfg_bbs <- Sac_bb_set.add root cfg.cfg_bbs ;
    (* Return the root *)
    root
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Remove the root basic block introduced by [add_read_edge_root].   *)
let remove_read_edge_root (cfg:sac_cfg) (root:sac_basic_block) = 
  begin
    (* Remove the root as a predecessor from all its successors *)
    let visit_root_succ bb =
      bb.bb_preds <- List.filter (fun bb2 -> bb2 == root) bb.bb_preds 
    in List.iter visit_root_succ root.bb_succs ;
    (* Remove the root from the set of basic blocks *)
    cfg.cfg_bbs <- Sac_bb_set.remove root cfg.cfg_bbs ;
  end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Normalize a CFG and add all fresh functions we create in the
   process to the program *)
let normalize (fn:sac_function) : unit =
  let cfg = fn.fn_cfg in

  (* Compute the live variables *)
  let cfg_live = compute_live_vars cfg in
  let _ = if !slime_print_dot <> 0 then
    (print_graph (fn.fn_varinfo.vname^"_live") 
       ~cfg_live:(Some cfg_live) cfg) in

  (* Print stuff before we partition it *)
  (*let _ = print_cfg cfg ~cfg_live:(Some cfg_live) in*)
  (*let _ = print_cfg_graph cfg ~cfg_live:(Some cfg_live) in*)

  (* Compute the dominator tree *)
  let root = add_read_edge_root cfg in
  let dom_map = Sac_bb_dom.dominators cfg.cfg_bbs root in
  let idom_map = Sac_bb_dom.immediate_dominators cfg.cfg_bbs root dom_map in
  let dom_tree = Sac_bb_dom.dominator_tree root idom_map in
  let _ = remove_read_edge_root cfg root in
    
  (* Print stuff before we partition it *)
  (*
  let _ = Sac_bb_dom.print_dom_tree_graph 
    cfg.cfg_fundec.svar.vname dom_tree in*)
  
  (* The mappings we use to fixup gotos -- they map initial blocks to
     functions. *)
  let funbb0s = ref Sac_bb_map.empty in
  
  (* Trim down the locals for the function to those variables that are
     (1) used (2) local and (3) aren't formals *)
  let update_locals (fn:sac_function) =
    let formals = List.fold_left (fun vars var -> Varset.add var vars) 
      Varset.empty fn.fn_normal.sformals in
    let free = compute_free_vars fn.fn_cfg.cfg_bbs in
    let locals = Varset.elements (Varset.diff free formals) in
    let locals = List.filter (fun var -> not var.vglob) locals in
    (fn.fn_normal.slocals <- locals)
  in

    (* Introduce a fresh function (and CFG) for the given [bb0] and
       [bbs] -- we don't make a fresh function for the original initial
       basic block. *)
  let fresh_function (bb0:sac_basic_block) (bbs:Sac_bb_set.t) 
      : sac_function =
    let fn' =
      if not (bb0 == cfg.cfg_bb0) then
        let name = sprintf "%s_%d" fn.fn_varinfo.vname bb0.bb_id in
        let live = Sac_bb_map.find bb0 cfg_live in 
        let formals = Varset.elements live in
        let formals = List.filter (fun var -> not var.vglob) formals in
        let formal_typs = List.map (fun arg -> (arg.vname, arg.vtype, arg.vattr)) formals in
        let typ = TFun (voidType, Some formal_typs, false, [Attr("slime_function",[])]) in
        let svar = makeVarinfo true name typ in
        let fundec = 
          {fn.fn_fundec with 
             svar = svar; 
             sformals = formals; 
             sbody = mkBlock []; 
             sallstmts = []} 
        in
        let cfg = {cfg with 
                     cfg_bb0 = bb0;
                     cfg_bbs = bbs;} in
        (add_normal_function fn fundec cfg)
      else begin
        fn.fn_cfg.cfg_bbs <- bbs ; fn
      end
    in
    begin
      funbb0s := Sac_bb_map.add bb0 fn' !funbb0s;
      update_locals fn' ;
      fn';
    end
  in
  
  (* Paritition the CFG based on the dominator tree *)
  let partition = Sac_bb_dom.dom_tree_subtrees dom_tree in
  let fns = List.map 
    (fun (bb0, bbs) -> fresh_function bb0 bbs) 
    partition in

  let fixup_function (fn:sac_function) =
    (* Change non-local gotos into tailcalls *)
    let rec fixup_term (term:sac_term) = 
      match term with
          Sac_if (exp, term1, term2, loc) -> 
            Sac_if (exp, fixup_term term1, fixup_term term2, loc)
        | Sac_read (def, term1, loc) ->
            Sac_read (def, fixup_term term1, loc)
        | Sac_tailcall (funvar, args, loc) ->
            Sac_tailcall (funvar, args, loc)
        | Sac_return (expop, loc) -> Sac_return (expop, loc)
        | Sac_goto (bb, loc) ->
            if Sac_bb_set.mem !bb fn.fn_cfg.cfg_bbs then
              Sac_goto (bb, loc)
            else 
              let fn' = Sac_bb_map.find !bb !funbb0s in
              let args = List.map 
                (fun argvar -> Sac_exp(Lval(Var argvar, NoOffset)))
                fn'.fn_fundec.sformals in
              Sac_tailcall (fn'.fn_varinfo, args, loc)
    in
    begin
      let cfg = fn.fn_cfg in
      (* Fixup all the terminal instructions *)
      (Sac_bb_set.iter 
         (fun bb -> bb.bb_term <- fixup_term bb.bb_term) 
         cfg.cfg_bbs) ;
      (* Compute edges, reaching defs and remove unused reads and
         extra edges *)
      let _ = compute_edges cfg in
      let cfg_defs = compute_reaching_defs cfg in
      update_uses cfg cfg_defs ;
      remove_unused_reads cfg ;
      remove_extra_edges cfg ;
    end
  in  
  (List.iter fixup_function fns) ;
  (if !slime_print_dot <> 0 then
     (print_function_graph (fn.fn_varinfo.vname^"_normal") fns))

(*
  let = cfg_of_fundec fundec in  
  let cfgs = normalize_cfg cfg in
  let _ = print_cfg_multigraph (cfg.cfg_fundec.svar.vname^"_normal") cfgs in
*)

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* Check the given function is in normal-form by checking that its CFG
   has no remaining read terminal instructions. *)

let anormal_reads (fn:sac_function) : location list =
  let rec visit_term (term:sac_term) = 
    match term with
        Sac_if (_,term1,term2,_) -> 
          (visit_term term1 @ visit_term term2)
      | Sac_read (_,_,loc) -> [loc]
      | Sac_tailcall _ -> []
      | Sac_goto _     -> []
      | Sac_return _   -> []
  in
  let visit_basic_block (bb:sac_basic_block) =
    (visit_term bb.bb_term)
  in
  (Sac_bb_set.fold 
     (fun bb result -> result @ visit_basic_block bb)
     fn.fn_cfg.cfg_bbs [])
    
let check_normal (fn:sac_function) : unit =
  List.iter 
    (fun loc -> ignore (errorLoc loc "cannot allow the read that appears here"))
    (anormal_reads fn)
