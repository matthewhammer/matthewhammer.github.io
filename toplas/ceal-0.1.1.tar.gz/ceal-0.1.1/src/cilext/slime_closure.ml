open Cil
open Slime_util
open Slime_api
open Slime_program

exception Hell
exception Wtf of string

type arginfo = { mutable arg_index : int ;
                 mutable arg_name : string ;
                 mutable arg_typ : typ ;
                 mutable arg_offset : offset ;
                 mutable arg_value : offset ;
                 mutable arg_read : offset ;
                 mutable arg_never_a_read : bool ;
               }

let rec mkstruct (fn : sac_function) (ob:traceobj) 
    : typ * arginfo list
    =  
  let basename = fn.fn_varinfo.vname in    
  let compinfo = 
    let make_fields (compinfo:compinfo) =
      let proto_field_from_formal (formal:varinfo) = 
        let arg_compinfo = 
          let make_arg_fields _ = 
            [("value", formal.vtype, None, formal.vattr, locUnknown) ;
             ("read", TPtr(api_typ "read_t", []), None, [], locUnknown)] 
          in 
          let union = 
            mkCompInfo false 
              (basename^"_closure_"^formal.vname^"_u") 
              make_arg_fields [] in
          let _ = extend_def ob (GCompTag (union, locUnknown)) 
          in union
        in  
        (formal.vname,
         TComp(arg_compinfo,[]),
         None, [], locUnknown)
      in
      ("closure", api_typ "closure_t", None, [], locUnknown) 
      :: (List.map proto_field_from_formal fn.fn_fundec.sformals)
    in
    mkCompInfo true (basename^"_closure_s") make_fields []
  in   
  let arginfos = mkarginfos compinfo in
  let typeinfo = {tname=basename^"_closure_t"; 
                  ttype=TComp(compinfo,[]);
                  treferenced=true;} in
  let typedef = TNamed (typeinfo, []) in
  begin
    extend_proto ob (GType (typeinfo, locUnknown));
    extend_def ob (GCompTag (compinfo, locUnknown));
    (typedef, arginfos)
  end  

(* Makes an [arginfo list] from the structure created by [mkstruct].
   I've found that the CIL [compinfo] type is particularly difficult
   to use without some auxiliarly knowledge about its fields, etc. The
   [arginfo list] we create here gives us a more useful representation
   of the [compinfo] of the closure. *)
and mkarginfos (compinfo:compinfo) 
    : arginfo list 
    =
  let rec loop index fields =
    match fields with
      | [] -> []
          
      | field::fields 
          when (field.fname = "closure") -> 
          loop index fields

      | field::fields ->
          let unioninfo = 
            match field.ftype with
              | TComp(unioninfo, _) -> unioninfo
              | _ -> raise (Heck ("type of "^field.fname^" should be a TComp!"))
          in
          let (value_field, read_field) = 
            match unioninfo.cfields with
              | [value_field; read_field] -> (value_field, read_field)
              | _ -> raise (Heck "this union should have exactly two fields!")
          in
          let arginfo = { arg_index = index ;
                          arg_name = field.fname ;
                          arg_typ = value_field.ftype ;
                          arg_offset = Field(field, NoOffset) ;
                          arg_value = Field(field, Field(value_field, NoOffset)) ;
                          arg_read = Field(field, Field(read_field, NoOffset)) ;
                          arg_never_a_read = false; }
          in
          (arginfo :: loop (index+1) fields)
  in
  (loop 0 compinfo.cfields)


(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let closure_elaborate (fn : sac_function) (ob : traceobj) =
  let basename = fn.fn_varinfo.vname in
  let (inst_typ, arginfos) = mkstruct fn ob in
  let mask_off = proj inst_typ ["closure";"readmask"] in
  let rval_off = proj (api_typ "read_t") ["value"] in
  let inst_ptr = TPtr(inst_typ, []) in  
  let buffer_typ = TPtr(TInt(IUChar, []), []) in
  let vtbl_var = (makeGlobalVar 
                    (basename^"_closure_vtbl")
                    (api_typ "closure_vtbl_t")) 
  in
  let _ = vtbl_var.vstorage <- Static in
  let name_typ = TFun(charConstPtrType,
                      Some [("closure", inst_ptr, [])], 
                      false, [])
  in  
  let size_typ = TFun(api_typ "uintptr_t", 
                      Some [("closure", inst_ptr, [])], 
                      false, []) 
  in  
  let buff_typ = TFun(api_typ "uintptr_t",
                      Some [("closure", inst_ptr, []);
                            ("buffer", buffer_typ, [])],
                      false, [])
  in
  let hash_typ = TFun(api_typ "uintptr_t",
                      Some [("closure", inst_ptr, []);
                            ("hashin", (api_typ "uintptr_t"), [])],
                      false, [])
  in
  let eqiv_typ = TFun(api_typ "uintptr_t",
                      Some [("closure_1", inst_ptr, []);
                            ("closure_2", inst_ptr, [])], 
                      false, []) 
  in
  let init_typ = TFun(voidType,
                      Some [("closure", inst_ptr, [])], 
                      false, []) 
  in
  let comb_typ = TFun(voidType,
                      Some [("closure_1", inst_ptr, []);
                            ("closure_2", inst_ptr, [])], 
                      false, []) 
  in
  let invk_typ = TFun(TPtr(api_typ "closure_t", []), 
                      Some [("closure", inst_ptr, [])], 
                      false, []) 
  in

  let current_fundec = 
    ref dummyFunDec
  in  
  let make_fundec (opname:string) (optyp:typ) (storage:storage) =
    let varinfo = makeGlobalVar (basename ^ "_closure_" ^ opname) optyp in
    let _ = varinfo.vstorage <- storage in
    let fundec = make_fundec varinfo in
    let _ = current_fundec := fundec in
    extend_def ob (GFun (fundec, locUnknown)) ; fundec
  in
  let make_temp_var ?(name="tmpa___") (typ:typ) : varinfo =
    if(!current_fundec == dummyFunDec) 
    then raise (Heck "current_fundec is dummyFunDec!")
    else (makeTempVar ~name !current_fundec typ)
  in
  
  (* An (integer) expression that evaluates to the size of buffer
     required for "buff" operation *)
  let rec buff_size_exp arginfos =
    match arginfos with 
      | [] -> zero
      | arginfo::arginfos -> 
          BinOp ( PlusA,
                  SizeOf (arginfo.arg_typ), 
                  buff_size_exp arginfos,
                  api_typ "uintptr_t"
                )
  in

  (* Operation: INST -- instantiate *)
  let make_inst _ =
    let inst_typ = 
      let formals = 
        match fn.fn_varinfo.vtype with
          | TFun(_, Some(formals), _, _) -> formals
          | _ -> raise Hell
      in
      let inst_formals = List.fold_right
        (fun (name, typ, attr) formals -> 
           (name, typ, attr)
           :: (name^"_read", TPtr(api_typ "read_t", []) , [])
           :: formals)
        (formals) [] 
      in
      TFun(inst_ptr, Some inst_formals, false, []) 
    in
    let fundec = make_fundec "inst" inst_typ fn.fn_varinfo.vstorage in
    let tmp_closure = makeTempVar fundec inst_ptr in
    let inst_stmt = 
      mkStmt (Instr [(Call (Some (Var tmp_closure, NoOffset), 
                            Lval (Var (api_varinfo "closure_inst"), NoOffset), 
                            [AddrOf (Var vtbl_var, NoOffset)],
                            locUnknown))])       
    in    
    let args : (varinfo * varinfo * arginfo) list = List.map 
      (fun arginfo -> 
         let formal_val = 
           makeFormalVar fundec 
             (arginfo.arg_name^"_val") (arginfo.arg_typ) 
         in         
         let formal_read = 
           makeFormalVar fundec 
           (arginfo.arg_name^"_read") (TPtr(api_typ "read_t", []))
         in
         (formal_val, formal_read, arginfo)) 
      arginfos
    in
    let init_stmts =
      let handle_arg (val_arg, read_arg, arginfo) =
        Formatcil.cStmts 
          "if (read_arg) { 
             (*closure) %o:read_off = read_arg;
             (*closure) %o:mask_off = ((*closure) %o:mask_off) |  (1 << %d:arg_idx);
           } else {
             (*closure) %o:val_off = val_arg;
           }"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("closure",  Fv tmp_closure);
            ("arg_idx",  Fd arginfo.arg_index);
            ("val_arg",  Fv val_arg);
            ("read_arg", Fv read_arg);
            ("val_off",  Fo arginfo.arg_value);
            ("read_off", Fo arginfo.arg_read);
            ("mask_off", Fo mask_off); ]
      in
      List.flatten (List.map handle_arg args)
    in
    let return_stmt = 
      mkStmt (Return (Some(Lval (Var tmp_closure, NoOffset)), locUnknown)) in    
    fundec.sbody <- mkBlock (inst_stmt :: init_stmts @ [return_stmt]) ;
    fundec.svar
  in
  
  (* Operation: NAME *)
  let make_name _ =
    let fundec = make_fundec "name" name_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    fundec.sbody <- mkBlock [mkStmt (Return(Some (Const (CStr basename)), locUnknown))] ;
    fundec.svar
  in

  (* Operation: SIZE *)
  let make_size _ =
    let fundec = make_fundec "size" size_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    fundec.sbody <- mkBlock [mkStmt (Return(Some (SizeOf inst_typ), locUnknown))] ;
    fundec.svar
  in
  
  (* Operation: BUFF *)
  let make_buff _ =
    let fundec = make_fundec "buff" buff_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    let tmp_buffer  = makeFormalVar fundec ~where:"$" "buff" buffer_typ  in
    let fill_stmts =
      let handle_arginfo arginfo =
        let tmp = makeTempVar fundec arginfo.arg_typ in
        Formatcil.cStmts
          "if ((*closure) %o:mask_off & 1 << %d:arg_idx)
           { tmp = (%t:arg_t) (* (*closure) %o:read_off) %o:rval_off; }
           else
           { tmp = (*closure) %o:val_off; }
           *((%t:arg_t *) buffer) = tmp;
           buffer = buffer + sizeof(tmp);"

          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("closure",  Fv tmp_closure);
            ("tmp",      Fv tmp);
            ("buffer",   Fv tmp_buffer);
            ("arg_idx",  Fd arginfo.arg_index);
            ("arg_t",    Ft arginfo.arg_typ);
            ("mask_off", Fo mask_off);
            ("read_off", Fo arginfo.arg_read);
            ("rval_off", Fo rval_off);
            ("val_off",  Fo arginfo.arg_value);
          ]
      in
      List.flatten (List.map handle_arginfo arginfos)
    in    
    let check_and_fill = 
      mkStmt (If ((Lval (Var tmp_buffer, NoOffset)), 
                  mkBlock (fill_stmts), mkBlock [], locUnknown))
    in
    let return_size = 
      mkStmt (Return (Some (buff_size_exp arginfos), locUnknown))
    in
    fundec.sbody <- mkBlock [check_and_fill; return_size] ;
    fundec.svar
  in

  (* Operation: HASH *)
  let make_hash buff_svar =
    let fundec = make_fundec "hash" hash_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    let tmp_hashin  = makeFormalVar fundec ~where:"$" "hashin" (api_typ "uintptr_t") in
    let tmp_result  = makeTempVar fundec (api_typ "uintptr_t") in
    let tmp_buffer  = 
      makeTempVar fundec 
        (TArray (TInt (IUChar, []), Some (buff_size_exp arginfos), [])) 
    in
    let stmts = Formatcil.cStmts
      "buff(closure, buffer);
       result = hashfn(buffer, %e:size, hashin);
       return result;"
      (fun n t -> make_temp_var ~name:n t) locUnknown
      [ ("closure",  Fv tmp_closure);
        ("hashin",   Fv tmp_hashin);
        ("buffer",   Fv tmp_buffer);
        ("result",   Fv tmp_result);
        ("buff",     Fv buff_svar);
        ("size",     Fe (buff_size_exp arginfos));
        ("hashfn",   Fv (api_varinfo "hash_buffer"));
      ]
    in
    fundec.sbody <- mkBlock stmts;
    fundec.svar
  in

  (* Operation: EQIV -- Equivalent? *)
  let make_eqiv _ =
    let fundec = make_fundec "eqiv" eqiv_typ Static in
    let tmp_closure1 = makeFormalVar fundec ~where:"$" "closure_1" inst_ptr in
    let tmp_closure2 = makeFormalVar fundec ~where:"$" "closure_2" inst_ptr in
    let test_stmts =
      let handle_arginfo arginfo =
        Formatcil.cStmts 
          "%t:arg_t tmp1; 
           %t:arg_t tmp2;
           
           if ((*closure1) %o:mask_off & 1 << %d:arg_idx)
              tmp1 = (%t:arg_t) (* (*closure1) %o:read_off) %o:rval_off;
           else 
              tmp1 = (*closure1) %o:val_off;
           
           if ((*closure2) %o:mask_off & 1 << %d:arg_idx)
              tmp2 = (%t:arg_t) (* (*closure2) %o:read_off) %o:rval_off;
           else 
              tmp2 = (*closure2) %o:val_off;

           if(tmp1 != tmp2) 
              return 0;"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("closure1",  Fv tmp_closure1);
            ("closure2",  Fv tmp_closure2);
            ("arg_idx",   Fd arginfo.arg_index);
            ("mask_off",  Fo mask_off);
            ("read_off",  Fo arginfo.arg_read);
            ("rval_off",  Fo rval_off);
            ("val_off",   Fo arginfo.arg_value);
            ("arg_t",     Ft arginfo.arg_typ);
          ]
      in
      (List.flatten (List.map handle_arginfo arginfos))
    in
    let return_one = 
      mkStmt (Return (Some one, locUnknown))
    in
    fundec.sbody <- mkBlock (test_stmts @ [return_one]);
    fundec.svar
  in

  (* Operation: INIT -- Initialize *)
  let make_init _ =
    let fundec = make_fundec "init" init_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    let init_stmts =
      let handle_arginfo arginfo =
        Formatcil.cStmts 
           "if ((*closure) %o:mask_off & 1 << %d:arg_idx)
              (*closure) %o:read_off = 
                modref_addread((*closure) %o:read_off, (%t:closure_t*) closure);"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("closure",  Fv tmp_closure);
            ("arg_idx",   Fd arginfo.arg_index);
            ("mask_off",  Fo mask_off);
            ("read_off",  Fo arginfo.arg_read);
            ("closure_t", Ft (api_typ "closure_t"));
            ("modref_addread", Fv (api_varinfo "modref_addread"));
          ]
      in
      (List.flatten (List.map handle_arginfo arginfos))
    in
    fundec.sbody <- mkBlock init_stmts ;
    fundec.svar
  in

  (* Operation: UINI -- Un-initialize *)
  let make_uini _ =
    let fundec = make_fundec "uini" init_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    let uini_stmts =
      let handle_arginfo arginfo =
        Formatcil.cStmts 
           "if ((*closure) %o:mask_off & 1 << %d:arg_idx)
              modref_remread((*closure) %o:read_off);"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("closure",  Fv tmp_closure);
            ("arg_idx",   Fd arginfo.arg_index);
            ("mask_off",  Fo mask_off);
            ("read_off",  Fo arginfo.arg_read);
            ("modref_remread", Fv (api_varinfo "modref_remread"));
          ]
      in
      (List.flatten (List.map handle_arginfo arginfos))
    in
    fundec.sbody <- mkBlock uini_stmts ;
    fundec.svar
  in

  (* Operation: COMB -- Combine *)
  let make_comb (uini:varinfo) (init:varinfo) =
    let fundec = make_fundec "comb" comb_typ Static in
    let tmp_closure1 = makeFormalVar fundec ~where:"$" "closure_1" inst_ptr in
    let tmp_closure2 = makeFormalVar fundec ~where:"$" "closure_2" inst_ptr in
    let common_vars =       
      [ ("closure1", Fv tmp_closure1);
        ("closure2", Fv tmp_closure2);
        ("init",     Fv uini);
        ("uini",     Fv init);
        ("mask_off", Fo mask_off)]
    in
    let stmts_first = Formatcil.cStmts 
      "uini(closure2); 
       (*closure2) %o:mask_off = (*closure1) %o:mask_off;"
      (fun n t -> make_temp_var ~name:n t) locUnknown 
      common_vars
    in
    let stmts_middle = 
      let handle_arginfo arginfo =
        Formatcil.cStmt 
          "(*closure2) %o:arg_off = (*closure1) %o:arg_off;"          
          (fun n t -> make_temp_var ~name:n t) locUnknown
          (("arg_off", Fo arginfo.arg_offset)::common_vars)
      in
      (List.map handle_arginfo arginfos)
    in      
    let stmts_last = Formatcil.cStmts 
      "init(closure2);"
      (fun n t -> make_temp_var ~name:n t) locUnknown common_vars
    in
    fundec.sbody <- mkBlock (stmts_first @ stmts_middle @ stmts_last);
    fundec.svar
  in
  
  (* Operation: INVK -- Invoke *)
  let make_invk _ =
    let fundec = make_fundec "invk" invk_typ Static in
    let tmp_closure = makeFormalVar fundec ~where:"$" "closure" inst_ptr in
    let tmp_closure2 = makeTempVar fundec inst_ptr in
    let args : (varinfo * arginfo) list = 
      List.map 
        (fun arginfo -> 
           (makeTempVar fundec (arginfo.arg_typ), arginfo)) 
        arginfos
    in
    let unpack_stmts = 
      let handle_arg (varinfo, arginfo) =
        Formatcil.cStmts 
           "if ((*closure) %o:mask_off & 1 << %d:arg_idx)
              arg = (%t:arg_t) (* (*closure) %o:read_off) %o:rval_off;
            else
              arg = (*closure) %o:val_off;"
          (fun n t -> make_temp_var ~name:n t) locUnknown
          [ ("closure",   Fv tmp_closure);
            ("arg_idx",   Fd arginfo.arg_index);
            ("mask_off",  Fo mask_off);
            ("read_off",  Fo arginfo.arg_read);
            ("val_off",   Fo arginfo.arg_value);
            ("rval_off",  Fo rval_off);
            ("arg",       Fv varinfo);
            ("arg_t",     Ft arginfo.arg_typ);
          ]
      in
      (List.flatten (List.map handle_arg args))
    in
    let locals = List.map (fun (varinfo, _) ->  Lval(Var varinfo, NoOffset)) args in
    let invk_stmt = 
      mkStmt (Instr [Call (Some (Var tmp_closure2, NoOffset),
                           Lval (Var fn.fn_varinfo, NoOffset),
                           locals, locUnknown)])
    in
    let return_exp = 
      mkCast (Lval (Var tmp_closure2, NoOffset)) 
        (TPtr (api_typ "closure_t", []))
    in
    let return_stmt = mkStmt (Return (Some return_exp, locUnknown)) in
    fundec.sbody <- mkBlock (unpack_stmts @ [invk_stmt; return_stmt]) ;
    fundec.svar
  in

  (* Create initializer for field named [fname] for vtbl of type [typ]
     using variable [varinfo] *)
  let vtbl_init (typ:typ) (fname:string) (varinfo:varinfo)
      : (offset * init) 
      = 
    let offset = proj typ [fname] in
    let field = proj_field offset in
    (offset, SingleInit(CastE(field.ftype, Lval(Var varinfo, NoOffset))))
  in
  
  begin
    extend_def ob (GVarDecl (vtbl_var, locUnknown));     
    extend_def ob (GFun (fn.fn_fundec, locUnknown));
    ob.ob_inst_fun <- make_inst () ;
    ob.ob_inst_typ <- inst_typ ;
    extend_proto ob (GVarDecl (ob.ob_inst_fun, locUnknown));
    extend_proto ob (GVarDecl (fn.fn_varinfo, locUnknown));
           
    let name = make_name () in
    let size = make_size () in
    let buff = make_buff () in
    let hash = make_hash buff in
    let eqiv = make_eqiv () in
    let init = make_init () in
    let uini = make_uini () in
    let comb = make_comb init uini in
    let invk = make_invk () in
    
    let is_memoized = 
      if hasAttribute "slime_nomemo" fn.fn_varinfo.vattr then false
      else if hasAttribute "slime_function" fn.fn_varinfo.vattr then true
      else true (* TODO: The default for functions we create via normalization *)
    in

    let sing = if is_memoized then
      (api_varinfo "traceobj_sing_false")
    else begin
      (ignore (out "not memo-ized: %s" fn.fn_varinfo.vname)) ;
      (api_varinfo "traceobj_sing_true")
    end
    in
        
    let traceobj_vtbl_init : init =
      let typ = (api_typ "traceobj_vtbl_t") in
      let inits : (offset * init) list = 
        [ vtbl_init typ "name" name;
          vtbl_init typ "size" size;
          vtbl_init typ "sing" sing;
          vtbl_init typ "buff" buff;
          vtbl_init typ "hash" hash;
          vtbl_init typ "eqiv" eqiv;
          vtbl_init typ "time" (api_varinfo "closure_time_start");
          vtbl_init typ "init" init;
          vtbl_init typ "comb" comb; ] 
      in
      CompoundInit (typ, inits)
    in  
    
    let closure_vtbl_init : init =
      let typ = (api_typ "closure_vtbl_t") in
      let inits : (offset * init) list = 
        [ (proj typ ["traceobj_vtbl"], traceobj_vtbl_init);
          vtbl_init typ "invk" invk; 
          vtbl_init typ "uini" uini;
        ]
      in
      CompoundInit (typ, inits)        
    in
    extend_def ob (GVar (vtbl_var, {init=Some closure_vtbl_init}, locUnknown))
 end

let closure_prototype fn ob : global list = 
  List.rev ob.ob_prototype

let rec closure_definition fn ob : global list =  
  let getprotos fn =
    match fn.fn_kind with 
      | Sac_fn_self(ob) -> closure_prototype fn ob
      | _ -> raise Hell
  in
  let getdefs fn =
    match fn.fn_kind with 
      | Sac_fn_self(ob) -> closure_definition fn ob
      | _ -> raise Hell
  in
  let descs_protos = List.flatten (List.map getprotos fn.fn_descs) in
  let descs_defs = List.flatten (List.map getdefs fn.fn_descs) in
  (descs_protos
   @ fn.fn_globs 
   @ (List.rev ob.ob_definition)
   @ descs_defs)
