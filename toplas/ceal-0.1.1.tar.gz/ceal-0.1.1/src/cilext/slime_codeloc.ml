open Cil
open Printf
open Slime_api
open Slime_util
open Slime_program

(* Locations -- for Sets and Maps. *)
module Codeloc = struct
  (* A "Codeloc" is a CIL location and a function name *)
  type t = location * string
  let compare codeloc1 codeloc2 = 
    let (l1, func1) = codeloc1 in
    let (l2, func2) = codeloc2 in
    if func1 <> func2 then compare func1 func2
    else if l1.file <> l2.file then compare l1.file l2.file
    else if l1.line <> l2.line then compare l1.line l2.line
    else if l1.byte <> l2.byte then compare l1.byte l2.byte
    else 0    
end

module Codelocset = Set.Make(Codeloc)
module Codelocmap = Map.Make(Codeloc)

(* -- Global State -- *)
(* map: Codeloc.t --> varinfo *)
let codelocmap 
    : (varinfo Codelocmap.t) ref
    = ref Codelocmap.empty

(* Elaborate a code location given a CIL location (and the function
   being currently elaborated).  Gives back an expression that
   evaluates to a codeloc_t pointer as well as the globals where
   this pointer points.  Some extra care must be taken to avoid
   elaborating the globals for the same code location twice.  We
   maintain a mapping from code-locations to vars for this
   purpose. *)
let elab_codeloc (location:location) (fn:sac_function) : instr =
  let func = fn.fn_varinfo.vname in
  let codeloc = (location, func) in
  let var = 
    if Codelocmap.mem codeloc !codelocmap 
    then Codelocmap.find codeloc !codelocmap 
    else            
      let file = location.file in
      let line = location.line in
      let byte = location.byte in
      
      (* Create a (psuedo-)unique name for this global -- we replace
         common illegal characters with underscores. *)
      let name =       
        let format = sprintf "codeloc__%s_%d_%d" func line byte in
        let regexp = Str.regexp "-\\|\\.\\| " in
        (Str.global_replace regexp "_" format)
      in
      
      let typ  = api_typ "codeloc_t" in
      let var  = makeGlobalVar name typ in
      let _    = var.vstorage <- Static in
      let init = CompoundInit 
        (typ,
         [ (proj typ ["file"], SingleInit (Const (CStr file))) ;
           (proj typ ["func"], SingleInit (Const (CStr func))) ;
           (proj typ ["line"], SingleInit (integer line)) ;
           (proj typ ["byte"], SingleInit (integer byte)) ;
         ])
      in
      let glob  = GVar (var, {init=Some init}, locUnknown) in
      let _     = fn.fn_globs <- glob :: fn.fn_globs in
      let _     = codelocmap := Codelocmap.add codeloc var !codelocmap in
      (var)
  in    
  (Call (None, Lval(Var (api_varinfo "codeloc_curr"), NoOffset),
         [(AddrOf (Var var, NoOffset))], locUnknown))
