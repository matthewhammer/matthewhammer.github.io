open Cil
open Trace
open Printf

module P = Pretty
module IH = Inthash
module H = Hashtbl
module E = Errormsg
exception Hell
exception Error of string

open Slime_util
open Slime_attrs
open Slime_api
open Slime_program
open Slime_normalize
open Slime_allocation
open Slime_elaborate
open Slime_verifier

let debug = if false then out else no_out

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
let process_fn (varinfo:varinfo) (fundec:fundec option) = 
  if hasAttribute "slime_function" varinfo.vattr then begin
    debug "self-function: %s" varinfo.vname ;
    normalize (add_source_self_function varinfo fundec) ;
    SkipChildren
  end
  else if hasAttribute "slime_function_nomemo" varinfo.vattr then begin
    debug "self-function (no-memo): %s" varinfo.vname ;
    normalize (add_source_self_function varinfo fundec) ;
    SkipChildren
  end
  else if hasAttribute "slime_initializer" varinfo.vattr then begin
    debug "init-function: %s" varinfo.vname ;
    let fn = (add_source_init_function varinfo fundec) in
    check_normal fn ;
    SkipChildren
  end
  else 
    match fundec with 
      | None -> SkipChildren
      | Some fundec ->
          if fundec_uses_ceal_api fundec then begin
            debug "meta-function: %s" varinfo.vname ;
            let fn = (add_source_meta_function varinfo (Some fundec)) in
            check_normal fn ;
            SkipChildren
          end
          else SkipChildren
  
class read_program () = object(self)
  inherit nopCilVisitor
      
  method vvdec (varinfo:varinfo) : varinfo visitAction = 
    process_fn (varinfo) (None)

  method vfunc (fundec:fundec) : fundec visitAction = 
    process_fn (fundec.svar) (Some fundec)

end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
class write_program () = object(self)
  inherit nopCilVisitor
  method vglob (global:global) : global list visitAction = begin
    match global with
      | GVarDecl(varinfo, loc) ->
          if check_function varinfo then
            let fn = lookup_function varinfo in
            ChangeTo (elaborate_prototype fn loc)
          else
            SkipChildren              
      
      | GFun(fundec, loc) -> 
          if check_function fundec.svar then 
            let fn = lookup_function fundec.svar in
            ChangeTo (elaborate_definition fn loc) 
          else
            SkipChildren
            
      | _ -> DoChildren
  end
end

(* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *)
(* The "main" function of this extension. *)
let go file = begin    
  debug "slime transformation: starting:" ;
  debug "slime_elab_closure_elim=%d" !slime_elab_closure_elim ;
  debug "slime_elab_hash_buffer=%d" !slime_elab_hash_buffer ;
  
  visitCilFile (new normalize_attributes () :> cilVisitor) file ;
  visitCilFile (new api_setup () :> cilVisitor) file ;
  Cfg.computeFileCFG file ;
  visitCilFile (new read_program () :> cilVisitor) file ;
  (* TODO -- Do optimizations *)
  
  elaborate_program () ;
  visitCilFile (new write_program () :> cilVisitor) file ;
  
  (* BUG-FIX: some definitions can only safely be included after we
     process the definitions existing in the original file -- e.g., the
     definitions for allocations with 'external' initialization
     functions. *)
  file.globals <- file.globals @ (elaborate_remaining_definitions ()) ;
  
  visitCilFile (new expand_verif_macro () :> cilVisitor) file ;
  visitCilFile (new expand_isverif_macro () :> cilVisitor) file ;
  visitCilFile (new stripper () :> cilVisitor) file ;
  debug "slime transformation: done." ;
  ()
end

let do_slime = ref false

let feature : featureDescr =
  {
    fd_name = "slime";
    fd_enabled = do_slime;
    fd_description = "automagic SLIME code instrumentation";
    fd_extraopt = [ ("--slime-print-dot", 
                     Arg.Set_int slime_print_dot, 
                     " Toggle printing .dot files for CFGs");
                    
                    ("--slime-elab-closure-elim", 
                     Arg.Set_int slime_elab_closure_elim,
                     " Eliminate closures for non-reads ");
                    
                    ("--slime-elab-hash-buffer", 
                     Arg.Set_int slime_elab_hash_buffer, 
                     " Use intermediate buffers for hashing"); ] ;
    fd_doit = (function (f:file) -> go f);
    fd_post_check = true;
  }
