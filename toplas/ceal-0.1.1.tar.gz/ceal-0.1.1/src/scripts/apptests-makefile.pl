#!/usr/bin/env perl
use strict;
use lib "src/scripts/";
use BuildTools;

my $util_code =
    code("box.h", "box.c",
         "coin.h", "coin.c",
         "pair.h", "pair.c",
         "modstack.h", "modstack.c");

my $modlist_code =
    code_union($util_code,
               code("conscell.h", "conscell.c",
                    "modlist.h", "modlist.c"));
                  
my $reduce_code =
    code_union($modlist_code, 
               code("reduce.h", "reduce.c"));

my $filter_sparse_code =
    code_union($modlist_code, 
               code("filter_sparse.h", "filter_sparse.c"));

my $rctree3_code = 
    code_union($modlist_code,
               code("rctree3.h", 
                    "rctree3_alloc.c", 
                    "rctree3_build.c", 
                    "rctree3_common.c",
                    "rctree3_contract.c", 
                    "rctree3_contract_opt.c", 
                    "rctree3_nop.c",
                    "rctree3_maxweight.c",
                    "rctree3_print.c"));

my $geom2d_code =
    code("geom2d.h", "geom2d.c");

my $quickhull_code =
    code_union($modlist_code, 
               $reduce_code,
               $filter_sparse_code,
               $geom2d_code,
               code("quickhull.h", "quickhull.c"));    

my $apptests = 
    [ 
      ## List Primitives:
      apptest ("map", "test_app_map",
               $modlist_code,
               code("test_app_map.c", 
                    "test_inout_int_modlist.c")),

      apptest ("reverse", "test_app_reverse",
               $modlist_code,
               code("test_app_reverse.c", 
                    "test_inout_int_modlist.c")),
      
      apptest ("filter", "test_app_filter",
               $modlist_code,
               code("test_app_filter.c", 
                    "test_inout_int_modlist.c")),

      apptest ("split", "test_app_split",
               $modlist_code,
               code("test_app_split.c", 
                    "test_inout_int_modlist.c")),

      apptest ("merge", "test_app_merge",
               $modlist_code,
               code("test_app_merge.c", 
                    "test_inout_int_modlist.c")),
      
      apptest ("minimum", "test_app_minimum",
               $reduce_code,
               code("test_app_minimum.c", 
                    "test_inout_int_modlist.c", 
                    "test_inout_int.c")),
      
      apptest ("sum", "test_app_sum",
               $reduce_code,
               code("test_app_sum.c", 
                    "test_inout_int_modlist.c", 
                    "test_inout_int.c")),
      
      apptest ("filter-sparse", "test_app_filter_sparse",
               $filter_sparse_code,
               code("test_app_filter_sparse.c", 
                    "test_inout_filter_sparse.c")),

      ## List-Sorting:
      apptest ("quicksort", "test_app_quicksort",
               code_union($modlist_code, code("quicksort.h", "quicksort.c")),
               code("test_app_quicksort.c", 
                    "test_inout_string_modlist.c")),

      apptest ("mergesort", "test_app_mergesort",
               code_union($modlist_code, code("mergesort.h", "mergesort.c")),
               code("test_app_mergesort.c", 
                    "test_inout_string_modlist.c")),

      ## (Binary) Directed Graphs:
      apptest ("bidigraph", "test_app_bidigraph",
               code_union($modlist_code, code("bidigraph.h", "bidigraph.c")),
               code("test_app_bidigraph.c", 
                    "test_inout_bidigraph.c",
                    "test_inout_int_modlist.c")),

      ## Expression trees:
      apptest ("exptrees", "test_app_exptrees",
               code("box.h", "box.c",
                    "exptrees.h", "exptrees.c"),
               code("test_app_exptrees.c", 
                    "test_inout_exptrees.c", 
                    "test_inout_float.c")),
      
      ## (2D) Computational Geometry:
      apptest ("quickhull", "test_app_quickhull",
               $quickhull_code,
               code("test_app_quickhull.c",
                    "test_inout_point2d_modlist.c")),
      
      apptest ("diameter", "test_app_diameter",
               code_union($quickhull_code, code("diameter.h", "diameter.c")),
               code("test_app_diameter.c",
                    "test_inout_point2d_modlist.c",
                    "test_inout_float.c")),

      apptest ("distance", "test_app_distance",
               code_union($quickhull_code, code("diameter.h", "diameter.c")),
               code("test_app_distance.c",
                    "test_inout_point2d_modlist.c",
                    "test_inout_point2d_B_modlist.c",
                    "test_inout_float.c")),
      
      ## Rake-Compress trees (Tree-Contraction):
      apptest ("rctree3", "test_app_rctree3",
               $rctree3_code,
               code("test_app_rctree3.c",
                    "test_inout_rctree3.c")),
      
      ## The -opt version is 'hand-optimized':
      apptest ("rctree3-opt", "test_app_rctree3_opt",
               $rctree3_code,
               code("test_app_rctree3_opt.c",
                    "test_inout_rctree3.c")),

      apptest ("max-weight", "test_app_rctree3_maxweight",
               $rctree3_code,
               code("test_app_rctree3_maxweight.c",
                    "test_inout_rctree3.c")),

      
      ];   

apptest_makefile($apptests);
