#!/usr/bin/env perl
# Matthew Hammer <hammer@tti-c.org>

# cpp-tool -- a tool for doing things that cpp(1) doesn't seem to do
#             very easily*.

# *: The truth is, I'm not really sure.  After a couple of hours of
# reading man pages for cpp(1) and make(1), as well as the on-line
# documentation, I've decided to run the risk of re-inventing the
# wheel if it means I can stop trying to find somebody else's "wheel
# parts".

# The functionality I want involves parsing a C header file for
# (zero-argument) macro definitions.  Given the set of these in a
# given header file, I then want to perform a few simple queries
# and/or textual manipulations.

# LIMITATIONS + BUGS:
# -- only zero-argument macros are recognized (that's all I need for now).
# -- header file isn't fully expanded before being processed. However,
#    conditionals and #includes should both work like you'd expect.

my $name = `basename $0`; chomp($name);
my $usage = <<END;
#$name: usage:
#  -h          --- you're lookin' at it.
#  -f <file>   --- <file> is read as a C header file.
#  -d <macro>  --- the RHS of the definition of <macro> is printed, if found,
#                  error otherwise.  <macro> must be zero-argument.
#
END
$usage =~ s/\#//g;

use strict;
use Getopt::Std;

my $text;

sub get_text {
    my $file_in = shift;
    die "can't read: $file_in\n" if !(-f $file_in);   
    ## This is the gut of it.  Each #define is changed into two
    ## lines.  The first acts like inert text to cpp.  The second acts
    ## as a normal directive.  Then cpp runs over the whole thing and
    ## expands it.  Then we change our inert text copy back to an
    ## ordinary #define.
    $text = `cat $file_in | perl -pe "s/(\#define(\\s.+))/%%%define\\2\\n\\1/g" | cpp -P`;   
    $text =~ s/%%%define/\#define/g;
}

sub get_value {
    my $macro = shift;
    if($text =~ /\#define\s+$macro\s+(.+)/) {
        return $1;
    }
    else {
        die "undefined: $macro\n"
    }
}

my %args;
getopts("f:d:", \%args);

if(exists $args{h}) { die "$usage\n"; }
if(exists $args{f}) {
    get_text($args{f});
    
    if(exists $args{d}) {
        print (get_value($args{d}));
    }
    
    else {
        print $text;
    }
}
else {
    die "$usage\n";
}
