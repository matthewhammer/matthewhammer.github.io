for i in *.dot; do
    o="`basename $i .dot`.ps";
    echo "$i --> $o";
    dot -Tps $i > $o
done
