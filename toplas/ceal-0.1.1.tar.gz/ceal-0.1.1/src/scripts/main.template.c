#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* This file serves as a template. Three 'macros' are to-be-defined:
 *
 *  -- TEST_APP_EXTERNS
 *  -- TEST_APP_LIST
 *  -- TEST_APP_DEFAULT
 *
 *  These macros are filled in by the build system when this template
 *  is used to create a binary to test one or more CEAL applications.   
 */
TEST_APP_EXTERNS
test_app_t* test_app_default = TEST_APP_DEFAULT;
test_app_t* test_apps[] = { TEST_APP_LIST };
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

static int count = sizeof(test_apps) / sizeof(test_app_t*);

test_app_t* test_app_lookup(const char* name) {
  if(name) {
    int i;
    for(i = 0; i < count; i++) {
      if(!strcmp(name, test_apps[i]->name))
        return test_apps[i];
    }
  }
  return NULL;
}

void test_app_listall(FILE* f,
                      const char* prefix,
                      const char* suffix,
                      const char* end)
{
  int i;  
  for(i = 0; i < count; i++) {
    fprintf(f, "%s%s%s",
            prefix, test_apps[i]->name,
            i + 1 < count ? suffix : end);
  }
}

int main(int argc, char** argv) {
  test_state_t test_state;
  
  test_params_default(&test_state.params);
  test_params_from_argv(&test_state.params, argc, argv);
  test_state.slime = slime_open();
  
  /* -- Determine which application we are testing. TEST_APP is either
        NULL or a pointer of type test_app_t*.  If NULL, we try to use
        the command line arguments and our static list of test apps
        (and associated names) to find an app_test_t* pointer. */  
  if(test_app_default != NULL) {
    test_state.app = test_app_default;
  }
  else {
    /* -- Find the requested test application. */
    test_state.app = test_app_lookup(test_state.params.app_name);
  }

  /* -- If we can't find an app_test_t*, issue an error message and exit. */
  if(test_state.app == NULL) {
    fprintf(stderr, "test: ERR: there's no test app: %s (usage: -app <appname>)\n", test_state.params.app_name);
    fprintf(stderr, "here's a list of valid test apps (usage: -list-apps):\n");
    test_app_listall(stderr, "\t", "\n", "\n");
    exit(-1);
  }

  /* -- Echo the parameters back to the user. */
  test_params_print(&test_state.params, stderr);

  /* -- Standard test. */
  test_app(&test_state);

  return 0;
}
