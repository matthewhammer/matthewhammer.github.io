/* SLIME CONFIGURATION.
 *
 * Each #define is (1) an elaboration flag for the front-end system,
 * (2) a build flag for the Makefile, or (3) a directive for the C
 * code for the runtime and applications.
 *
 * Every #define is visible within the C source code of the system
 * (both for the runtime and the applications).
 *
 * These #define's are seperated out from the respective parts of the
 * codetree so that the entire system's build can be parameterized by
 * one file.  This means this file is the only file we need to change
 * to experiment with different "knob settings". It can also be later
 * used to record and summarize these settings.
 *
 */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
 * Flags for building.
 *
 * See also: Makefile
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/** SLIME_BUILD_DEBUG -- Global debug flag used throughout this file. */
#define SLIME_BUILD_DEBUG 1

/** SLIME_BUILD_MERGE -- If non-zero, do a sort of whole-program
    compilation (cilly calls this "merging", see --merge option for
    cilly); otherwise, process each source file seperately, generate
    seperate runtime library, and link as usual. */
#define SLIME_BUILD_MERGE 0

#if SLIME_BUILD_DEBUG
#define SLIME_BUILD_CFLAGS -lm -O0 -g
#else
/*#define NDEBUG 1*/
#if (defined(__x86_64__))
#define SLIME_BUILD_CFLAGS -lm -O3 
#else
#define SLIME_BUILD_CFLAGS -lm -O3 
#endif
#endif

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
 * Flags for elaboration.
 *
 * See also: src/cilext/slime.ml, src/cilext/slime_elaborate.ml
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

#define SLIME_ELAB_CLOSURE_ELIM 1

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
 * Flags compiled into the runtime system.
 *
 * See also: src/runtime/
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* Base Memory Manager.
 *
 * -- See also: basemm.[hc]
 */
#if SLIME_BUILD_DEBUG
#define SLIME_ENABLE_BASEMM_FREESET 0
#else
#define SLIME_ENABLE_BASEMM_FREESET 1
#endif

#define SLIME_ENABLE_BASEMM_STATS 1
#define SLIME_FREESET_MAX_BLOCK_SIZE 128

/* Dynamic tracking of static (code) locations.  For deubbing and
 * profiling the stability characteristics of a program.
 *
 * -- See also: codeloc.[hc]
 */
#if SLIME_BUILD_DEBUG
#define SLIME_ENABLE_CODELOCS 1
#else
#define SLIME_ENABLE_CODELOCS 0
#endif

/* Run-time Logging.  Prints lots and lots of stuff.  Mostly useful
 * for debugging programs that crash.  (Note: For debugging programs
 * that don't crash, but seem unstable, try using
 * SLIME_ENABLE_CODELOCS instead).
 *
 * -- See also: logging.[hc], SLIME_ENABLE_CODELOCS
 */
#if SLIME_BUILD_DEBUG
#define SLIME_ENABLE_LOGGING 0
#define SLIME_LOGGING_STDERR 0
#else
#define SLIME_ENABLE_LOGGING 0
#define SLIME_LOGGING_STDERR 0
#endif

/* Trace-tables.
 *
 * -- See also: tracetbl.[hc]
 */
#define SLIME_TRACETBL_INITIAL_SIZE  64
#define SLIME_TRACETBL_MAX_CAPACITY  0.50
#define SLIME_TRACETBL_GROW_FACTOR   4
#define SLIME_TRACETBL_MIN_CAPACITY  0.10
#define SLIME_TRACETBL_SHRINK_FACTOR 2

/* Imperative Modrefs.
 *
 * -- See also: modref.[hc]
 */
#define SLIME_MODREF_ALLIMPERATIVE 1

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
 * Flags compiled into application-level code.
 *
 * See also: src/apps/
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* Cons-cells for modifiable lists.
 * -- See also: conscell.[hc]
 */
#define SLIME_CONSCELL_PACK 1
